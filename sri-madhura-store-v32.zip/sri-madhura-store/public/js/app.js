// Sri Madhura Agro Traders web store.
// Catalog: Firestore catalog/main (1 read per visit, cached on the phone).
// Orders: saved to an outbox on the phone and sent to Firestore
// orders/{orderNo} when online. The shop sees them live in its app and
// confirms each order with the customer on WhatsApp.
import { FIREBASE_CONFIG, STORE_DEFAULTS, ORDER_PREFIX, FIREBASE_SDK_VERSION, PUSH_VAPID_KEY } from './config.js';

const LS = {
  catalog: 'smat_catalog', cart: 'smat_cart', orders: 'smat_orders',
  outbox: 'smat_outbox', stockAlerts: 'smat_stockalerts', reviewed: 'smat_reviewed', opush: 'smat_opush', alerts: 'smat_alerts', bought: 'smat_bought', sort: 'smat_sort', customer: 'smat_customer', lang: 'smat_lang',
};
const LIVE = Boolean(FIREBASE_CONFIG.apiKey) && !FIREBASE_CONFIG.apiKey.startsWith('PASTE');

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const inr = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 });
const money = (n) => inr.format(Math.round(Number(n) || 0));
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function load(key, fallback) { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; } }
function save(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* storage blocked or full */ } }

/* ---------- Language ---------- */
// Tamil strings: please have a native reader check these before launch.
const I18N = {
  en: {
  reviewOrder: 'Review order', payStep: '1 · Pay {amt}', proofStep: '2 · Upload payment screenshot',
  proofPick: '📷 Choose screenshot', proofChange: 'Change screenshot', utrL: 'UPI transaction ID (optional)',
  proofNeeded: 'Please pay and upload the payment screenshot first.', proofBad: 'Could not read that image. Please choose a screenshot.',
  placeOrder2: 'Place order', proofSent: '✅ Payment screenshot sent. The shop will verify it and confirm your order.',
  fbCard: '💬 Can\'t find something? Tell us', fbCardSub: 'A product you want, feedback or a suggestion — we read every message.',
  fbTitle: 'Feedback & requests', fbText: 'What are you looking for, or what can we improve?', fbName: 'Your name (optional)',
  fbPhone: 'Phone number (optional, for our reply)', fbSend: 'Send', fbThanks: 'Thank you! We\'ve got your message.',
  fbShort: 'Please write a few words.', fbAsk: 'Tell us what you were looking for',
  stockNotify: '🔔 Notify me when back', stockNotifyOn: '🔔 We\'ll tell you when it\'s back', updating: 'Updating to the latest version…',
  askWaShort: 'Ask us on WhatsApp', payViaUpi: 'Pay with UPI app', payViaWa: 'Pay on WhatsApp',
  payWaNote: 'Place your order, then WhatsApp opens with your order details. We\'ll send our payment QR in the chat — pay there and we\'ll confirm.',
  placeAndWa: 'Place order & open WhatsApp', waPayMsg: 'Hi, I placed order {no} for {amt}. Please send the payment QR.',
  waPayDone: 'Pay in our WhatsApp chat — we\'ll send the payment QR there and confirm your order.', openChat: 'Open WhatsApp chat',
  copyUpiBig: 'Copy UPI ID', upiCopiedLine: '✓ UPI ID copied — now open your UPI app:', appSteps: 'In the app: tap "Pay UPI ID" → paste → enter {amt} → pay. Check the name shows {shop}.',
  appStepsIos: 'Open your UPI app → "Pay UPI ID" → paste → enter {amt} → pay. Check the name shows {shop}.',
  reviewsTab: 'Reviews', rateTitle: 'Rate your items', rateName: 'Your name', rateText: 'What did you like? (optional)', rateSend: 'Send review',
  rateThanks: 'Thanks! Your review will appear after the shop checks it.', ratePick: 'Tap the stars to rate first.', ratedL: '✓ Reviewed',
  amountToPay: 'Amount to pay', payNowCopy: 'Pay now',
  payNowHint: 'Tap Pay now: our UPI ID is copied and your UPI apps open. Choose one, enter {amt} and pay.',
  payCopied: 'UPI ID copied. If your app shows an error, open it, tap "Pay UPI ID", paste, enter {amt} and pay.',
  otherWays: 'Other ways to pay',
  payHow: 'Pay with any UPI app (GPay, PhonePe, Paytm):', payWayQr: 'Scan this QR with your UPI app. On this same phone: take a screenshot, then in your UPI app tap Scan → upload from gallery.',
  payWayId: 'Or open your UPI app → "Pay to UPI ID" → paste the UPI ID and amount shown above.',
  amountL: 'Amount', openUpi2: 'Open UPI app', linkNote: 'Google Pay may block this button for safety. If it does, use the QR or UPI ID above.',
  payTrouble: 'Payment link not working?', copyAmount: 'Copy amount',
  payManual: 'If your UPI app shows an error (like "limit exceeded"), pay manually: 1) Copy the UPI ID and amount below. 2) Open GPay, PhonePe or Paytm → "Pay to UPI ID". 3) Paste, pay, and come back to upload the screenshot.',
  notifyOpt: '🔔 Keep me updated: confirmed, dispatched, delivered — and remind me when it\'s time to restock',
  orderUpdates: '🔔 Get updates for this order', orderUpdatesOn: '🔔 You\'ll get updates for this order on this phone',
  reviewOrder2: 'Review order',
  trackBtn: 'Track order', trackTitle: 'Order {no}', trackLoading: 'Checking your order…', trackNotFound: 'We couldn\'t find this order yet. If you just ordered, try again in a minute.',
  trackOffline: 'Connect to the internet to see the latest status.', trackRefresh: 'Refresh',
  st_requested: 'Order placed', st_confirmed: 'Confirmed', st_dispatched: 'Dispatched', st_delivered: 'Delivered', st_cancelled: 'Cancelled',
  courierL: 'Courier', trackNoL: 'Tracking no.', trackParcel: 'Track parcel', updatedL: 'Updated {when}',
  installTitle: 'Get the Madhura Millets app', installSub: 'Reorder in one tap · works offline · free',
  installBtn: 'Install', installHow: 'How to install', notNow: 'Not now',
  iosSteps: 'Tap the Share button at the bottom, then "Add to Home Screen".',
  menuSteps: 'Tap the ⋮ menu at the top of Chrome, then "Install app" or "Add to Home screen".',
  alertsBtn: 'Get offer alerts', alertsOn: 'Offer alerts are on', alertsIntro: 'Be the first to hear about new combos, fresh stock and price drops.',
  alertsInstallFirst: 'On iPhone, add the store to your Home Screen first, then turn on alerts.',
  alertsBlocked: 'Notifications are blocked for this site. Allow them in your browser settings.',
  alertsFail: 'Could not turn on alerts right now. Please try again later.',
  enterPin: 'Enter pincode to see', weightL: 'Weight', zoneLocal: 'Local', zoneState: 'Tamil Nadu', zoneIndia: 'Rest of India',
  payInfo: 'Pay by UPI — GPay, PhonePe, Paytm or any UPI app — right after placing your order.',
  payNow: 'Pay {amt} now', payAfter: 'After paying, send the payment screenshot on WhatsApp so we can confirm.',
  sendShot: 'Send payment screenshot', payLater: 'The shop will share payment details on WhatsApp.',
  paidMsg: 'Hi, I have paid {amt} for order {no}. Sending the screenshot.',
  addrLine: 'Door no. & street', landmark: 'Landmark (optional)', city: 'Town / city', pincode: 'Pincode',
  errPin: 'Enter a 6-digit pincode', errCity: 'Enter your town or city',
  itemsTotal: 'Items', deliveryCharge: 'Delivery charge', freeDelivery: 'Free', grandTotal: 'Total to pay',
  freeAbove: 'Free delivery on orders above {amt}', addMore: 'Add {amt} more for free delivery',
  confirmTitle: 'Confirm your order', confirmAddr: 'Deliver to', confirmPickup: 'Pick up from the shop',
  confirmQ: 'Is this address correct?', confirmYes: 'Yes, place order', confirmEdit: 'Edit details',
  combos: 'Combo offers', comboTag: 'Combo', comboSave: 'Save {amt}',
  subAll: 'All', emailUs: 'Email',
  waHello: 'Hi, I have a question about your products.', chatWa: 'Chat on WhatsApp',
  sortBy: 'Sort', sortRec: 'Recommended', sortPriceUp: 'Price: low to high', sortPriceDown: 'Price: high to low', sortName: 'Name A–Z', sortBest: 'Best sellers first',
  customKg: 'Custom', customTitle: 'Enter quantity', kgLabel: 'Quantity in kg', kgHint: 'e.g. 2.5 for two and a half kg', kgAdd: 'Use this quantity', kgBad: 'Enter a quantity from 0.1 to 100 kg',
  startShopping: 'Shop fresh stock', orderWa: 'Order on WhatsApp', learnBtn: 'Health benefits 🌿',
  tabAbout: 'About', tabBenefits: 'Benefits', tabHowTo: 'How to use', noInfo: 'Details coming soon.',
  healthNote: 'General information, not medical advice. For health conditions, ask your doctor.',
  customerTips: 'Tips from customers', shareTip: 'Share how you use it', tipName: 'Your name', tipText: 'Your tip or recipe',
  tipSend: 'Send tip', tipThanks: 'Thank you! Your tip will appear after the shop checks it.', tipOffline: 'Connect to the internet to send a tip.',
  learnTitle: 'Know your grains', learnIntro: 'What each grain is good for, and how to cook it.', readMore: 'Read more',
  bestSellers: 'Best sellers', newArrivals: 'New arrivals', orderAgain: 'Order again',
  save: 'Save {amt}', askWa: 'Ask on WhatsApp', details: 'Details', related: 'You may also need',
  navHome: 'Home', navCats: 'Categories', navSearch: 'Search', savedTotal: 'You saved {amt} on this order',
  homemade: 'Homemade', bestTag: 'Best seller', newTag: 'New', aboutUs: 'About us', callUs: 'Call us',
  findUs: 'Find us on the map', followUs: 'Instagram', hoursL: 'Shop hours',
  yearsServing: 'Serving for over {n} years', waAsk: 'Hi, I would like to know more about {name}.',
  viewProduct: 'View details of {name}',
    demo: 'Preview mode with sample products. Add your Firebase settings in js/config.js to go live.',
    heroTitle: 'Order millets, rice and grains online',
    point1: 'Pay by UPI', point2: 'Order tracking', point3: 'WhatsApp confirmation',
    ordersShort: 'Orders', cartShort: 'Cart',
    search: 'Search products', searchPh: 'Search products',
    offers: 'Offers', searchResults: 'Search results', nProducts: '{n} items', oneProduct: '1 item',
    add: 'Add', outOfStock: 'Out of stock', pctOff: '{pct}% off', packSize: 'Pack size',
    viewCart: 'View cart', cart: 'Your cart', items: '{n} items', item: '1 item',
    emptyCart: 'Your cart is empty. Add products to place an order.', browse: 'Browse products',
    each: '{price} each', nowOut: 'Now out of stock, not included',
    total: 'Total', deliveryNote: 'Delivery charges, if any, are confirmed on WhatsApp.',
    minOrder: 'Minimum order is {min}. Add {more} more to continue.',
    toCheckout: 'Continue to checkout', checkout: 'Checkout',
    yourName: 'Your name', mobile: 'Mobile number', mobilePh: '10-digit number',
    howGet: 'How do you want it?', delivery: 'Home delivery', pickup: 'Pick up from shop',
    pickupFallback: 'The shop shares its location on WhatsApp.',
    area: 'Area', chooseArea: 'Choose your area', otherArea: 'Other area', address: 'Delivery address',
    payment: 'Payment', cod: 'Cash on delivery', upi: 'UPI', upiHint: 'Pay by UPI after the shop confirms your total on WhatsApp.',
    note: 'Note for the shop (optional)', placeOrder: 'Place order',
    placeHint: 'The shop confirms every order on WhatsApp, usually within a few minutes.',
    errName: 'Enter your name.', errPhone: 'Enter a 10-digit mobile number.',
    errAddress: 'Enter the delivery address.', errArea: 'Choose your area.',
    orderPlaced: 'Order placed', shopWillConfirm: 'The shop will confirm your order on WhatsApp shortly.',
    copyDetails: 'Copy order details', copyShort: 'Copy', sendWa: 'Send details on WhatsApp',
    continueShopping: 'Continue shopping', upiId: 'UPI ID', copyUpi: 'Copy UPI ID', openUpi: 'Open UPI app',
    yourOrders: 'Your orders',
    ordersHint: 'Orders placed from this phone. The shop confirms each one on WhatsApp.',
    noOrders: 'No orders from this phone yet.',
    st_pending: 'Saved on this phone. It reaches the shop when you are online.',
    st_saved: 'Received by the shop', st_failed: 'Not saved online. Send the details to the shop on WhatsApp.',
    st_demo: 'Preview mode: not saved online',
    ss_pending: 'Waiting for internet', ss_saved: 'Received', ss_failed: 'Not saved', ss_demo: 'Preview',
    noProducts: 'Products are being added. Check back soon.',
    noMatch: 'No products match “{q}”. Try another word.',
    loadFail: 'Products could not load. Check your internet connection and refresh.',
    savedCopy: 'Showing prices saved on this phone. Final prices are confirmed on WhatsApp.',
    offline: "You're offline. You can still browse and place orders; they are sent when you're back online.",
    copied: 'Copied', copyFail: 'Copy did not work. Long-press to copy instead.',
    reached: 'Order {no} reached the shop.', chatUs: 'Chat with us on WhatsApp',
    qtyOf: 'Quantity of {name}', removeOne: 'Remove one', addOne: 'Add one',
  },
  ta: {
  reviewOrder: 'ஆர்டரை சரிபார்', payStep: '1 · {amt} செலுத்துங்கள்', proofStep: '2 · பணம் செலுத்திய ஸ்கிரீன்ஷாட்டை பதிவேற்றவும்',
  proofPick: '📷 ஸ்கிரீன்ஷாட் தேர்வு செய்', proofChange: 'ஸ்கிரீன்ஷாட்டை மாற்று', utrL: 'UPI பரிவர்த்தனை எண் (விருப்பம்)',
  proofNeeded: 'முதலில் பணம் செலுத்தி ஸ்கிரீன்ஷாட்டை பதிவேற்றவும்.', proofBad: 'அந்த படத்தை படிக்க முடியவில்லை. ஸ்கிரீன்ஷாட்டை தேர்வு செய்யவும்.',
  placeOrder2: 'ஆர்டர் செய்', proofSent: '✅ பணம் செலுத்திய ஸ்கிரீன்ஷாட் அனுப்பப்பட்டது. கடை சரிபார்த்து உங்கள் ஆர்டரை உறுதிசெய்யும்.',
  fbCard: '💬 தேடியது கிடைக்கவில்லையா? சொல்லுங்கள்', fbCardSub: 'நீங்கள் விரும்பும் பொருள், கருத்து அல்லது ஆலோசனை — ஒவ்வொரு செய்தியையும் படிக்கிறோம்.',
  fbTitle: 'கருத்து & கோரிக்கைகள்', fbText: 'நீங்கள் எதைத் தேடுகிறீர்கள், அல்லது நாங்கள் எதை மேம்படுத்தலாம்?', fbName: 'உங்கள் பெயர் (விருப்பம்)',
  fbPhone: 'போன் எண் (விருப்பம், பதில் அனுப்ப)', fbSend: 'அனுப்பு', fbThanks: 'நன்றி! உங்கள் செய்தி கிடைத்தது.',
  fbShort: 'சில வார்த்தைகள் எழுதவும்.', fbAsk: 'நீங்கள் தேடியதைச் சொல்லுங்கள்',
  stockNotify: '🔔 வந்ததும் சொல்லுங்கள்', stockNotifyOn: '🔔 வந்ததும் உங்களுக்குச் சொல்வோம்', updating: 'புதிய பதிப்புக்கு மாறுகிறது…',
  askWaShort: 'WhatsApp-ல் கேளுங்கள்', payViaUpi: 'UPI செயலியில் செலுத்து', payViaWa: 'WhatsApp-ல் செலுத்து',
  payWaNote: 'ஆர்டர் செய்யுங்கள், பின் உங்கள் ஆர்டர் விவரத்துடன் WhatsApp திறக்கும். சாட்டில் எங்கள் QR அனுப்புவோம் — அங்கே செலுத்துங்கள், நாங்கள் உறுதிசெய்வோம்.',
  placeAndWa: 'ஆர்டர் செய்து WhatsApp திற', waPayMsg: 'வணக்கம், ஆர்டர் {no} ({amt}) செய்துள்ளேன். பணம் செலுத்தும் QR அனுப்பவும்.',
  waPayDone: 'எங்கள் WhatsApp சாட்டில் செலுத்துங்கள் — QR அனுப்பி உங்கள் ஆர்டரை உறுதிசெய்வோம்.', openChat: 'WhatsApp சாட் திற',
  copyUpiBig: 'UPI ID நகலெடு', upiCopiedLine: '✓ UPI ID நகலெடுக்கப்பட்டது — உங்கள் UPI செயலியைத் திறக்கவும்:', appSteps: 'செயலியில்: "Pay UPI ID" → ஒட்டவும் → {amt} உள்ளிடவும் → செலுத்தவும். பெயர் {shop} என வருகிறதா பாருங்கள்.',
  appStepsIos: 'UPI செயலி → "Pay UPI ID" → ஒட்டவும் → {amt} உள்ளிடவும் → செலுத்தவும். பெயர் {shop} என வருகிறதா பாருங்கள்.',
  reviewsTab: 'மதிப்புரைகள்', rateTitle: 'உங்கள் பொருட்களை மதிப்பிடுங்கள்', rateName: 'உங்கள் பெயர்', rateText: 'என்ன பிடித்தது? (விருப்பம்)', rateSend: 'மதிப்புரை அனுப்பு',
  rateThanks: 'நன்றி! கடை சரிபார்த்த பின் உங்கள் மதிப்புரை தோன்றும்.', ratePick: 'முதலில் நட்சத்திரங்களை அழுத்தி மதிப்பிடுங்கள்.', ratedL: '✓ மதிப்பிடப்பட்டது',
  amountToPay: 'செலுத்த வேண்டிய தொகை', payNowCopy: 'இப்போது செலுத்து',
  payNowHint: 'இப்போது செலுத்து அழுத்தவும்: எங்கள் UPI ID நகலெடுக்கப்பட்டு உங்கள் UPI செயலிகள் திறக்கும். ஒன்றைத் தேர்ந்தெடுத்து {amt} உள்ளிட்டு செலுத்துங்கள்.',
  payCopied: 'UPI ID நகலெடுக்கப்பட்டது. செயலி பிழை காட்டினால், அதைத் திறந்து "Pay UPI ID" அழுத்தி, ஒட்டி, {amt} உள்ளிட்டு செலுத்துங்கள்.',
  otherWays: 'பணம் செலுத்த மற்ற வழிகள்',
  payHow: 'எந்த UPI செயலியிலும் செலுத்தலாம் (GPay, PhonePe, Paytm):', payWayQr: 'இந்த QR-ஐ உங்கள் UPI செயலியில் ஸ்கேன் செய்யுங்கள். இதே போனில்: ஸ்கிரீன்ஷாட் எடுத்து, UPI செயலியில் Scan → gallery-ல் இருந்து பதிவேற்றவும்.',
  payWayId: 'அல்லது UPI செயலி → "Pay to UPI ID" → மேலே உள்ள UPI ID மற்றும் தொகையை ஒட்டவும்.',
  amountL: 'தொகை', openUpi2: 'UPI செயலியைத் திற', linkNote: 'Google Pay பாதுகாப்புக்காக இந்த பொத்தானைத் தடுக்கலாம். அப்படியானால், மேலே உள்ள QR அல்லது UPI ID-ஐப் பயன்படுத்தவும்.',
  payTrouble: 'பணம் செலுத்தும் இணைப்பு வேலை செய்யவில்லையா?', copyAmount: 'தொகையை நகலெடு',
  payManual: 'உங்கள் UPI செயலி பிழை காட்டினால் ("limit exceeded" போன்றவை), நேரடியாக செலுத்துங்கள்: 1) கீழே உள்ள UPI ID மற்றும் தொகையை நகலெடுக்கவும். 2) GPay, PhonePe அல்லது Paytm → "Pay to UPI ID". 3) ஒட்டி, செலுத்தி, திரும்பி வந்து ஸ்கிரீன்ஷாட்டை பதிவேற்றவும்.',
  notifyOpt: '🔔 ஆர்டர் உறுதி, அனுப்புதல், டெலிவரி அறிவிப்புகள் — மீண்டும் வாங்கும் நேரத்தில் நினைவூட்டலும்',
  orderUpdates: '🔔 இந்த ஆர்டரின் அறிவிப்புகள் பெறுங்கள்', orderUpdatesOn: '🔔 இந்த ஆர்டரின் அறிவிப்புகள் இந்த போனில் வரும்',
  reviewOrder2: 'ஆர்டரை சரிபார்',
  trackBtn: 'ஆர்டரை கண்காணி', trackTitle: 'ஆர்டர் {no}', trackLoading: 'உங்கள் ஆர்டரை சரிபார்க்கிறோம்…', trackNotFound: 'இந்த ஆர்டர் இன்னும் கிடைக்கவில்லை. இப்போது ஆர்டர் செய்திருந்தால், ஒரு நிமிடம் கழித்து முயற்சிக்கவும்.',
  trackOffline: 'சமீபத்திய நிலையைப் பார்க்க இணையத்துடன் இணைக்கவும்.', trackRefresh: 'புதுப்பி',
  st_requested: 'ஆர்டர் செய்யப்பட்டது', st_confirmed: 'உறுதிசெய்யப்பட்டது', st_dispatched: 'அனுப்பப்பட்டது', st_delivered: 'டெலிவரி செய்யப்பட்டது', st_cancelled: 'ரத்து செய்யப்பட்டது',
  courierL: 'கூரியர்', trackNoL: 'கண்காணிப்பு எண்', trackParcel: 'பார்சலை கண்காணி', updatedL: '{when} புதுப்பிக்கப்பட்டது',
  installTitle: 'மதுரா மில்லெட்ஸ் செயலியைப் பெறுங்கள்', installSub: 'ஒரே தட்டில் மீண்டும் ஆர்டர் · ஆஃப்லைனிலும் இயங்கும் · இலவசம்',
  installBtn: 'நிறுவு', installHow: 'நிறுவும் முறை', notNow: 'இப்போது வேண்டாம்',
  iosSteps: 'கீழே உள்ள Share பொத்தானை அழுத்தி, "Add to Home Screen" தேர்வு செய்யவும்.',
  menuSteps: 'Chrome-இன் மேலே உள்ள ⋮ மெனுவை அழுத்தி, "Install app" அல்லது "Add to Home screen" தேர்வு செய்யவும்.',
  alertsBtn: 'சலுகை அறிவிப்புகள் பெறுங்கள்', alertsOn: 'சலுகை அறிவிப்புகள் இயக்கத்தில்', alertsIntro: 'புதிய காம்போ, புதிய சரக்கு, விலைக் குறைப்பு — முதலில் உங்களுக்கே தெரியும்.',
  alertsInstallFirst: 'iPhone-ல், முதலில் கடையை Home Screen-ல் சேர்த்து, பின் அறிவிப்புகளை இயக்கவும்.',
  alertsBlocked: 'இந்த தளத்திற்கு அறிவிப்புகள் தடுக்கப்பட்டுள்ளன. உலாவி அமைப்புகளில் அனுமதிக்கவும்.',
  alertsFail: 'இப்போது அறிவிப்புகளை இயக்க முடியவில்லை. பிறகு முயற்சிக்கவும்.',
  enterPin: 'பின்கோடு உள்ளிட்டால் தெரியும்', weightL: 'எடை', zoneLocal: 'உள்ளூர்', zoneState: 'தமிழ்நாடு', zoneIndia: 'இந்தியாவின் மற்ற பகுதிகள்',
  payInfo: 'ஆர்டர் செய்தவுடன் UPI மூலம் செலுத்துங்கள் — GPay, PhonePe, Paytm அல்லது எந்த UPI செயலியும்.',
  payNow: '{amt} இப்போது செலுத்து', payAfter: 'செலுத்திய பின், உறுதிசெய்ய பணம் செலுத்திய ஸ்கிரீன்ஷாட்டை WhatsApp-ல் அனுப்பவும்.',
  sendShot: 'ஸ்கிரீன்ஷாட் அனுப்பு', payLater: 'பணம் செலுத்தும் விவரங்களை கடை WhatsApp-ல் பகிரும்.',
  paidMsg: 'வணக்கம், ஆர்டர் {no}-க்கு {amt} செலுத்திவிட்டேன். ஸ்கிரீன்ஷாட் அனுப்புகிறேன்.',
  addrLine: 'கதவு எண் & தெரு', landmark: 'அடையாளம் (விருப்பம்)', city: 'ஊர் / நகரம்', pincode: 'பின்கோடு',
  errPin: '6 இலக்க பின்கோடு உள்ளிடவும்', errCity: 'உங்கள் ஊரை உள்ளிடவும்',
  itemsTotal: 'பொருட்கள்', deliveryCharge: 'டெலிவரி கட்டணம்', freeDelivery: 'இலவசம்', grandTotal: 'செலுத்த வேண்டிய தொகை',
  freeAbove: '{amt}க்கு மேல் ஆர்டருக்கு இலவச டெலிவரி', addMore: 'இலவச டெலிவரிக்கு இன்னும் {amt} சேர்க்கவும்',
  confirmTitle: 'உங்கள் ஆர்டரை உறுதிசெய்யவும்', confirmAddr: 'டெலிவரி முகவரி', confirmPickup: 'கடையில் பெற்றுக்கொள்ளவும்',
  confirmQ: 'இந்த முகவரி சரியா?', confirmYes: 'ஆம், ஆர்டர் செய்', confirmEdit: 'விவரங்களைத் திருத்து',
  combos: 'காம்போ சலுகைகள்', comboTag: 'காம்போ', comboSave: '{amt} சேமிப்பு',
  subAll: 'அனைத்தும்', emailUs: 'மின்னஞ்சல்',
  waHello: 'வணக்கம், உங்கள் பொருட்கள் பற்றி ஒரு கேள்வி.', chatWa: 'WhatsApp-ல் பேசுங்கள்',
  sortBy: 'வரிசை', sortRec: 'பரிந்துரை', sortPriceUp: 'விலை: குறைவு முதல்', sortPriceDown: 'விலை: அதிகம் முதல்', sortName: 'பெயர் அ–ஃ', sortBest: 'அதிகம் விற்பனையானவை முதல்',
  customKg: 'விருப்ப அளவு', customTitle: 'அளவை உள்ளிடவும்', kgLabel: 'கிலோவில் அளவு', kgHint: 'எ.கா. இரண்டரை கிலோவுக்கு 2.5', kgAdd: 'இந்த அளவை பயன்படுத்து', kgBad: '0.1 முதல் 100 கிலோ வரை உள்ளிடவும்',
  startShopping: 'புதிய சரக்கை வாங்குங்கள்', orderWa: 'WhatsApp-ல் ஆர்டர் செய்ய', learnBtn: 'ஆரோக்கிய நன்மைகள் 🌿',
  tabAbout: 'விவரம்', tabBenefits: 'நன்மைகள்', tabHowTo: 'பயன்படுத்தும் முறை', noInfo: 'விவரங்கள் விரைவில்.',
  healthNote: 'இது பொதுவான தகவல், மருத்துவ ஆலோசனை அல்ல. உடல்நலப் பிரச்சினைகளுக்கு மருத்துவரை அணுகவும்.',
  customerTips: 'வாடிக்கையாளர் குறிப்புகள்', shareTip: 'நீங்கள் எப்படி பயன்படுத்துகிறீர்கள் என பகிருங்கள்', tipName: 'உங்கள் பெயர்', tipText: 'உங்கள் குறிப்பு அல்லது செய்முறை',
  tipSend: 'அனுப்பு', tipThanks: 'நன்றி! கடை சரிபார்த்த பின் உங்கள் குறிப்பு தோன்றும்.', tipOffline: 'குறிப்பை அனுப்ப இணையத்துடன் இணைக்கவும்.',
  learnTitle: 'உங்கள் தானியங்களை அறியுங்கள்', learnIntro: 'ஒவ்வொரு தானியத்தின் நன்மைகள் மற்றும் சமைக்கும் முறை.', readMore: 'மேலும் படிக்க',
  bestSellers: 'அதிகம் விற்பனையானவை', newArrivals: 'புதிய வரவுகள்', orderAgain: 'மீண்டும் ஆர்டர் செய்ய',
  save: '{amt} சேமிப்பு', askWa: 'WhatsApp-ல் கேளுங்கள்', details: 'விவரங்கள்', related: 'உங்களுக்கு தேவைப்படலாம்',
  navHome: 'முகப்பு', navCats: 'வகைகள்', navSearch: 'தேடல்', savedTotal: 'இந்த ஆர்டரில் {amt} சேமித்துள்ளீர்கள்',
  homemade: 'வீட்டுத் தயாரிப்பு', bestTag: 'அதிக விற்பனை', newTag: 'புதியது', aboutUs: 'எங்களைப் பற்றி', callUs: 'அழைக்கவும்',
  findUs: 'வரைபடத்தில் காண', followUs: 'Instagram', hoursL: 'கடை நேரம்',
  yearsServing: '{n} ஆண்டுகளுக்கும் மேலாக சேவை', waAsk: 'வணக்கம், {name} பற்றி அறிய விரும்புகிறேன்.',
  viewProduct: '{name} விவரங்கள்',
    demo: 'மாதிரி பொருட்களுடன் முன்னோட்டம். நேரலைக்கு js/config.js-ல் Firebase அமைப்புகளைச் சேர்க்கவும்.',
    heroTitle: 'சிறுதானியங்கள், அரிசி, தானியங்கள் ஆன்லைனில் ஆர்டர் செய்யுங்கள்',
    point1: 'UPI மூலம் பணம்', point2: 'ஆர்டர் கண்காணிப்பு', point3: 'WhatsApp உறுதிப்படுத்தல்',
    ordersShort: 'ஆர்டர்கள்', cartShort: 'கூடை',
    search: 'பொருட்களைத் தேடுங்கள்', searchPh: 'பொருட்களைத் தேடுங்கள்',
    offers: 'சலுகைகள்', searchResults: 'தேடல் முடிவுகள்', nProducts: '{n} பொருட்கள்', oneProduct: '1 பொருள்',
    add: 'சேர்', outOfStock: 'இருப்பு இல்லை', pctOff: '{pct}% தள்ளுபடி', packSize: 'அளவு',
    viewCart: 'கூடையைப் பார்', cart: 'உங்கள் கூடை', items: '{n} பொருட்கள்', item: '1 பொருள்',
    emptyCart: 'உங்கள் கூடை காலியாக உள்ளது. ஆர்டர் செய்ய பொருட்களைச் சேர்க்கவும்.', browse: 'பொருட்களைப் பார்க்க',
    each: 'ஒன்றுக்கு {price}', nowOut: 'இப்போது இருப்பு இல்லை, சேர்க்கப்படவில்லை',
    total: 'மொத்தம்', deliveryNote: 'டெலிவரி கட்டணம் இருந்தால் WhatsApp-ல் தெரிவிக்கப்படும்.',
    minOrder: 'குறைந்தபட்ச ஆர்டர் {min}. தொடர இன்னும் {more} சேர்க்கவும்.',
    toCheckout: 'ஆர்டர் செய்யத் தொடரவும்', checkout: 'ஆர்டர் விவரங்கள்',
    yourName: 'உங்கள் பெயர்', mobile: 'மொபைல் எண்', mobilePh: '10 இலக்க எண்',
    howGet: 'எப்படிப் பெற விரும்புகிறீர்கள்?', delivery: 'வீட்டுக்கு டெலிவரி', pickup: 'கடையில் பெற்றுக்கொள்',
    pickupFallback: 'கடையின் இருப்பிடம் WhatsApp-ல் பகிரப்படும்.',
    area: 'பகுதி', chooseArea: 'உங்கள் பகுதியைத் தேர்ந்தெடுக்கவும்', otherArea: 'பிற பகுதி', address: 'டெலிவரி முகவரி',
    payment: 'பணம் செலுத்தும் முறை', cod: 'டெலிவரியில் பணம்', upi: 'UPI', upiHint: 'கடை WhatsApp-ல் மொத்தத் தொகையை உறுதிப்படுத்திய பின் UPI-ல் செலுத்தவும்.',
    note: 'கடைக்கான குறிப்பு (விருப்பம்)', placeOrder: 'ஆர்டர் செய்',
    placeHint: 'ஒவ்வொரு ஆர்டரையும் கடை WhatsApp-ல் சில நிமிடங்களில் உறுதிப்படுத்தும்.',
    errName: 'உங்கள் பெயரை உள்ளிடவும்.', errPhone: '10 இலக்க மொபைல் எண்ணை உள்ளிடவும்.',
    errAddress: 'டெலிவரி முகவரியை உள்ளிடவும்.', errArea: 'உங்கள் பகுதியைத் தேர்ந்தெடுக்கவும்.',
    orderPlaced: 'ஆர்டர் செய்யப்பட்டது', shopWillConfirm: 'கடை உங்கள் ஆர்டரை விரைவில் WhatsApp-ல் உறுதிப்படுத்தும்.',
    copyDetails: 'ஆர்டர் விவரங்களை நகலெடு', copyShort: 'நகலெடு', sendWa: 'விவரங்களை WhatsApp-ல் அனுப்பு',
    continueShopping: 'தொடர்ந்து வாங்கவும்', upiId: 'UPI ஐடி', copyUpi: 'UPI ஐடியை நகலெடு', openUpi: 'UPI செயலியைத் திற',
    yourOrders: 'உங்கள் ஆர்டர்கள்',
    ordersHint: 'இந்த போனிலிருந்து செய்த ஆர்டர்கள். ஒவ்வொன்றையும் கடை WhatsApp-ல் உறுதிப்படுத்தும்.',
    noOrders: 'இந்த போனிலிருந்து இன்னும் ஆர்டர்கள் இல்லை.',
    st_pending: 'இந்த போனில் சேமிக்கப்பட்டது. இணையம் வந்ததும் கடைக்குச் சென்றடையும்.',
    st_saved: 'கடைக்குச் சென்றடைந்தது', st_failed: 'ஆன்லைனில் சேமிக்க முடியவில்லை. விவரங்களை WhatsApp-ல் கடைக்கு அனுப்பவும்.',
    st_demo: 'முன்னோட்டம்: ஆன்லைனில் சேமிக்கப்படவில்லை',
    ss_pending: 'இணையத்திற்காகக் காத்திருக்கிறது', ss_saved: 'சென்றடைந்தது', ss_failed: 'சேமிக்கப்படவில்லை', ss_demo: 'முன்னோட்டம்',
    noProducts: 'பொருட்கள் சேர்க்கப்பட்டு வருகின்றன. விரைவில் பார்க்கவும்.',
    noMatch: '“{q}” உடன் பொருந்தும் பொருட்கள் இல்லை. வேறு சொல்லை முயற்சிக்கவும்.',
    loadFail: 'பொருட்களை ஏற்ற முடியவில்லை. இணைய இணைப்பைச் சரிபார்த்து மீண்டும் முயற்சிக்கவும்.',
    savedCopy: 'இந்த போனில் சேமித்த விலைகள் காட்டப்படுகின்றன. இறுதி விலை WhatsApp-ல் உறுதிப்படுத்தப்படும்.',
    offline: 'நீங்கள் ஆஃப்லைனில் உள்ளீர்கள். பொருட்களைப் பார்த்து ஆர்டர் செய்யலாம்; இணையம் வந்ததும் அனுப்பப்படும்.',
    copied: 'நகலெடுக்கப்பட்டது', copyFail: 'நகலெடுக்க முடியவில்லை. நீண்ட நேரம் அழுத்தி நகலெடுக்கவும்.',
    reached: 'ஆர்டர் {no} கடைக்குச் சென்றடைந்தது.', chatUs: 'WhatsApp-ல் எங்களைத் தொடர்பு கொள்ளுங்கள்',
    qtyOf: '{name} அளவு', removeOne: 'ஒன்றைக் குறை', addOne: 'ஒன்றைச் சேர்',
  },
};

const SITE_VERSION = 'v32';
const OFFERS = '__offers';
const AGAIN = '__again';
const BEST = '__best';
const NEWS = '__new';
const state = {
  catalog: null, rawSig: '', cart: load(LS.cart, {}), sel: {}, active: '', q: '',
  // First visit: Tamil-language phones open in Tamil; afterwards the
  // customer's own choice is remembered.
  sort: null,
  lang: (load(LS.lang, null) ?? ((navigator.languages || [navigator.language || '']).some((l) => /^ta\b/i.test(l)) ? 'ta' : 'en')) === 'ta' ? 'ta' : 'en',
  fs: null, db: null, fromCache: false, view: null, starting: false,
};
const inflight = new Set();

function t(key, vars = {}) {
  let s = I18N[state.lang][key] ?? I18N.en[key] ?? key;
  for (const [k, v] of Object.entries(vars)) s = s.split(`{${k}}`).join(v);
  return s;
}
const isTa = () => state.lang === 'ta';

/* ---------- Icons ---------- */
const svg = (inner, size = 22) => `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${inner}</svg>`;
const ICONS = {
  sack: '<path d="M8 4h8l-1.5 3c3 2 4.5 5.5 4.5 9 0 3-2 5-7 5s-7-2-7-5c0-3.5 1.5-7 4.5-9z"/><path d="M9.5 7h5"/>',
  millet: '<path d="M12 21V8"/><path d="M12 8C9.5 8 8 6.2 8 3.5c2.5 0 4 1.8 4 4.5zM12 8c2.5 0 4-1.8 4-4.5-2.5 0-4 1.8-4 4.5z"/><path d="M12 14c-2.5 0-4-1.8-4-4.5 2.5 0 4 1.8 4 4.5zM12 14c2.5 0 4-1.8 4-4.5-2.5 0-4 1.8-4 4.5z"/>',
  rice: '<path d="M3 11h18a9 9 0 0 1-18 0z"/><path d="M8 8.5l.6-1.4M12 7.6V6M16 8.5l-.6-1.4"/>',
  seeds: '<ellipse cx="8" cy="9" rx="3" ry="4.2" transform="rotate(-25 8 9)"/><ellipse cx="16" cy="9" rx="3" ry="4.2" transform="rotate(25 16 9)"/><ellipse cx="12" cy="16.5" rx="3" ry="4.2"/>',
  tag: '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1.5"/>',
  receipt: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6M9 16h3"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="M20 20l-4.8-4.8"/>',
};
function catIcon(cat) {
  if (cat === OFFERS) return ICONS.tag;
  if (cat === AGAIN) return EXTRA_ICONS.again;
  if (cat === BEST) return EXTRA_ICONS.star;
  if (cat === NEWS) return EXTRA_ICONS.spark;
  const c = cat.toLowerCase();
  if (/feed|cattle|cow|poultry|bran|cake/.test(c)) return ICONS.sack;
  if (/millet|ragi|bajra|jowar|thinai|samai/.test(c)) return ICONS.millet;
  if (/rice|arisi/.test(c)) return ICONS.rice;
  if (/grain|pulse|dal|gram|seed|bean/.test(c)) return ICONS.seeds;
  return ICONS.sack;
}

/* ---------- Catalog ---------- */
function normalize(raw) {
  const store = { ...STORE_DEFAULTS, ...(raw.store || {}) };
  const hidden = new Set((Array.isArray(raw.hiddenCategories) ? raw.hiddenCategories : []).map(String));
  const categoriesLocal = raw.categoriesLocal && typeof raw.categoriesLocal === 'object' ? raw.categoriesLocal : {};
  const products = (Array.isArray(raw.products) ? raw.products : [])
    .filter((p) => p && p.id && p.name)
    .map((p) => ({
      id: String(p.id),
      name: String(p.name),
      nameLocal: p.nameLocal ? String(p.nameLocal) : '',
      category: p.category ? String(p.category) : 'Other',
      image: p.image ? String(p.image) : '',
      description: p.description ? String(p.description) : '',
      descriptionLocal: p.descriptionLocal ? String(p.descriptionLocal) : '',
      details: (Array.isArray(p.details) ? p.details : []).map((d) => String(d).trim()).filter(Boolean).slice(0, 12),
      subcategory: p.subcategory ? String(p.subcategory).trim() : '',
      subcategoryLocal: p.subcategoryLocal ? String(p.subcategoryLocal).trim() : '',
      homemade: p.homemade === true,
      rating: p.rating && Number(p.rating.count) > 0 ? { avg: Number(p.rating.avg) || 0, count: Number(p.rating.count) } : null,
      reviews: (Array.isArray(p.reviews) ? p.reviews : []).filter((r) => r && Number(r.stars) >= 1)
        .map((r) => ({ name: String(r.name || ''), stars: Math.min(5, Math.round(Number(r.stars))), text: String(r.text || '') })).slice(0, 10),
      benefits: (Array.isArray(p.benefits) ? p.benefits : []).map((d) => String(d).trim()).filter(Boolean).slice(0, 12),
      benefitsLocal: (Array.isArray(p.benefitsLocal) ? p.benefitsLocal : []).map((d) => String(d).trim()).filter(Boolean).slice(0, 12),
      howTo: (Array.isArray(p.howTo) ? p.howTo : []).map((d) => String(d).trim()).filter(Boolean).slice(0, 12),
      howToLocal: (Array.isArray(p.howToLocal) ? p.howToLocal : []).map((d) => String(d).trim()).filter(Boolean).slice(0, 12),
      tips: (Array.isArray(p.tips) ? p.tips : []).filter((x) => x && x.text).map((x) => ({ name: String(x.name || ''), text: String(x.text) })).slice(0, 20),
      bestseller: p.bestseller === true,
      isNew: p.isNew === true,
      inStock: p.inStock !== false,
      byWeight: p.byWeight === true && Number(p.pricePerKg) > 0,
      pricePerKg: Number(p.pricePerKg) > 0 ? Number(p.pricePerKg) : 0,
      offerPerKg: Number(p.offerPerKg) > 0 && Number(p.offerPerKg) < Number(p.pricePerKg) ? Number(p.offerPerKg) : 0,
      order: Number.isFinite(p.order) ? p.order : 999,
      packs: (Array.isArray(p.packs) ? p.packs : [])
        .filter((k) => k && k.label && Number(k.price) > 0)
        .map((k) => {
          // Every price is a whole rupee (halves round up), so what's shown
          // is exactly what goes into the order.
          const price = Math.round(Number(k.price));
          const offer = Math.round(Number(k.offerPrice));
          return { label: String(k.label), price, offerPrice: offer > 0 && offer < price ? offer : null, kg: Number(k.kg) > 0 ? Number(k.kg) : null, isDefault: k.isDefault === true };
        }),
    }))
    .filter((p) => p.packs.length && !hidden.has(p.category))
    .sort((a, b) => a.order - b.order || a.name.localeCompare(b.name));
  const categories = (Array.isArray(raw.categories) && raw.categories.length
    ? raw.categories.map(String)
    : [...new Set(products.map((p) => p.category))]).filter((c) => !hidden.has(c));
  const byId = new Map(products.map((p) => [p.id, p]));
  const combos = (Array.isArray(raw.combos) ? raw.combos : []).map((c) => {
    const items = (Array.isArray(c.items) ? c.items : [])
      .map((i) => ({ id: String(i.id || ''), qty: Number(i.qty) || 0, label: String(i.label || ''), name: String(i.name || ''), nameLocal: String(i.nameLocal || '') }))
      .filter((i) => i.qty > 0 && byId.has(i.id));
    const price = Math.round(Number(c.price) || 0);
    const normal = Math.round(Number(c.normal) || 0);
    return {
      id: String(c.id || ''), name: String(c.name || ''), nameLocal: String(c.nameLocal || ''), price, normal, weightKg: Number(c.weightKg) || 0,
      items, images: items.map((i) => byId.get(i.id).image).filter(Boolean).slice(0, 3),
      inStock: items.length >= 2 && items.every((i) => byId.get(i.id).inStock),
    };
  }).filter((c) => c.id && c.name && c.items.length >= 2 && c.price > 0);
  return { store, categories, categoriesLocal, products, combos, site: normSite(raw.site), updatedAt: raw.updatedAt || null };
}

function setCatalog(raw, persist) {
  const sig = JSON.stringify(raw);
  if (sig === state.rawSig) { renderUpdated(); return; }
  state.rawSig = sig;
  state.catalog = normalize(raw);
  if (persist) save(LS.catalog, raw);
  renderAll();
}

const unitPrice = (pack) => pack.offerPrice ?? pack.price;
const keyOf = (id, label) => `${id}::${label}`;
function lookup(key) {
  const [id, label] = key.split('::');
  if (id === 'combo') {
    const c = state.catalog?.combos?.find((x) => x.id === label);
    if (!c) return null;
    return {
      p: { id: `combo:${c.id}`, name: c.name, nameLocal: c.nameLocal, image: c.images[0] || '', inStock: c.inStock, packs: [], combo: c },
      pack: { label: comboList(c), price: c.normal > c.price ? c.normal : c.price, offerPrice: c.normal > c.price ? c.price : null },
    };
  }
  const p = state.catalog?.products.find((x) => x.id === id);
  const pack = p ? packByLabel(p, label) : null;
  return p && pack ? { p, pack } : null;
}
// Default to a pack with an offer, so deals are visible without an extra tap.
function selPack(p) {
  // The customer's pick, else the shop's default size (500 g), else an offer pack, else the first.
  return packByLabel(p, state.sel[p.id]) || p.packs.find((k) => k.isDefault) || p.packs.find((k) => k.offerPrice) || p.packs[0];
}
// Weight products: a custom amount like "2.5 kg" is priced per kg.
const round2 = (n) => Math.round(n * 100) / 100;
function fmtKg(kg) { return kg < 1 ? `${Math.round(kg * 1000)} g` : `${Number(kg.toFixed(3))} kg`; }
function weightPack(p, kg) {
  // Whole rupees only: what the customer sees is exactly what the order carries.
  const price = Math.round(p.pricePerKg * kg);
  const offer = p.offerPerKg ? Math.round(p.offerPerKg * kg) : null;
  return { label: fmtKg(kg), kg, price, offerPrice: offer && offer < price ? offer : null, custom: true };
}
function packByLabel(p, label) {
  if (!label) return null;
  const fixed = p.packs.find((k) => k.label === label);
  if (fixed) return fixed;
  if (!p.byWeight) return null;
  const m = /^(\d+(?:\.\d+)?)\s*(kg|g)$/.exec(label);
  if (!m) return null;
  const kg = Number(m[1]) * (m[2] === 'g' ? 0.001 : 1);
  return kg >= 0.1 && kg <= 100 ? weightPack(p, kg) : null;
}
const hasOffer = (p) => p.inStock && p.packs.some((k) => k.offerPrice);
function waNumber() {
  const n = String(state.catalog?.store.whatsapp || '').replace(/\D/g, '');
  return n.length >= 10 ? n : '';
}
function catLabel(c) {
  if (c === OFFERS) return t('offers');
  if (c === AGAIN) return t('orderAgain');
  if (c === BEST) return t('bestSellers');
  if (c === NEWS) return t('newArrivals');
  return (isTa() && state.catalog?.categoriesLocal?.[c]) || c;
}
function names(p) {
  if (isTa() && p.nameLocal) return { main: p.nameLocal, alt: p.name };
  return { main: p.name, alt: p.nameLocal };
}
function imgSrc(image) {
  if (!image) return '/images/placeholder.svg';
  if (isFsImage(image)) return photoCache.get(image) || '/images/placeholder.svg';
  return /^https?:\/\//i.test(image) ? image : `/images/products/${encodeURI(image)}`;
}

/* ---------- Cart ---------- */
function cartLines() {
  const lines = [];
  for (const [key, qty] of Object.entries(state.cart)) {
    const hit = lookup(key);
    if (!hit || qty <= 0) continue;
    const unit = unitPrice(hit.pack);
    lines.push({ key, p: hit.p, pack: hit.pack, qty, unit, line: unit * qty, ok: hit.p.inStock });
  }
  return lines;
}
function totals() {
  const lines = cartLines();
  const ok = lines.filter((l) => l.ok);
  return { lines, ok, count: ok.reduce((s, l) => s + l.qty, 0), total: ok.reduce((s, l) => s + l.line, 0) };
}
function setQty(key, qty) {
  if (qty > 0) state.cart[key] = Math.min(qty, 99);
  else delete state.cart[key];
  save(LS.cart, state.cart);
}
const itemsLabel = (n) => (n === 1 ? t('item') : t('items', { n }));

/* ---------- Rendering ---------- */
function applyStatic() {
  document.documentElement.lang = state.lang;
  $$('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  $$('[data-i18n-ph]').forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
  $$('[data-act="lang"]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.lang === state.lang)));
  updateNet();
}

function renderStore() {
  const s = state.catalog.store;
  const name = (isTa() && s.nameLocal) || s.name;
  $('#brandName').textContent = name;
  $('#brandSub').textContent = s.tagline || '';
  $('#footName').textContent = name;
  $('#footAddr').textContent = s.pickupAddress || '';
  document.title = `${s.name} | Order online`;
  const wa = $('#footWa');
  const num = waNumber();
  wa.hidden = !num;
  if (num) wa.href = `https://wa.me/${num}`;
}

// Sections in page order: Offers (if any), then each visible category.
// Hidden categories were already removed in normalize(), so they vanish
// from the tiles, the header chips and the product list together.
function sections() {
  const { products, categories } = state.catalog;
  const byStock = (a, b) => Number(b.inStock) - Number(a.inStock);
  const list = [];
  const again = orderAgainItems();
  if (again.length) list.push({ key: AGAIN, items: again });
  const offers = products.filter(hasOffer);
  if (offers.length) list.push({ key: OFFERS, items: offers });
  const best = products.filter((p) => p.bestseller && p.inStock);
  if (best.length) list.push({ key: BEST, items: best });
  const fresh = products.filter((p) => p.isNew && p.inStock);
  if (fresh.length) list.push({ key: NEWS, items: fresh });
  for (const c of categories) {
    const items = products.filter((p) => p.category === c).sort(byStock);
    if (items.length) list.push({ key: c, items });
  }
  return list.map((x) => (x.key === AGAIN ? x : { ...x, items: sortItems(x.items) }));
}
// Customer's choice, else the shop's default (set in the app), else "Recommended".
function currentSort() { return state.sort || state.catalog?.site?.defaultSort || 'recommended'; }
function sortItems(items) {
  const mode = currentSort();
  const stock = (a, b) => Number(b.inStock) - Number(a.inStock);
  const price = (p) => unitPrice(selPack(p));
  const cmp = {
    price_asc: (a, b) => price(a) - price(b),
    price_desc: (a, b) => price(b) - price(a),
    name: (a, b) => names(a).main.localeCompare(names(b).main),
    best: (a, b) => Number(b.bestseller) - Number(a.bestseller) || a.order - b.order,
  }[mode];
  return cmp ? [...items].sort((a, b) => stock(a, b) || cmp(a, b)) : items;
}
function sortBar() {
  const opts = [['recommended', 'sortRec'], ['price_asc', 'sortPriceUp'], ['price_desc', 'sortPriceDown'], ['name', 'sortName'], ['best', 'sortBest']];
  return `<div class="sortbar"><label for="sortSel">${esc(t('sortBy'))}</label><select id="sortSel">${opts.map(([v, k]) =>
    `<option value="${v}"${v === currentSort() ? ' selected' : ''}>${esc(t(k))}</option>`).join('')}</select></div>`;
}
const slug = (key) => `sec-${key.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}`;

function renderCats() {
  const secs = sections();
  if (!secs.some((x) => x.key === state.active)) state.active = secs[0]?.key || '';
  const cur = (k) => String(k === state.active);
  $('#cats').innerHTML = secs.map((x, i) =>
    `<button type="button" class="tile" data-act="cat" data-cat="${esc(x.key)}" data-tone="${i % 5}" aria-current="${cur(x.key)}">
      <span class="tile-i${catPhoto(x.key) ? ' has-photo' : ''}">${catThumb(x.key, 30)}</span>
      <span class="tile-l">${esc(catLabel(x.key))}</span><span class="tile-n">${x.items.length}</span></button>`).join('');
  $('#catChips').innerHTML = secs.map((x, i) =>
    `<button type="button" class="chip" data-act="cat" data-cat="${esc(x.key)}" data-tone="${i % 5}" aria-current="${cur(x.key)}">${svg(catIcon(x.key), 16)}${esc(catLabel(x.key))}</button>`).join('');
  $('#cats').hidden = Boolean(state.q.trim()) || !secs.length;
  hydratePhotos($('#cats')); // category photos from the app (was never loaded here)
}

function markActive(key) {
  if (!key || key === state.active) return;
  state.active = key;
  $$('[data-act="cat"]').forEach((b) => b.setAttribute('aria-current', String(b.dataset.cat === key)));
  // Scroll ONLY the chip bar sideways — scrollIntoView could also nudge the
  // page and interrupt the customer's own scrolling (felt as a stutter).
  const bar = $('#catChips');
  const chip = bar?.querySelector(`[data-cat="${CSS.escape(key)}"]`);
  if (bar && chip && bar.offsetParent) {
    bar.scrollTo({ left: chip.offsetLeft - (bar.clientWidth - chip.offsetWidth) / 2, behavior: 'smooth' });
  }
}

function stepper(key, qty, name) {
  return `<div class="step" role="group" aria-label="${esc(t('qtyOf', { name }))}">`
    + `<button type="button" data-act="dec" data-key="${esc(key)}" aria-label="${esc(t('removeOne'))}">−</button>`
    + `<output aria-live="polite">${qty}</output>`
    + `<button type="button" data-act="inc" data-key="${esc(key)}" aria-label="${esc(t('addOne'))}">+</button></div>`;
}

function cardHTML(p) {
  const pack = selPack(p);
  const key = keyOf(p.id, pack.label);
  const qty = state.cart[key] || 0;
  const n = names(p);
  const pct = pack.offerPrice ? Math.round(((pack.price - pack.offerPrice) / pack.price) * 100) : 0;
  const tag = !p.inStock
    ? `<span class="tag tag-out">${esc(t('outOfStock'))}</span>`
    : (pct > 0 ? `<span class="tag tag-off">${esc(t('pctOff', { pct }))}</span>` : '');
  // Home cards stay simple: one size until the product is in the cart,
  // then every size (and Custom) appears to adjust.
  const inCart = Object.keys(state.cart).some((k) => k.startsWith(`${p.id}::`));
  const packs = (p.packs.length > 1 || p.byWeight) && inCart
    ? `<div class="packs" role="group" aria-label="${esc(t('packSize'))}">${p.packs.map((k) =>
      `<button type="button" class="pack" data-act="pack" data-id="${esc(p.id)}" data-label="${esc(k.label)}" aria-pressed="${k.label === pack.label}">${esc(k.label)}</button>`).join('')}${customChip(p, pack)}</div>`
    : `<p class="pack-one">${esc(pack.label)}</p>`;
  const price = `<p class="price"><span class="now">${money(unitPrice(pack))}</span>${pack.offerPrice ? `<s>${money(pack.price)}</s>` : ''}</p>${metaHTML(pack)}`;
  let action;
  if (!p.inStock) {
    action = `<p class="out">${esc(t('outOfStock'))}</p>`;
    if (PUSH_VAPID_KEY && 'Notification' in window && !(isIOS() && !isStandalone())) {
      action += load(LS.stockAlerts, []).includes(p.id)
        ? `<p class="alerts-on stock-on">${esc(t('stockNotifyOn'))}</p>`
        : `<button type="button" class="btn ghost small stock-btn" data-act="stockAlert" data-id="${esc(p.id)}">${esc(t('stockNotify'))}</button>`;
    }
  }
  else if (!qty) action = `<button type="button" class="add" data-act="add" data-key="${esc(key)}">${esc(t('add'))}</button>`;
  else action = stepper(key, qty, n.main);
  return `<article class="card${p.inStock ? '' : ' is-out'}" data-id="${esc(p.id)}">
  <div class="ph" data-act="view" data-id="${esc(p.id)}"><img src="${esc(imgSrc(p.image))}"${isFsImage(p.image) ? ` data-fs="${esc(p.image)}"${photoCache.has(p.image) ? ' data-loaded="1"' : ''}` : ''} alt="" loading="lazy" decoding="async" width="400" height="400">${tag}${badges(p)}</div>
  <div class="card-b"><h3 class="clamp2"><button type="button" class="pname" data-act="view" data-id="${esc(p.id)}" aria-label="${esc(t('viewProduct', { name: n.main }))}">${esc(n.main)}</button></h3>${p.rating ? `<p class="rating">★ ${p.rating.avg.toFixed(1)} <span>(${p.rating.count})</span></p>` : ''}<p class="alt"${isTa() ? '' : ' lang="ta"'}>${esc(n.alt || '')}</p>${packs}<div class="buy">${price}<div class="act-row">${action}</div></div></div>
</article>`;
}

function sectionHTML(key, items, tone, title) {
  // Sub-categories (e.g. Whole grains / Flours) become filter chips when a
  // category has two or more of them.
  const subs = [...new Map(items.filter((p) => p.subcategory).map((p) => [p.subcategory, p])).values()];
  let chips = '';
  if (subs.length >= 2) {
    const cur = state.sub?.[key] || '';
    if (cur) items = items.filter((p) => p.subcategory === cur);
    const chip = (v, label) => `<button type="button" class="subchip" data-act="sub" data-cat="${esc(key)}" data-sub="${esc(v)}" aria-pressed="${cur === v}">${esc(label)}</button>`;
    chips = `<div class="subchips" role="group">${chip('', t('subAll'))}${subs.map((p) => chip(p.subcategory, (isTa() && p.subcategoryLocal) || p.subcategory)).join('')}</div>`;
  }
  const count = items.length === 1 ? t('oneProduct') : t('nProducts', { n: items.length });
  return `<section class="sec" id="${slug(key)}" data-cat="${esc(key)}" data-tone="${tone}">
    <div class="sec-head"><span class="sec-i">${svg(key === '__search' ? ICONS.search : catIcon(key), 20)}</span><h2>${esc(title)}</h2><span class="sec-n">${esc(count)}</span></div>${chips}
    <div class="grid">${items.map(cardHTML).join('')}</div></section>`;
}

function renderSkeleton() {
  $('#catalog').innerHTML = `<div class="grid">${Array.from({ length: 8 }, () =>
    '<div class="skel" aria-hidden="true"><div class="s-img"></div><div class="s-l"></div><div class="s-l short"></div></div>').join('')}</div>`;
}

function renderCatalog() {
  const el = $('#catalog');
  if (!state.catalog.products.length) {
    el.innerHTML = `<p class="empty">${esc(t('noProducts'))}</p>`;
    return;
  }
  const q = state.q.trim().toLowerCase();
  if (q) {
    const local = state.catalog.categoriesLocal;
    const hits = state.catalog.products
      .filter((p) => `${p.name} ${p.nameLocal} ${p.category} ${local[p.category] || ''}`.toLowerCase().includes(q))
      .sort((a, b) => Number(b.inStock) - Number(a.inStock));
    el.innerHTML = hits.length
      ? sectionHTML('__search', hits, 0, t('searchResults'))
      : `<div class="empty"><p>${esc(t('noMatch', { q: state.q }))}</p>
        <button type="button" class="btn primary" data-act="feedback" data-q="${esc(state.q.trim())}">${esc(t('fbAsk'))}</button></div>`;
    return;
  }
  el.innerHTML = comboSectionHTML() + sortBar() + sections().map((x, i) => sectionHTML(x.key, x.items, i % 5, catLabel(x.key))).join('');
}

// A product can appear twice (in Offers and its own category), so every
// copy of the card is refreshed.
function refreshCard(id, focusSel, focusIn) {
  if (id === 'combo') {
    const sec = $('#comboSec');
    if (!sec) return;
    const holder = document.createElement('div');
    holder.innerHTML = comboSectionHTML();
    if (holder.firstElementChild) { sec.replaceWith(holder.firstElementChild); hydratePhotos($('#comboSec')); }
    return;
  }
  const p = state.catalog.products.find((x) => x.id === id);
  if (!p) return;
  const html = cardHTML(p);
  $$(`.card[data-id="${CSS.escape(id)}"]`).forEach((el) => {
    const wasTarget = focusIn && el.contains(focusIn);
    const holder = document.createElement('div');
    holder.innerHTML = html;
    const fresh = holder.firstElementChild;
    el.replaceWith(fresh);
    if (wasTarget && focusSel) ($(focusSel, fresh) || $('[data-act="add"], [data-act="inc"]', fresh))?.focus();
  });
}

function renderCartBar() {
  const navCount = $('#navCount');
  if (navCount) { const c = totals().count; navCount.textContent = String(c); navCount.hidden = !c; }
  const { count, total } = totals();
  $('#cartbar').hidden = count === 0;
  document.body.classList.toggle('has-cart', count > 0);
  const badge = $('#cartCount');
  badge.hidden = count === 0;
  badge.textContent = count > 99 ? '99+' : String(count);
  if (count) {
    $('#cartSummary').innerHTML = `<span class="cb-count">${esc(itemsLabel(count))}</span><span class="cb-total">${money(total)}</span>`;
  }
  $('#ordersDot').hidden = !load(LS.orders, []).some((o) => o.state === 'pending' || o.state === 'failed');
}

function renderUpdated() {
  const show = Boolean(state.catalog) && (!navigator.onLine || state.fromCache) && LIVE;
  const el = $('#cached');
  el.hidden = !show;
  el.textContent = show ? t('savedCopy') : '';
}

function renderAll() {
  renderSite();
  if (!state.catalog) return;
  renderStore();
  renderCats();
  renderCatalog();
  renderCartBar();
  renderUpdated();
  measureHead();
  if (state.view && state.view.name !== 'checkout') renderSheet();
}

function showError(msg) { $('#catalog').innerHTML = `<p class="empty">${esc(msg)}</p>`; }

/* ---------- Scrolling: header height, category jump, active tracking ---------- */
// The chip bar now floats under the header (it no longer makes the header
// taller), so the page never shifts; its height only adjusts where
// "jump to category" lands.
function headLine() {
  const bar = $('#catChips');
  const barH = document.body.classList.contains('cats-away') && bar && bar.offsetParent ? bar.offsetHeight : 0;
  return $('#head').offsetHeight + barH;
}
function measureHead() {
  document.documentElement.style.setProperty('--head-h', `${headLine()}px`);
}
function scrollToSection(key) {
  const sec = document.getElementById(slug(key));
  if (!sec) return;
  markActive(key);
  const smooth = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  sec.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto', block: 'start' });
}
let spyTicking = false;
function onScroll() {
  if (spyTicking) return;
  spyTicking = true;
  requestAnimationFrame(() => {
    spyTicking = false;
    if (state.q.trim()) return;
    const line = headLine() + 24;
    let current = '';
    for (const sec of $$('#catalog .sec')) {
      if (sec.getBoundingClientRect().top <= line) current = sec.dataset.cat;
      else break;
    }
    markActive(current || $('#catalog .sec')?.dataset.cat);
  });
}
function watchTiles() {
  // When the category tiles scroll out of view, show compact chips in the header.
  if (!('IntersectionObserver' in window)) return;
  const io = new IntersectionObserver(([entry]) => {
    const away = !entry.isIntersecting && entry.boundingClientRect.top < 0;
    if (document.body.classList.contains('cats-away') !== away) {
      document.body.classList.toggle('cats-away', away);
      measureHead();
    }
  }, { threshold: 0 });
  io.observe($('#cats'));
}

/* ---------- Sheet views ---------- */
function field(id, label, control, error) {
  return `<div class="field${error ? ' has-err' : ''}"><label for="f-${id}">${esc(label)}</label>${control}${error ? `<p class="err">${esc(error)}</p>` : ''}</div>`;
}
function radio(name, value, label, current) {
  return `<label class="opt"><input type="radio" name="${name}" value="${value}"${value === current ? ' checked' : ''}><span>${esc(label)}</span></label>`;
}
const CHECK_ICON = '<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';

const VIEWS = {
  product(v) {
    const p = state.catalog.products.find((x) => x.id === v.id);
    if (!p) return [t('details'), `<p class="empty">${esc(t('noProducts'))}</p>`];
    const n = names(p);
    const pack = selPack(p);
    const key = keyOf(p.id, pack.label);
    const qty = state.cart[key] || 0;
    const desc = loc(p.description, p.descriptionLocal);
    const packs = p.packs.length > 1 || p.byWeight
      ? `<div class="packs" role="group" aria-label="${esc(t('packSize'))}">${p.packs.map((k) =>
        `<button type="button" class="pack" data-act="pack" data-id="${esc(p.id)}" data-label="${esc(k.label)}" aria-pressed="${k.label === pack.label}">${esc(k.label)}</button>`).join('')}${customChip(p, pack)}</div>`
      : `<p class="pack-one">${esc(pack.label)}</p>`;
    let action;
    if (!p.inStock) action = `<p class="out">${esc(t('outOfStock'))}</p>`;
    else if (!qty) action = `<button type="button" class="add" data-act="add" data-key="${esc(key)}">${esc(t('add'))}</button>`;
    else action = stepper(key, qty, n.main);
    const related = state.catalog.products.filter((x) => x.category === p.category && x.id !== p.id && x.inStock).slice(0, 4);
    const num = waNumber();
    const wa = num ? `https://wa.me/${num}?text=${encodeURIComponent(t('waAsk', { name: n.main }))}` : '';
    return [n.main, `<article class="pv">
      <div class="pv-ph">${imgTag(p.image, n.main)}${badges(p)}</div>
      ${n.alt ? `<p class="alt pv-alt">${esc(n.alt)}</p>` : ''}
      ${packs}
      <div class="buy pv-buy"><p class="price"><span class="now">${money(unitPrice(pack))}</span>${pack.offerPrice ? `<s>${money(pack.price)}</s>` : ''}</p>${metaHTML(pack)}${action}</div>
      ${pvTabs(p, desc)}
      ${wa ? `<a class="btn wa pv-wa" href="${wa}" target="_blank" rel="noopener">${esc(t('askWa'))}</a>` : ''}
      ${related.length ? `<h3 class="pv-h">${esc(t('related'))}</h3><div class="pv-rel">${related.map((r) =>
        `<button type="button" class="rel" data-act="view" data-id="${esc(r.id)}">${imgTag(r.image, '')}<span class="rel-n">${esc(names(r).main)}</span><span class="rel-p">${money(unitPrice(selPack(r)))}</span></button>`).join('')}</div>` : ''}
    </article>`];
  },
  feedback(v) {
    const c = load(LS.customer, {});
    const q = v.q || '';
    return [t('fbTitle'), `<form class="fb-form" id="fbForm" data-q="${esc(q)}">
      <label for="fbText">${esc(t('fbText'))}</label>
      <textarea id="fbText" name="text" rows="4" maxlength="500" required>${esc(q ? `${q} — ` : '')}</textarea>
      <input name="name" maxlength="40" placeholder="${esc(t('fbName'))}" value="${esc(c.name || '')}">
      <input name="phone" inputmode="numeric" maxlength="10" placeholder="${esc(t('fbPhone'))}" value="${esc(c.phone || '')}">
      <button type="submit" class="btn primary">${esc(t('fbSend'))}</button>
    </form>`];
  },
  kg(v) {
    const p = state.catalog.products.find((x) => x.id === v.id);
    if (!p) return [t('customTitle'), ''];
    const cur = selPack(p);
    return [t('customTitle'), `<form class="kg-form" id="kgForm" data-id="${esc(p.id)}">
      <p class="kg-name">${esc(names(p).main)} · ₹${p.offerPerKg || p.pricePerKg}/kg</p>
      <label for="kgIn">${esc(t('kgLabel'))}</label>
      <input id="kgIn" name="kg" type="number" inputmode="decimal" step="0.1" min="0.1" max="100" required value="${cur.kg && cur.custom ? cur.kg : ''}" placeholder="2.5">
      <p class="kg-hint">${esc(t('kgHint'))}</p>
      <button type="submit" class="btn primary">${esc(t('kgAdd'))}</button>
    </form>`];
  },
  learn() {
    const items = state.catalog.products.filter((p) => p.benefits.length || p.benefitsLocal.length);
    const list = items.map((p) => {
      const b = (isTa() && p.benefitsLocal.length ? p.benefitsLocal : p.benefits).slice(0, 2);
      return `<button type="button" class="learn-row" data-act="viewtab" data-id="${esc(p.id)}" data-tab="benefits">
        <span class="learn-ph">${imgTag(p.image, '')}</span>
        <span class="learn-t"><strong>${esc(names(p).main)}</strong>${b.map((x) => `<span>${esc(x)}</span>`).join('')}<em>${esc(t('readMore'))}</em></span></button>`;
    }).join('');
    return [t('learnTitle'), `<p class="learn-intro">${esc(t('learnIntro'))}</p>${list || `<p class="empty">${esc(t('noInfo'))}</p>`}<p class="health-note">${esc(t('healthNote'))}</p>`];
  },
  cats() {
    return [t('navCats'), `<div class="cat-list">${sections().map((x) =>
      `<button type="button" class="cat-row" data-act="catgo" data-cat="${esc(x.key)}"><span class="tile-i${catPhoto(x.key) ? ' has-photo' : ''}">${catThumb(x.key, 24)}</span><span class="cat-row-l">${esc(catLabel(x.key))}</span><span class="tile-n">${x.items.length}</span></button>`).join('')}</div>`];
  },
  cart() {
    const { lines, ok, total } = totals();
    const saved = ok.reduce((s, l) => s + (l.pack.offerPrice ? (l.pack.price - l.pack.offerPrice) * l.qty : 0), 0);
    const min = Number(state.catalog.store.minOrder) || 0;
    if (!lines.length) {
      return [t('cart'), `<p class="empty">${esc(t('emptyCart'))}</p><button type="button" class="btn ghost" data-act="close">${esc(t('browse'))}</button>`];
    }
    const rows = lines.map((l) => {
      const n = names(l.p);
      return `<li class="line${l.ok ? '' : ' is-out'}">
      <div class="line-t"><p class="line-n">${esc(n.main)}</p><p class="line-m">${esc(l.pack.label)}, ${esc(t('each', { price: money(l.unit) }))}${l.ok ? '' : `. ${esc(t('nowOut'))}`}</p></div>
      ${stepper(l.key, l.qty, n.main)}<p class="line-p">${l.ok ? money(l.line) : ''}</p></li>`;
    }).join('');
    const short = min > 0 && total < min;
    return [t('cart'), `<ul class="lines">${rows}</ul>
      ${saved > 0 ? `<p class="saved">${esc(t('savedTotal', { amt: money(saved) }))}</p>` : ''}
      <div class="sum"><span>${esc(t('total'))}</span><strong>${money(total)}</strong></div>
      <p class="hint">${esc(t('deliveryNote'))}</p>
      ${short ? `<p class="warn">${esc(t('minOrder', { min: money(min), more: money(min - total) }))}</p>` : ''}
      <button type="button" class="btn primary" data-act="checkout"${short || !ok.length ? ' disabled' : ''}>${esc(t('toCheckout'))}</button>`];
  },

  checkout(v) {
    const s = state.catalog.store;
    const c = { ...load(LS.customer, {}), ...(v.draft || {}) };
    const err = v.errors || {};
    const { total, count } = totals();
    const mode = c.fulfilment === 'pickup' ? 'pickup' : 'delivery';
    const pay = c.payment === 'upi' ? 'upi' : 'cod';
    const areas = Array.isArray(s.deliveryAreas) ? s.deliveryAreas : [];
    const areaField = areas.length
      ? field('area', t('area'), `<select id="f-area" name="area"><option value="">${esc(t('chooseArea'))}</option>${areas.map((a) =>
        `<option value="${esc(a)}"${a === c.area ? ' selected' : ''}>${esc(a)}</option>`).join('')}<option value="Other area"${c.area === 'Other area' ? ' selected' : ''}>${esc(t('otherArea'))}</option></select>`, err.area)
      : '';
    return [t('checkout'), `<form id="co" class="co" novalidate data-mode="${mode}" data-pay="${pay}">
      ${field('name', t('yourName'), `<input id="f-name" name="name" autocomplete="name" maxlength="60" value="${esc(c.name || '')}">`, err.name)}
      ${field('phone', t('mobile'), `<input id="f-phone" name="phone" type="tel" inputmode="numeric" autocomplete="tel-national" maxlength="14" placeholder="${esc(t('mobilePh'))}" value="${esc(c.phone || '')}">`, err.phone)}
      <fieldset class="seg"><legend class="group-label">${esc(t('howGet'))}</legend>
        <div class="seg-opts">${radio('fulfilment', 'delivery', t('delivery'), mode)}${radio('fulfilment', 'pickup', t('pickup'), mode)}</div></fieldset>
      <p class="hint only-pickup">${esc(s.pickupAddress || t('pickupFallback'))}</p>
      <div class="only-delivery">${areaField}
        ${field('address', t('addrLine'), `<input id="f-address" name="address" maxlength="150" autocomplete="address-line1" value="${esc(c.address || '')}">`, err.address)}
        ${field('landmark', t('landmark'), `<input id="f-landmark" name="landmark" maxlength="80" value="${esc(c.landmark || '')}">`)}
        <div class="row2">${field('city', t('city'), `<input id="f-city" name="city" maxlength="60" autocomplete="address-level2" value="${esc(c.city || '')}">`, err.city)}
        ${field('pincode', t('pincode'), `<input id="f-pincode" name="pincode" inputmode="numeric" maxlength="6" autocomplete="postal-code" value="${esc(c.pincode || '')}">`, err.pincode)}</div></div>
      <fieldset class="seg"><legend class="group-label">${esc(t('payment'))}</legend>
        <input type="hidden" name="payment" value="upi"><p class="pay-info">${esc(t('payInfo'))}</p></fieldset>
      <p class="hint only-upi">${esc(t('upiHint'))}</p>
      ${field('note', t('note'), `<textarea id="f-note" name="note" rows="2" maxlength="300">${esc(c.note || '')}</textarea>`)}
      <div id="coCharges">${chargeRows(total, mode === 'delivery', c.pincode)}</div>
      <button type="submit" class="btn primary">${esc(t('reviewOrder'))}</button>
      <p class="hint">${esc(t('placeHint'))}</p>
    </form>`];
  },

  confirm(v) {
    const d = v.draft;
    const { total } = totals();
    const delivery = d.fulfilment !== 'pickup';
    return [t('confirmTitle'), `<div class="confirm">
      <p class="group-label">${esc(delivery ? t('confirmAddr') : t('confirmPickup'))}</p>
      <div class="addr-card"><strong>${esc(d.name)}</strong> · ${esc(d.phone)}<br>${esc(delivery ? fullAddress(d) : (state.catalog.store.pickupAddress || ''))}</div>
      ${delivery ? `<p class="confirm-q">${esc(t('confirmQ'))}</p>` : ''}
      ${chargeRows(total, delivery, d.pincode)}
      ${payFirstHTML(d, total + (deliveryChargeFor(total, delivery, d.pincode) || 0))}
      ${pushPossible() ? `<label class="notify-opt"><input type="checkbox" id="notifyOpt"${d.notify === false ? '' : ' checked'}> <span>${esc(t('notifyOpt'))}</span></label>` : ''}
      <button type="button" class="btn primary" data-act="confirmOrder"${needsProof() && !payingOnWa(d) && !d.proof ? ' aria-disabled="true"' : ''}>${esc(payingOnWa(d) ? t('placeAndWa') : needsProof() ? t('placeOrder2') : t('confirmYes'))}</button>
      <button type="button" class="btn ghost" data-act="editOrder">${esc(t('confirmEdit'))}</button>
    </div>`];
  },
  done(v) {
    const o = load(LS.orders, []).find((x) => x.orderNo === v.orderNo);
    if (!o) return [t('orderPlaced'), `<button type="button" class="btn ghost" data-act="close">${esc(t('continueShopping'))}</button>`];
    const s = state.catalog.store;
    const num = waNumber();
    const waFallback = o.state === 'failed' && num
      ? `<a class="btn wa" href="https://wa.me/${num}?text=${encodeURIComponent(o.text)}" target="_blank" rel="noopener">${esc(t('sendWa'))}</a>`
      : '';
    // Direct UPI: opens GPay / PhonePe / Paytm with the shop's UPI ID, the
    // exact amount and the order number filled in. Money goes straight to
    // the shop; the customer sends the screenshot so the shop can confirm.
    const amt = Math.round(Number(o.total) || 0);
    const paidText = t('paidMsg', { amt: money(amt), no: o.orderNo });
    const shot = num ? `<a class="btn wa" href="https://wa.me/${num}?text=${encodeURIComponent(paidText)}" target="_blank" rel="noopener">${esc(t('sendShot'))}</a>` : '';
    const upi = s.upiId
      ? `<div class="upi">
        <a class="btn primary pay-now" href="upi://pay?pa=${encodeURIComponent(s.upiId)}&pn=${encodeURIComponent(s.name)}&am=${amt}.00&cu=INR&tn=${encodeURIComponent(`Order ${o.orderNo}`)}">${esc(t('payNow', { amt: money(amt) }))}</a>
        <p>${esc(t('upiId'))}: <strong>${esc(s.upiId)}</strong> <button type="button" class="linkish" data-act="copy" data-text="${esc(s.upiId)}">${esc(t('copyUpi'))}</button></p>
        <p class="hint">${esc(t('payAfter'))}</p>
        ${shot}</div>`
      : `<p class="hint">${esc(t('payLater'))}</p>`;
    return [t('orderPlaced'), `<div class="done">
      <div class="done-icon">${CHECK_ICON}</div>
      <p class="done-no">${esc(o.orderNo)}</p>
      <p class="done-t">${money(o.total)}, ${esc(itemsLabel(o.itemCount))}</p>
      <p class="badge b-${o.state}">${esc(t(`st_${o.state}`))}</p>
      ${o.payVia === 'whatsapp' && num
        ? `<p class="proof-sent">${esc(t('waPayDone'))}</p><a class="btn wa" href="https://wa.me/${num}?text=${encodeURIComponent(t('waPayMsg', { no: o.orderNo, amt: money(o.total) }))}" target="_blank" rel="noopener">${esc(t('openChat'))}</a>`
        : o.proof ? `<p class="proof-sent">${esc(t('proofSent'))}</p>` : upi}
      ${orderUpdatesHTML(o.orderNo)}
      ${alertsCardHTML()}
      <button type="button" class="btn ghost" data-act="track" data-no="${esc(o.orderNo)}">${esc(t('trackBtn'))}</button>
      <p>${esc(t('shopWillConfirm'))}</p>
      ${waFallback}
      <button type="button" class="btn ghost" data-act="copy" data-text="${esc(o.text)}">${esc(t('copyDetails'))}</button>
      <button type="button" class="btn ghost" data-act="close">${esc(t('continueShopping'))}</button></div>`];
  },

  track(v) {
    const no = v.no;
    const r = state.track?.[no];
    if (!r) { loadTrack(no); return [t('trackTitle', { no }), `<p class="empty">${esc(t('trackLoading'))}</p>`]; }
    if (r.missing) return [t('trackTitle', { no }), `<p class="empty">${esc(r.offline ? t('trackOffline') : t('trackNotFound'))}</p>
      <button type="button" class="btn ghost" data-act="trackRefresh" data-no="${esc(no)}">${esc(t('trackRefresh'))}</button>`];
    const order = ['requested', 'confirmed', 'dispatched', 'delivered'];
    const status = r.status === 'paid' ? 'delivered' : r.status;
    const at = order.indexOf(status);
    const h = r.history || {};
    const when = (x) => (x ? new Date(x).toLocaleString(isTa() ? 'ta-IN' : 'en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }) : '');
    const steps = status === 'cancelled'
      ? `<li class="tl done cancel"><span class="tl-dot"></span><div><strong>${esc(t('st_cancelled'))}</strong><small>${esc(when(h.cancelled))}</small></div></li>`
      : order.filter((k) => k !== 'dispatched' || r.fulfilment !== 'pickup').map((k) => {
        const i = order.indexOf(k);
        return `<li class="tl ${i <= at ? 'done' : ''} ${i === at ? 'now' : ''}"><span class="tl-dot"></span><div><strong>${esc(t(`st_${k}`))}</strong><small>${esc(when(h[k]))}</small></div></li>`;
      }).join('');
    const courier = r.courier || r.trackingNo
      ? `<div class="courier"><p>${esc(t('courierL'))}: <strong>${esc(r.courier || '—')}</strong></p>
        ${r.trackingNo ? `<p>${esc(t('trackNoL'))}: <strong>${esc(r.trackingNo)}</strong> <button type="button" class="linkish" data-act="copy" data-text="${esc(r.trackingNo)}">${esc(t('copyShort'))}</button></p>` : ''}
        ${/^https:\/\//.test(r.trackingUrl || '') ? `<a class="btn ghost" href="${esc(r.trackingUrl)}" target="_blank" rel="noopener">${esc(t('trackParcel'))}</a>` : ''}</div>`
      : '';
    return [t('trackTitle', { no }), `<ol class="timeline">${steps}</ol>${courier}
      <p class="hint">${esc(t('updatedL', { when: when(r.updatedAt) }))}</p>
      ${reviewFormHTML(no)}
      <button type="button" class="btn ghost" data-act="trackRefresh" data-no="${esc(no)}">${esc(t('trackRefresh'))}</button>`];
  },
  orders() {
    const list = load(LS.orders, []);
    if (!list.length) return [t('yourOrders'), `<p class="empty">${esc(t('noOrders'))}</p>`];
    const itemRows = (o) => (Array.isArray(o.items) && o.items.length
      ? o.items.map((it) => `<li><span>${esc(it.name)} (${esc(it.pack)}) × ${it.qty}</span><span>${money(it.lineTotal)}</span></li>`).join('')
      : `<li><span>${esc(itemsLabel(o.itemCount))}</span></li>`);
    return [t('yourOrders'), `<p class="hint">${esc(t('ordersHint'))}</p>
      <ul class="olist">${list.map((o) => `<li class="ocard">
        <div class="ocard-top"><span class="ocard-i">${svg(ICONS.receipt, 18)}</span>
          <p class="ocard-no">${esc(o.orderNo)}</p><span class="badge b-${o.state}">${esc(t(`ss_${o.state}`))}</span></div>
        <ul class="ocard-items">${itemRows(o)}</ul>
        <div class="ocard-foot"><span class="ocard-total">${money(o.total)}</span>
          <button type="button" class="btn small" data-act="track" data-no="${esc(o.orderNo)}">${esc(t('trackBtn'))}</button>
          <button type="button" class="btn small ghost" data-act="copy" data-text="${esc(o.text)}">${esc(t('copyShort'))}</button></div>
      </li>`).join('')}</ul>`];
  },
};

let lastFocus = null;
function renderSheet(resetScroll = false) {
  if (!state.view || !state.catalog) return;
  const body = $('#sheetBody');
  const top = body.scrollTop;
  const [title, html] = VIEWS[state.view.name](state.view);
  $('#sheetTitle').textContent = title;
  body.innerHTML = html;
  body.scrollTop = resetScroll ? 0 : top;
  hydratePhotos(body);
}
function openSheet(view) {
  if (!state.catalog) return;
  lastFocus = document.activeElement;
  state.view = view;
  renderSheet(true);
  $('#scrim').hidden = false;
  const sheet = $('#sheet');
  sheet.hidden = false;
  requestAnimationFrame(() => sheet.classList.add('open'));
  document.body.classList.add('lock');
  $('#closeSheet').focus();
}
function closeSheet() {
  state.view = null;
  const sheet = $('#sheet');
  sheet.classList.remove('open');
  sheet.hidden = true;
  $('#scrim').hidden = true;
  document.body.classList.remove('lock');
  if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
  if (pendingUpdate) { pendingUpdate = false; applyUpdate(); }
}

/* ---------- Orders ---------- */
function makeOrderNo() {
  const d = new Date();
  const mmdd = `${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const rnd = crypto.getRandomValues(new Uint8Array(4));
  return `${ORDER_PREFIX}-${mmdd}-${Array.from(rnd, (b) => A[b % A.length]).join('')}`;
}

// Plain-text summary for "Copy order details" and the WhatsApp fallback.
function orderSummaryText(o, s) {
  const items = o.items.map((it, i) => `${i + 1}. ${it.name} (${it.pack}) x ${it.qty} = ${money(it.lineTotal)}`);
  const where = o.fulfilment === 'pickup'
    ? 'Pick up from shop'
    : `Delivery: ${fullAddress(o.customer)}`;
  return [
    `Order ${o.orderNo}`, s.name, '', ...items, '',
    `Items: ${money(o.itemsTotal ?? o.total)}`,
    ...(o.fulfilment !== 'pickup' ? [`Delivery charge: ${o.deliveryCharge ? money(o.deliveryCharge) : 'Free'}`] : []),
    `Total: ${money(o.total)}`, '',
    `Name: ${o.customer.name}`, `Phone: ${o.customer.phone}`, where,
    `Payment: ${o.payment === 'upi' ? 'UPI' : 'Cash on delivery'}`,
    ...(o.note ? [`Note: ${o.note}`] : []),
  ].join('\n');
}

function submitCheckout(form) {
  const d = Object.fromEntries(new FormData(form).entries());
  d.phone = String(d.phone || '').replace(/\D/g, '').replace(/^(91|0)(?=\d{10}$)/, '');
  const areas = state.catalog.store.deliveryAreas || [];
  const errors = {};
  if (!String(d.name || '').trim()) errors.name = t('errName');
  if (!/^\d{10}$/.test(d.phone)) errors.phone = t('errPhone');
  if (d.fulfilment !== 'pickup') {
    if (!String(d.address || '').trim()) errors.address = t('errAddress');
    if (areas.length && !d.area) errors.area = t('errArea');
    if (!String(d.city || '').trim()) errors.city = t('errCity');
    d.pincode = String(d.pincode || '').replace(/\D/g, '');
    if (!/^[1-9]\d{5}$/.test(d.pincode)) errors.pincode = t('errPin');
  }
  if (Object.keys(errors).length) {
    state.view = { name: 'checkout', draft: d, errors };
    renderSheet();
    $('#sheetBody .has-err input, #sheetBody .has-err select, #sheetBody .has-err textarea')?.focus();
    return;
  }
  save(LS.customer, {
    name: d.name.trim(), phone: d.phone, address: String(d.address || '').trim(),
    landmark: String(d.landmark || '').trim(), city: String(d.city || '').trim(), pincode: d.pincode || '',
    area: d.area || '', fulfilment: d.fulfilment, payment: d.payment,
  });
  // Show the address and charges once more before the order is placed.
  state.view = { name: 'confirm', draft: d };
  renderSheet(true);
}

function placeOrder(d) {
  const { ok, total, count } = totals();
  if (!ok.length) return;
  const s = state.catalog.store;
  const delivery = d.fulfilment !== 'pickup';
  const orderNo = d.orderNo || makeOrderNo();
  const data = {
    orderNo,
    items: ok.map((l) => ({ id: l.p.id, name: l.p.name, pack: l.pack.label, qty: l.qty, price: l.unit, lineTotal: l.line, ...(l.pack.kg ? { kg: l.pack.kg } : {}), ...(l.p.combo ? { combo: l.p.combo.items.map((i) => ({ id: i.id, qty: i.qty })) } : {}) })),
    itemCount: count,
    itemsTotal: total,
    deliveryCharge: deliveryChargeFor(total, delivery, d.pincode) || 0,
    total: total + (deliveryChargeFor(total, delivery, d.pincode) || 0),
    weightKg: cartKg(),
    customer: {
      name: d.name.trim().slice(0, 60),
      phone: d.phone,
      address: delivery ? String(d.address || '').trim().slice(0, 150) : '',
      landmark: delivery ? String(d.landmark || '').trim().slice(0, 80) : '',
      city: delivery ? String(d.city || '').trim().slice(0, 60) : '',
      pincode: delivery ? String(d.pincode || '') : '',
      area: delivery ? String(d.area || '').slice(0, 60) : '',
    },
    fulfilment: delivery ? 'delivery' : 'pickup',
    payment: 'upi', // cash on delivery removed: payment is direct UPI
    paymentRef: String(d.utr || '').replace(/[^A-Za-z0-9]/g, '').slice(0, 40),
    payVia: payingOnWa(d) ? 'whatsapp' : 'upi',
    proof: Boolean(d.proof),
    note: String(d.note || '').trim().slice(0, 300),
    status: 'requested',
    channel: 'web',
    clientTime: new Date().toISOString(),
  };
  const text = orderSummaryText(data, s);

  const orders = load(LS.orders, []);
  orders.unshift({
    orderNo, clientTime: data.clientTime, total: data.total, itemCount: count, payment: data.payment, text, proof: data.proof, payVia: data.payVia,
    items: data.items.map((it) => ({ id: it.id, name: it.name, pack: it.pack, qty: it.qty, lineTotal: it.lineTotal })),
    state: LIVE ? 'pending' : 'demo',
  });
  save(LS.orders, orders.slice(0, 15));
  save(LS.bought, [...new Set([...data.items.map((i) => i.id), ...load(LS.bought, [])])].slice(0, 12));
  if (LIVE) {
    const box = load(LS.outbox, []);
    box.push({ orderNo, data, proof: d.proof || '', attempts: 0 });
    save(LS.outbox, box);
    flushOutbox();
  }

  state.cart = {};
  save(LS.cart, state.cart);
  try { sessionStorage.removeItem('smat_draft'); } catch (_) { /* ignore */ }
  renderCatalog();
  renderCartBar();
  state.view = { name: 'done', orderNo };
  renderSheet(true);
}

// Sends saved orders to Firestore. Offline writes wait in Firestore's own
// queue; the outbox also survives browsers where that queue is unavailable.
function flushOutbox() {
  if (!state.db || !state.fs) return;
  const { doc, setDoc, serverTimestamp } = state.fs;
  const box = load(LS.outbox, []);
  for (const item of box) {
    if (inflight.has(item.orderNo)) continue;
    inflight.add(item.orderNo);
    item.attempts = (item.attempts || 0) + 1;
    const attempt = item.attempts;
    setDoc(doc(state.db, 'orders', item.orderNo), { ...item.data, createdAt: serverTimestamp() })
      // Public tracking record: status only — never name, phone or address.
      .then(() => (item.proof
        ? setDoc(doc(state.db, 'payment_proofs', item.orderNo), { data: item.proof, createdAt: serverTimestamp() }).catch(() => {})
        : null))
      .then(() => setDoc(doc(state.db, 'order_status', item.orderNo), {
        status: 'requested', fulfilment: item.data.fulfilment, total: item.data.total,
        itemCount: item.data.itemCount, updatedAt: serverTimestamp(),
      }).catch(() => {}))
      .then(() => settle(item.orderNo, 'saved'))
      .catch((e) => {
        // A retry is refused when the first attempt already created the order.
        if (e?.code === 'permission-denied') settle(item.orderNo, attempt > 1 ? 'saved' : 'failed');
        else inflight.delete(item.orderNo);
      });
  }
  save(LS.outbox, box);
}

function settle(orderNo, result) {
  inflight.delete(orderNo);
  save(LS.outbox, load(LS.outbox, []).filter((x) => x.orderNo !== orderNo));
  const orders = load(LS.orders, []);
  const o = orders.find((x) => x.orderNo === orderNo);
  if (o) { o.state = result; save(LS.orders, orders); }
  renderCartBar();
  if (state.view && (state.view.name === 'done' || state.view.name === 'orders')) renderSheet();
  if (result === 'saved') toast(t('reached', { no: orderNo }));
}



/* ---------- Website content managed from the shop app ---------- */
// Banners, delivery note, trust lines, owner story, about text, contact
// links and category photos all come from the catalog the app publishes
// (Web Store screen), so the shop updates them without touching code.
const EXTRA_ICONS = {
  again: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/>',
  star: '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/>',
  spark: '<path d="M12 3v5M12 16v5M3 12h5M16 12h5M6.3 6.3l2.5 2.5M15.2 15.2l2.5 2.5M6.3 17.7l2.5-2.5M15.2 8.8l2.5-2.5"/>',
  phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/>',
  pin: '<path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  insta: '<rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r=".9"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  mail: '<rect x="3.5" y="5.5" width="17" height="13" rx="2"/><path d="M4 7l8 6 8-6"/>',
  home: '<path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/>',
  grid: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
};
const loc = (en, ta) => (isTa() && ta) || en;

function normSite(raw) {
  const s = raw && typeof raw === 'object' ? raw : {};
  const str = (v) => (typeof v === 'string' ? v.trim() : '');
  const today = new Date().toISOString().slice(0, 10);
  const banners = (Array.isArray(s.banners) ? s.banners : [])
    .filter((b) => b && (str(b.title) || str(b.image)) && b.active !== false && (!str(b.until) || str(b.until) >= today))
    .map((b) => ({ title: str(b.title), titleLocal: str(b.titleLocal), sub: str(b.sub), subLocal: str(b.subLocal), image: str(b.image), category: str(b.category) }));
  const trust = (Array.isArray(s.trust) ? s.trust : [])
    .filter((x) => x && str(x.text))
    .map((x) => ({ text: str(x.text), textLocal: str(x.textLocal) }));
  const o = s.owner && typeof s.owner === 'object' ? s.owner : {};
  const insta = str(s.instagram).replace(/^@/, '').replace(/^https?:\/\/(www\.)?instagram\.com\//i, '').replace(/[/?#].*$/, '');
  return {
    banners,
    trust,
    defaultSort: ['recommended', 'price_asc', 'price_desc', 'name', 'best'].includes(str(s.defaultSort)) ? str(s.defaultSort) : 'recommended',
    heroTitle: str(s.heroTitle),
    heroTitleLocal: str(s.heroTitleLocal),
    heroSub: str(s.heroSub),
    heroSubLocal: str(s.heroSubLocal),
    deliveryNote: str(s.deliveryNote),
    deliveryNoteLocal: str(s.deliveryNoteLocal),
    owner: {
      name: str(o.name), nameLocal: str(o.nameLocal), years: Number(o.years) > 0 ? Math.round(Number(o.years)) : 0,
      message: str(o.message), messageLocal: str(o.messageLocal), image: str(o.image),
    },
    about: str(s.about),
    aboutLocal: str(s.aboutLocal),
    instagram: /^[A-Za-z0-9._]{1,30}$/.test(insta) ? insta : '',
    mapUrl: /^https:\/\//i.test(str(s.mapUrl)) ? str(s.mapUrl) : '',
    payQr: str(s.payQr),
    hours: str(s.hours),
    hoursLocal: str(s.hoursLocal),
    phone: str(s.phone).replace(/[^0-9+]/g, ''),
    email: /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(str(s.email)) ? str(s.email) : '',
    categoryImages: s.categoryImages && typeof s.categoryImages === 'object' ? s.categoryImages : {},
  };
}

// "₹26.8/kg": worked out from the pack label (e.g. "25 kg bag", "500 g").
function perKg(pack) {
  const m = /(\d+(?:\.\d+)?)\s*(kg|kilo|kgs|g|gm|gms|gram|grams)\b/i.exec(pack.label);
  if (!m) return '';
  const qty = Number(m[1]) * (/^k/i.test(m[2]) ? 1 : 0.001);
  if (!(qty > 0)) return '';
  const v = unitPrice(pack) / qty;
  return `₹${v < 100 ? v.toFixed(1) : Math.round(v)}/${isTa() ? 'கிலோ' : 'kg'}`;
}
function metaHTML(pack) {
  const bits = [];
  const kg = perKg(pack);
  if (kg) bits.push(`<span>${esc(kg)}</span>`);
  if (pack.offerPrice) bits.push(`<span class="save">${esc(t('save', { amt: money(pack.price - pack.offerPrice) }))}</span>`);
  // Always present (even empty) so every card keeps the same height.
  return `<p class="meta-p">${bits.join('')}</p>`;
}
function badges(p) {
  const b = [];
  if (p.homemade) b.push(`<span class="badge-p b-home">${esc(t('homemade'))}</span>`);
  if (p.bestseller) b.push(`<span class="badge-p b-best">${esc(t('bestTag'))}</span>`);
  if (p.isNew) b.push(`<span class="badge-p b-new">${esc(t('newTag'))}</span>`);
  return b.length ? `<span class="badges">${b.join('')}</span>` : '';
}
function imgTag(image, alt) {
  const fs = isFsImage(image) ? ` data-fs="${esc(image)}"${photoCache.has(image) ? ' data-loaded="1"' : ''}` : '';
  return `<img src="${esc(imgSrc(image))}"${fs} alt="${esc(alt)}" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='/images/placeholder.svg'">`;
}
const catPhoto = (key) => state.catalog?.site?.categoryImages?.[key] || '';
function catThumb(key, size) {
  const photo = catPhoto(key);
  return photo ? imgTag(photo, '') : svg(catIcon(key), size);
}
function orderAgainItems() {
  const ids = load(LS.bought, []);
  const byId = new Map(state.catalog.products.map((p) => [p.id, p]));
  return ids.map((id) => byId.get(id)).filter((p) => p && p.inStock).slice(0, 8);
}

function renderSite() {
  const site = state.catalog?.site;
  if (!site) return;
  const s = state.catalog.store;

  // Headline: the shop's own words if set in the app; otherwise built from
  // the categories actually on the website, so switching a category off
  // (e.g. cattle feed during a trial) removes it from the headline too.
  const visible = state.catalog.categories.filter((c) => state.catalog.products.some((p) => p.category === c));
  const own = loc(site.heroTitle, site.heroTitleLocal);
  let head = own;
  if (!head && visible.length) {
    const names = visible.map((c) => (isTa() ? catLabel(c) : c.toLowerCase()));
    const list = isTa() || names.length < 2 ? names.join(', ') : `${names.slice(0, -1).join(', ')} and ${names[names.length - 1]}`;
    head = isTa() ? `${list} ஆன்லைனில் ஆர்டர் செய்யுங்கள்` : `Order ${list} online`;
  }
  $('#heroTitle').textContent = head || (isTa() ? 'ஆன்லைனில் ஆர்டர் செய்யுங்கள்' : 'Order online');
  // Search hint follows what's actually on sale (switched-off categories never appear).
  const hint = visible.slice(0, 4).map((c) => (isTa() ? catLabel(c) : c.toLowerCase()));
  const more = visible.length > 4 ? '…' : '';
  $('#search').placeholder = hint.length ? (isTa() ? `${hint.join(', ')}${more} தேடுங்கள்` : `Search ${hint.join(', ')}${more}`) : t('searchPh');
  const sub = loc(site.heroSub, site.heroSubLocal) || s.tagline || '';
  $('#heroSub').textContent = sub;
  $('#heroSub').hidden = !sub;
  const waNum = waNumber();
  // One floating WhatsApp button for the whole store.
  $('#waFab').hidden = !waNum;
  if (waNum) $('#waFab').href = `https://wa.me/${waNum}?text=${encodeURIComponent(t('waHello'))}`;

  const note = loc(site.deliveryNote, site.deliveryNoteLocal);
  $('#strip').hidden = !note;
  $('#strip').textContent = note;

  const bn = site.banners;
  $('#banners').hidden = !bn.length;
  $('#bnTrack').innerHTML = bn.map((b) => {
    const title = loc(b.title, b.titleLocal);
    const sub = loc(b.sub, b.subLocal);
    const link = b.category && visible.includes(b.category);
    const tag = link ? `button type="button" data-act="cat" data-cat="${esc(b.category)}"` : 'div';
    const end = link ? 'button' : 'div';
    return `<${tag} class="bn${b.image ? ' has-photo' : ''}">${b.image ? imgTag(b.image, '') : ''}<span class="bn-t">${title ? `<strong>${esc(title)}</strong>` : ''}${sub ? `<span>${esc(sub)}</span>` : ''}</span></${end}>`;
  }).join('');
  $('#bnDots').innerHTML = bn.length > 1
    ? bn.map((_, i) => `<button type="button" data-act="bdot" data-i="${i}" aria-label="${i + 1}" aria-current="${i === 0}"></button>`).join('')
    : '';
  hydratePhotos($('#bnTrack'));

  if (site.trust.length) {
    $('.promo .trust').innerHTML = site.trust
      .map((x) => `<li>${svg(EXTRA_ICONS.check, 16)}<span>${esc(loc(x.text, x.textLocal))}</span></li>`).join('');
  }

  const o = site.owner;
  const about = loc(site.about, site.aboutLocal);
  $('#story').hidden = !o.name && !about;
  $('#storyPh').innerHTML = o.image ? imgTag(o.image, loc(o.name, o.nameLocal)) : '';
  $('#storyPh').hidden = !o.image;
  $('#storyName').textContent = loc(o.name, o.nameLocal);
  $('#storyYears').textContent = o.years ? t('yearsServing', { n: o.years }) : '';
  $('#storyMsg').textContent = loc(o.message, o.messageLocal);
  $('#storyAbout').textContent = about;
  $('#aboutBlock').hidden = !about;
  hydratePhotos($('#story'));

  const links = [];
  if (site.phone) links.push(`<a href="tel:${esc(site.phone)}">${svg(EXTRA_ICONS.phone, 18)}<span>${esc(t('callUs'))}: ${esc(site.phone)}</span></a>`);
  if (site.email) links.push(`<a href="mailto:${esc(site.email)}">${svg(EXTRA_ICONS.mail, 18)}<span>${esc(t('emailUs'))}: ${esc(site.email)}</span></a>`);
  if (site.mapUrl) links.push(`<a href="${esc(site.mapUrl)}" target="_blank" rel="noopener">${svg(EXTRA_ICONS.pin, 18)}<span>${esc(t('findUs'))}</span></a>`);
  const hours = loc(site.hours || s.hours, site.hoursLocal);
  if (hours) links.push(`<p>${svg(EXTRA_ICONS.clock, 18)}<span>${esc(t('hoursL'))}: ${esc(hours)}</span></p>`);
  if (site.instagram) links.push(`<a href="https://instagram.com/${esc(site.instagram)}" target="_blank" rel="noopener">${svg(EXTRA_ICONS.insta, 18)}<span>@${esc(site.instagram)}</span></a>`);
  if (PUSH_VAPID_KEY && 'Notification' in window) {
    links.push(alertsAreOn()
      ? `<p>🔔 <span>${esc(t('alertsOn'))}</span></p>`
      : `<button type="button" class="linkish foot-alerts" data-act="alertsOn">🔔 ${esc(t('alertsBtn'))}</button>`);
  }
  links.push(`<button type="button" class="fb-card" data-act="feedback"><strong>${esc(t('fbCard'))}</strong><span>${esc(t('fbCardSub'))}</span></button>`);
  links.push(`<p class="site-version">Website ${SITE_VERSION}</p>`);
  $('#footLinks').innerHTML = links.join('');
}

// Offer banners move on their own every few seconds; they pause while
// the customer touches or hovers them, and stay still for anyone who has
// asked their phone to reduce motion.
function startBannerAutoplay() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const track = $('#bnTrack');
  let paused = false;
  const pause = () => { paused = true; };
  const resume = () => { paused = false; };
  ['pointerdown', 'mouseenter', 'focusin'].forEach((ev) => track.addEventListener(ev, pause, { passive: true }));
  ['pointerup', 'mouseleave', 'focusout'].forEach((ev) => track.addEventListener(ev, () => setTimeout(resume, 2500), { passive: true }));
  setInterval(() => {
    if (paused || document.hidden || $('#banners').hidden) return;
    const n = track.children.length;
    if (n < 2) return;
    const w = track.clientWidth || 1;
    const next = (Math.round(track.scrollLeft / w) + 1) % n;
    track.scrollTo({ left: next * w, behavior: 'smooth' });
  }, 4500);
}

function navigate(to) {
  if (to === 'cats') { openSheet({ name: 'cats' }); return; }
  if (to === 'learn') { openSheet({ name: 'learn' }); return; }
  if (state.view) closeSheet();
  if (to === 'home') window.scrollTo({ top: 0, behavior: 'smooth' });
  else if (to === 'shop') $('.layout').scrollIntoView({ behavior: 'smooth' });
  else if (to === 'search') { window.scrollTo({ top: 0 }); $('#search').focus(); }
  else if (to === 'orders') $('#headOrders').click();
  else if (to === 'cart') $('#headCart').click();
}



/* ---------- Delivery charge + address (set in the shop app) ---------- */
// Courier charge by pincode zone + parcel weight, set in the app
// (Web Store > Delivery charges). Without zones it falls back to the
// simple flat charge / free-above rule.
function parseKgLabel(label) {
  const m = /(\d+(?:\.\d+)?)\s*(kg|kgs|kilo|kilos|g|gm|gms|gram|grams)\b/i.exec(String(label || ''));
  return m ? Number(m[1]) * (/^k/i.test(m[2]) ? 1 : 0.001) : 0;
}
function lineKg(l) {
  if (l.p.combo) return (Number(l.p.combo.weightKg) || 0) * l.qty;
  return (l.pack.kg || parseKgLabel(l.pack.label) || 1) * l.qty; // unknown size: count 1 kg
}
function cartKg() { return Math.round(totals().ok.reduce((s, l) => s + lineKg(l), 0) * 1000) / 1000; }
function shipZone(pin) {
  if (!/^[1-9]\d{5}$/.test(String(pin || ''))) return null;
  const sh = state.catalog.store.shipping || {};
  const locals = (Array.isArray(sh.localPins) ? sh.localPins : []).map((x) => String(x).trim()).filter(Boolean);
  if (locals.some((x) => (x.endsWith('*') ? pin.startsWith(x.slice(0, -1)) : pin === x))) return 'local';
  const p2 = Number(pin.slice(0, 2));
  return p2 >= 60 && p2 <= 64 ? 'state' : 'india'; // 60–64: Tamil Nadu (and Puducherry)
}
function zonesOn() { return state.catalog.store.shipping?.enabled === true; }
// Returns the charge, or null when it can't be worked out yet (no pincode).
function deliveryChargeFor(itemsTotal, delivery, pin) {
  if (!delivery) return 0;
  const s = state.catalog.store;
  if (zonesOn()) {
    const z = shipZone(pin);
    if (!z) return null;
    const r = s.shipping.rates?.[z];
    if (r && (Number(r.base) > 0 || Number(r.perKg) > 0 || Number(r.freeAbove) > 0)) {
      if (Number(r.freeAbove) > 0 && itemsTotal >= Number(r.freeAbove)) return 0;
      const extraKg = Math.max(0, Math.ceil(cartKg() - (Number(r.baseKg) || 1) - 1e-9));
      return Math.round((Number(r.base) || 0) + extraKg * (Number(r.perKg) || 0));
    }
  }
  const charge = Number(s.deliveryCharge) || 0;
  const freeAbove = Number(s.freeDeliveryAbove) || 0;
  return freeAbove > 0 && itemsTotal >= freeAbove ? 0 : charge;
}
function fullAddress(c) {
  return [c.address, c.landmark, c.area && c.area !== 'Other area' ? c.area : '', c.city, c.pincode ? `PIN ${c.pincode}` : '']
    .map((x) => String(x || '').trim()).filter(Boolean).join(', ');
}
function chargeRows(itemsTotal, delivery, pin) {
  const dc = deliveryChargeFor(itemsTotal, delivery, pin);
  const s = state.catalog.store;
  const z = zonesOn() ? shipZone(pin) : null;
  const zr = z ? s.shipping.rates?.[z] : null;
  const freeAbove = zr ? Number(zr.freeAbove) || 0 : Number(s.freeDeliveryAbove) || 0;
  const nudge = delivery && dc > 0 && freeAbove > itemsTotal ? `<p class="hint">${esc(t('addMore', { amt: money(freeAbove - itemsTotal) }))}</p>` : '';
  const zoneName = z ? t({ local: 'zoneLocal', state: 'zoneState', india: 'zoneIndia' }[z]) : '';
  const dcText = dc === null ? t('enterPin') : (dc ? money(dc) : t('freeDelivery'));
  const label = `${t('deliveryCharge')}${delivery && zonesOn() ? ` · ${t('weightL')} ${cartKg()} kg${zoneName ? ` · ${zoneName}` : ''}` : ''}`;
  return `<div class="sum sub"><span>${esc(t('itemsTotal'))}</span><span>${money(itemsTotal)}</span></div>
    ${delivery ? `<div class="sum sub"><span>${esc(label)}</span><span>${esc(dcText)}</span></div>` : ''}
    <div class="sum"><span>${esc(t('grandTotal'))}</span><strong>${money(itemsTotal + (dc || 0))}</strong></div>${nudge}`;
}


/* ---------- Order tracking (public status record, no personal details) ---------- */
async function loadTrack(no, tries = 0) {
  state.track = state.track || {};
  if (!state.db) {
    if (tries < 10) { setTimeout(() => loadTrack(no, tries + 1), 800); return; }
    state.track[no] = { missing: true, offline: true };
  } else {
    try {
      const fs = state.fs;
      const snap = await fs.getDoc(fs.doc(state.db, 'order_status', no));
      if (snap.exists()) {
        const d = snap.data();
        const ts = (x) => (x && typeof x.toDate === 'function' ? x.toDate().toISOString() : x || '');
        const history = {};
        for (const [k, v] of Object.entries(d.history || {})) history[k] = ts(v);
        if (!history.requested) history.requested = ts(d.createdAt) || ts(d.updatedAt);
        state.track[no] = { ...d, history, updatedAt: ts(d.updatedAt) };
      } else {
        state.track[no] = { missing: true, offline: !navigator.onLine };
      }
    } catch (e) {
      state.track[no] = { missing: true, offline: true };
    }
  }
  if (state.view?.name === 'track' && state.view.no === no) renderSheet();
}


/* ---------- Pay first: UPI, then screenshot, then the order ---------- */
const needsProof = () => Boolean(state.catalog?.store?.upiId);
// Payee only: the customer types the amount in their app.
function upiPayeeLink() {
  const s = state.catalog.store;
  return `upi://pay?pa=${encodeURIComponent(s.upiId)}&pn=${encodeURIComponent(s.name)}&cu=INR`;
}
function upiLink(amount, orderNo) {
  const s = state.catalog.store;
  return `upi://pay?pa=${encodeURIComponent(s.upiId)}&pn=${encodeURIComponent(s.name)}&tr=${encodeURIComponent(orderNo)}&am=${Math.round(amount)}.00&cu=INR&tn=${encodeURIComponent(`Order ${orderNo}`)}`;
}
const isAndroid = () => /android/i.test(navigator.userAgent);
// Opens an app's home screen (not a payment screen), so nothing is blocked.
const UPI_APPS = [
  ['Google Pay', 'com.google.android.apps.nbu.paisa.user'],
  ['PhonePe', 'com.phonepe.app'],
  ['Paytm', 'net.one97.paytm'],
  ['BHIM', 'in.org.npci.upiapp'],
  ['WhatsApp', 'com.whatsapp'],
];
const appLink = (pkg) => `intent://#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=${pkg};S.browser_fallback_url=${encodeURIComponent(`https://play.google.com/store/apps/details?id=${pkg}`)};end`;
function payFirstHTML(d, amount) {
  if (!needsProof()) return '';
  if (!d.orderNo) d.orderNo = makeOrderNo();
  if (!d.payVia) d.payVia = 'upi';
  const s = state.catalog.store;
  const qr = state.catalog.site?.payQr;
  const amt = Math.round(amount);
  const wa = Boolean(waNumber());
  const choice = (v, label) => `<label class="pay-choice"><input type="radio" name="payVia" value="${v}"${d.payVia === v ? ' checked' : ''}> <span>${esc(label)}</span></label>`;
  const upi = `<button type="button" class="btn primary pay-now" data-act="copyUpi">${esc(t('copyUpiBig'))}</button>
    <p class="upi-line">${esc(t('upiId'))}: <strong>${esc(s.upiId)}</strong></p>
    ${d.upiCopied ? `<p class="copied-line">${esc(t('upiCopiedLine'))}</p>` : ''}
    ${isAndroid() ? `<div class="app-row">${UPI_APPS.map(([name, pkg]) => `<a class="app-btn" href="${appLink(pkg)}">${esc(name)}</a>`).join('')}</div>
      <p class="pay-note">${esc(t('appSteps', { amt: money(amt), shop: s.name }))}</p>`
      : `<p class="pay-note">${esc(t('appStepsIos', { amt: money(amt), shop: s.name }))}</p>`}
    ${qr ? `<details class="pay-help"><summary>${esc(t('otherWays'))}</summary><div class="pay-qr">${imgTag(qr, 'UPI QR')}</div><p class="pay-note">${esc(t('payWayQr'))}</p></details>` : ''}
    <p class="step-h">${esc(t('proofStep'))}</p>
    ${d.proof ? `<img class="proof-img" src="${d.proof}" alt="">` : ''}
    <label class="btn ghost upload-btn">${esc(d.proof ? t('proofChange') : t('proofPick'))}<input type="file" id="proofIn" accept="image/*" hidden></label>
    <input id="utrIn" class="utr" maxlength="40" inputmode="text" placeholder="${esc(t('utrL'))}" aria-label="${esc(t('utrL'))}" value="${esc(d.utr || '')}">`;
  return `<div class="paystep">
    <p class="step-h">${esc(t('payStep', { amt: money(amount) }))}</p>
    <div class="amount-big"><span>${esc(t('amountToPay'))}</span><strong>${money(amt)}</strong></div>
    ${wa ? `<div class="pay-choices">${choice('upi', t('payViaUpi'))}${choice('whatsapp', t('payViaWa'))}</div>` : ''}
    ${d.payVia === 'whatsapp' && wa ? `<p class="pay-note wa-note">${esc(t('payWaNote'))}</p>` : upi}
  </div>`;
}
const payingOnWa = (d) => d.payVia === 'whatsapp' && Boolean(waNumber());
// Shrinks a phone screenshot to a small JPEG (about 100–300 KB).
async function compressImage(file) {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
    const scale = Math.min(1, 1100 / Math.max(img.width, img.height));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(img.width * scale));
    c.height = Math.max(1, Math.round(img.height * scale));
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    let q = 0.72;
    let out = c.toDataURL('image/jpeg', q);
    while (out.length > 380000 && q > 0.3) { q -= 0.1; out = c.toDataURL('image/jpeg', q); }
    return out.length <= 420000 ? out : null;
  } finally {
    URL.revokeObjectURL(url);
  }
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch (_) {
    const ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); } catch (_) { /* nothing more to try */ }
    ta.remove();
  }
  toast(t('copied'));
}

/* ---------- Feedback & "looking for" requests ---------- */
async function sendFeedback(form) {
  const text = form.text.value.trim();
  if (text.length < 3) { toast(t('fbShort')); return; }
  if (!state.db || !navigator.onLine) { toast(t('tipOffline')); return; }
  const btn = form.querySelector('button');
  btn.disabled = true;
  try {
    const fs = state.fs;
    const phone = form.phone.value.replace(/\D/g, '');
    await fs.addDoc(fs.collection(state.db, 'feedback'), {
      text: text.slice(0, 500),
      name: form.name.value.trim().slice(0, 40),
      phone: /^\d{10}$/.test(phone) ? phone : '',
      query: String(form.dataset.q || '').slice(0, 80),
      lang: state.lang,
      createdAt: fs.serverTimestamp(),
    });
    toast(t('fbThanks'));
    closeSheet();
  } catch (e) {
    console.warn('Feedback not sent', e);
    toast(t('tipOffline'));
    btn.disabled = false;
  }
}

/* ---------- Back-in-stock alerts ---------- */
async function enableStockAlert(productId) {
  try {
    const token = await getPushToken();
    if (!token) return;
    const fs = state.fs;
    const id = `${productId}_${(await sha256Hex(token)).slice(0, 20)}`.slice(0, 200);
    await fs.setDoc(fs.doc(state.db, 'stock_alerts', id), { productId, token, lang: state.lang, createdAt: fs.serverTimestamp() })
      .catch(() => { /* already asked */ });
    save(LS.stockAlerts, [...new Set([productId, ...load(LS.stockAlerts, [])])].slice(0, 50));
    toast(t('stockNotifyOn'));
    refreshCard(productId);
  } catch (e) {
    console.warn('Stock alert', e);
    toast(t('alertsFail'));
  }
}

/* ---------- New version while the store is open: reload (never mid-checkout) ---------- */
let pendingUpdate = false;
const busyInCheckout = () => ['checkout', 'confirm', 'done'].includes(state.view?.name);
function applyUpdate() {
  if (busyInCheckout()) { pendingUpdate = true; return; }
  toast(t('updating'));
  setTimeout(() => window.location.reload(), 600);
}
async function checkForUpdate() {
  try {
    const res = await fetch(`/version.json?t=${Date.now()}`, { cache: 'no-store' });
    if (!res.ok) return;
    const v = (await res.json()).v;
    if (v && v !== SITE_VERSION) applyUpdate();
  } catch (_) { /* offline: try again later */ }
}
function startUpdateWatch() {
  setInterval(() => { if (!document.hidden) checkForUpdate(); }, 120000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) checkForUpdate(); });
  window.addEventListener('focus', checkForUpdate);
  setTimeout(checkForUpdate, 4000);
}

/* ---------- Product reviews (after delivery, approved by the shop) ---------- */
function reviewFormHTML(no) {
  const st = state.track?.[no];
  if (!st || !['delivered', 'paid'].includes(st.status)) return '';
  const order = load(LS.orders, []).find((o) => o.orderNo === no);
  if (!order || !Array.isArray(order.items) || !order.items.length) return '';
  const done = load(LS.reviewed, []);
  const items = [...new Map(order.items.filter((i) => i.id).map((i) => [i.id, i])).values()];
  if (!items.length) return '';
  return `<div class="rate-box"><h3 class="pv-h">${esc(t('rateTitle'))}</h3>${items.map((i, idx) => {
    const key = `${no}_${i.id}`;
    if (done.includes(key)) return `<p class="rate-item"><strong>${esc(i.name)}</strong> <span class="alerts-on">${esc(t('ratedL'))}</span></p>`;
    const n = state.rate?.[i.id] || 0;
    return `<div class="rate-item"><strong>${esc(i.name)}</strong>
      <div class="star-row">${[1, 2, 3, 4, 5].map((k) => `<button type="button" class="star${k <= n ? ' on' : ''}" data-act="star" data-pid="${esc(i.id)}" data-n="${k}" aria-label="${k} ★">★</button>`).join('')}</div>
      <input id="rv-name-${idx}" maxlength="40" placeholder="${esc(t('rateName'))}" value="${esc(load(LS.customer, {}).name || '')}">
      <textarea id="rv-text-${idx}" maxlength="400" rows="2" placeholder="${esc(t('rateText'))}"></textarea>
      <button type="button" class="btn ghost small" data-act="sendReview" data-no="${esc(no)}" data-pid="${esc(i.id)}" data-pname="${esc(i.name)}" data-idx="${idx}">${esc(t('rateSend'))}</button></div>`;
  }).join('')}</div>`;
}
async function sendReview(no, pid, pname, idx) {
  const stars = state.rate?.[pid] || 0;
  if (!stars) { toast(t('ratePick')); return; }
  if (!state.db) { toast(t('tipOffline')); return; }
  const fs = state.fs;
  try {
    await fs.setDoc(fs.doc(state.db, 'reviews', `${no}_${pid}`), {
      orderNo: no, productId: pid, productName: String(pname).slice(0, 80),
      name: String($(`#rv-name-${idx}`)?.value || '').trim().slice(0, 40),
      text: String($(`#rv-text-${idx}`)?.value || '').trim().slice(0, 400),
      stars, status: 'pending', createdAt: fs.serverTimestamp(),
    });
    save(LS.reviewed, [...new Set([`${no}_${pid}`, ...load(LS.reviewed, [])])].slice(0, 100));
    toast(t('rateThanks'));
    renderSheet();
  } catch (e) {
    console.warn('Review not sent', e);
    toast(t('tipOffline'));
  }
}

/* ---------- Checkout progress survives a switch to the UPI app ---------- */
function saveDraft() {
  if (state.view?.name !== 'confirm') return;
  try { sessionStorage.setItem('smat_draft', JSON.stringify(state.view.draft)); } catch (_) { /* full or blocked */ }
}
function restoreDraft() {
  let d = null;
  try { d = JSON.parse(sessionStorage.getItem('smat_draft') || 'null'); } catch (_) { d = null; }
  if (!d || !d.orderNo || !Object.keys(state.cart).length) return;
  const tryOpen = (n = 0) => (state.catalog ? openSheet({ name: 'confirm', draft: d }) : n < 20 && setTimeout(() => tryOpen(n + 1), 300));
  tryOpen();
}

/* ---------- Push token (shared by offer alerts and order updates) ---------- */
async function getPushToken(quiet = false) {
  const say = (msg) => { if (!quiet) toast(msg); };
  if (isIOS() && !isStandalone()) { say(t('alertsInstallFirst')); return null; }
  if (!alertsSupported()) { say(t('alertsFail')); return null; }
  // Ask first: phones only allow this question during the customer's tap.
  const perm = await Notification.requestPermission();
  if (perm !== 'granted') { say(t('alertsBlocked')); return null; }
  // Then wait (up to ~10 s) for the store's connection, e.g. on slow networks.
  for (let i = 0; i < 20 && !(state.fbApp && state.db); i += 1) await new Promise((r) => setTimeout(r, 500));
  if (!state.fbApp || !state.db) { say(t('alertsFail')); return null; }
  const m = await import(`https://www.gstatic.com/firebasejs/${FIREBASE_SDK_VERSION}/firebase-messaging.js`);
  if (!(await m.isSupported())) { say(t('alertsFail')); return null; }
  return m.getToken(m.getMessaging(state.fbApp), {
    vapidKey: PUSH_VAPID_KEY, serviceWorkerRegistration: await navigator.serviceWorker.ready,
  });
}
// Phones that can receive order updates right now (iPhone: only once the
// store is on the Home Screen). If notifications were blocked, we don't ask.
function pushPossible() {
  return alertsSupported() && Notification.permission !== 'denied' && !(isIOS() && !isStandalone());
}
// Instant status updates for one order: Confirmed, Dispatched, Delivered.
// quiet: used right after ordering — no error messages, just try.
async function enableOrderUpdates(orderNo, quiet = false) {
  try {
    const token = await getPushToken(quiet);
    if (!token) return;
    const fs = state.fs;
    await fs.setDoc(fs.doc(state.db, 'order_push', orderNo), { token, lang: state.lang, createdAt: fs.serverTimestamp() })
      .catch(() => { /* already on */ });
    save(LS.opush, [...new Set([orderNo, ...load(LS.opush, [])])].slice(0, 20));
    toast(t('orderUpdatesOn'));
    if (state.view) renderSheet();
  } catch (e) {
    console.warn('Order updates', e);
    if (!quiet) toast(t('alertsFail'));
  }
}
function orderUpdatesHTML(orderNo) {
  if (!PUSH_VAPID_KEY || !('Notification' in window)) return '';
  if (load(LS.opush, []).includes(orderNo)) return `<p class="alerts-on">${esc(t('orderUpdatesOn'))}</p>`;
  return `<button type="button" class="btn primary" data-act="orderUpdates" data-no="${esc(orderNo)}">${esc(t('orderUpdates'))}</button>`;
}

/* ---------- Install as an app (every visit until installed) ---------- */
let installPrompt = null;
const isStandalone = () => window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
const isIOS = () => /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
function showInstallBar() {
  const bar = $('#installBar');
  if (!bar || isStandalone() || bar.dataset.dismissed) return;
  // Always "Install": installs directly where the phone allows it, otherwise shows the steps.
  $('#installGo').textContent = t('installBtn');
  bar.hidden = false;
}
function installNow() {
  if (installPrompt) {
    installPrompt.prompt();
    installPrompt.userChoice.finally(() => { installPrompt = null; $('#installBar').hidden = true; });
    return;
  }
  toast(isIOS() ? t('iosSteps') : t('menuSteps'));
}
window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); installPrompt = e; showInstallBar(); });
window.addEventListener('appinstalled', () => { installPrompt = null; const b = $('#installBar'); if (b) b.hidden = true; });

/* ---------- Offer alerts: notification-bar messages from the shop ---------- */
function alertsSupported() {
  return Boolean(PUSH_VAPID_KEY) && 'Notification' in window && 'serviceWorker' in navigator && 'PushManager' in window;
}
const alertsAreOn = () => load(LS.alerts, '') === 'on' && 'Notification' in window && Notification.permission === 'granted';
function alertsCardHTML() {
  if (!PUSH_VAPID_KEY || !('Notification' in window)) return '';
  if (alertsAreOn()) return `<p class="alerts-on">🔔 ${esc(t('alertsOn'))}</p>`;
  return `<div class="alerts-card"><p>${esc(t('alertsIntro'))}</p><button type="button" class="btn ghost" data-act="alertsOn">🔔 ${esc(t('alertsBtn'))}</button></div>`;
}
async function sha256Hex(text) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}
async function enableOfferAlerts() {
  try {
    const token = await getPushToken();
    if (!token) return;
    const fs = state.fs;
    try {
      await fs.setDoc(fs.doc(state.db, 'push_subscribers', await sha256Hex(token)), {
        token, lang: state.lang, createdAt: fs.serverTimestamp(),
      });
    } catch (e) { /* already subscribed on this phone */ }
    save(LS.alerts, 'on');
    toast(`🔔 ${t('alertsOn')}`);
    renderSite();
    if (state.view) renderSheet();
  } catch (e) {
    console.warn('Offer alerts', e);
    toast(t('alertsFail'));
  }
}

/* ---------- Combo offers (created in the shop app) ---------- */
function comboList(c) {
  return c.items.map((i) => `${loc(i.name, i.nameLocal)} ${i.label}`).join(' + ');
}
function comboSectionHTML() {
  const combos = state.catalog?.combos || [];
  if (!combos.length || state.q.trim()) return '';
  return `<section class="sec combos" id="comboSec">
    <div class="sec-head"><span class="sec-i">${svg(ICONS.tag, 20)}</span><h2>${esc(t('combos'))}</h2><span class="sec-n">${combos.length}</span></div>
    <div class="combo-row">${combos.map(comboCard).join('')}</div></section>`;
}
function comboCard(c) {
  const key = `combo::${c.id}`;
  const qty = state.cart[key] || 0;
  const name = loc(c.name, c.nameLocal);
  const save = c.normal > c.price ? c.normal - c.price : 0;
  let action;
  if (!c.inStock) action = `<p class="out">${esc(t('outOfStock'))}</p>`;
  else if (!qty) action = `<button type="button" class="add" data-act="add" data-key="${esc(key)}">${esc(t('add'))}</button>`;
  else action = stepper(key, qty, name);
  return `<article class="combo-card${c.inStock ? '' : ' is-out'}">
    <div class="cb-photos">${(c.images.length ? c.images : ['']).map((im) => `<span class="cb-ph">${imgTag(im, '')}</span>`).join('')}<span class="cb-tag">${esc(t('comboTag'))}</span></div>
    <div class="cb-body"><h3>${esc(name)}</h3><p class="cb-list">${esc(comboList(c))}</p>
      <p class="price"><span class="now">${money(c.price)}</span>${save ? `<s>${money(c.normal)}</s>` : ''}</p>
      ${save ? `<p class="meta-p"><span class="save">${esc(t('comboSave', { amt: money(save) }))}</span></p>` : ''}
      <div class="act-row">${action}</div></div></article>`;
}

function customChip(p, pack) {
  if (!p.byWeight) return '';
  const on = !!pack.custom;
  return `<button type="button" class="pack custom" data-act="custom" data-id="${esc(p.id)}" aria-pressed="${on}">${esc(on ? pack.label : t('customKg'))}</button>`;
}

/* ---------- Learn: benefits, how to use, customer tips ---------- */
const WA_ICON = '<path d="M4 20l1.3-3.9A8 8 0 1 1 8 19z"/><path d="M9.2 9.1c.3 1.9 1.8 3.4 3.7 3.8l.9-.9 1.6.7-.2 1.4c-3.3.1-6.2-2.8-6.1-6.1l1.4-.2.7 1.6z"/>';
function waMini(name) {
  const num = waNumber();
  if (!num) return '';
  const href = `https://wa.me/${num}?text=${encodeURIComponent(t('waAsk', { name }))}`;
  return `<a class="wa-mini" href="${href}" target="_blank" rel="noopener" aria-label="${esc(t('askWa'))}">${svg(WA_ICON, 20)}</a>`;
}
const pick = (en, ta) => (isTa() && ta.length ? ta : en);
function pvTabs(p, desc) {
  const benefits = pick(p.benefits, p.benefitsLocal);
  const howTo = pick(p.howTo, p.howToLocal);
  // Only tabs with something in them; How to use always has the tip form.
  const has = { about: !!desc || p.details.length > 0, benefits: benefits.length > 0, howto: true, reviews: p.reviews.length > 0 };
  const tab = has[state.pvTab] ? state.pvTab : ['about', 'benefits', 'howto'].find((k) => has[k]);
  const btn = (k, label) => (has[k] ? `<button type="button" role="tab" class="pv-tab" data-act="pvtab" data-tab="${k}" aria-selected="${tab === k}">${esc(label)}</button>` : '');
  let body = '';
  if (tab === 'reviews') {
    body = `${p.rating ? `<p class="rating big">★ ${p.rating.avg.toFixed(1)} <span>(${p.rating.count})</span></p>` : ''}
      ${p.reviews.map((r) => `<blockquote class="tip"><p class="stars">${'★'.repeat(r.stars)}${'☆'.repeat(5 - r.stars)}</p>${r.text ? `<p>${esc(r.text)}</p>` : ''}${r.name ? `<cite>${esc(r.name)}</cite>` : ''}</blockquote>`).join('')}`;
  } else if (tab === 'benefits') {
    body = benefits.length
      ? `<ul class="pv-list ok">${benefits.map((d) => `<li>${esc(d)}</li>`).join('')}</ul><p class="health-note">${esc(t('healthNote'))}</p>`
      : `<p class="muted">${esc(t('noInfo'))}</p>`;
  } else if (tab === 'howto') {
    const tips = p.tips.length
      ? `<h3 class="pv-h">${esc(t('customerTips'))}</h3>${p.tips.map((x) => `<blockquote class="tip"><p>${esc(x.text)}</p>${x.name ? `<cite>${esc(x.name)}</cite>` : ''}</blockquote>`).join('')}`
      : '';
    body = `${howTo.length ? `<ol class="pv-list steps">${howTo.map((d) => `<li>${esc(d)}</li>`).join('')}</ol>` : `<p class="muted">${esc(t('noInfo'))}</p>`}
      ${tips}
      <form class="tip-form" id="tipForm" data-id="${esc(p.id)}" data-name="${esc(p.name)}">
        <h3 class="pv-h">${esc(t('shareTip'))}</h3>
        <input name="name" maxlength="40" autocomplete="given-name" placeholder="${esc(t('tipName'))}" aria-label="${esc(t('tipName'))}">
        <textarea name="text" maxlength="400" rows="3" required placeholder="${esc(t('tipText'))}" aria-label="${esc(t('tipText'))}"></textarea>
        <button type="submit" class="btn ghost">${esc(t('tipSend'))}</button>
      </form>`;
  } else {
    body = `${desc ? `<p class="pv-desc">${esc(desc)}</p>` : ''}
      ${p.details.length ? `<ul class="pv-det">${p.details.map((d) => `<li>${esc(d)}</li>`).join('')}</ul>` : ''}
      ${!desc && !p.details.length ? `<p class="muted">${esc(t('noInfo'))}</p>` : ''}`;
  }
  return `<div class="pv-tabs" role="tablist">${btn('about', t('tabAbout'))}${btn('benefits', t('tabBenefits'))}${btn('howto', t('tabHowTo'))}${btn('reviews', t('reviewsTab'))}</div><div class="pv-panel">${body}</div>`;
}
async function sendTip(form) {
  const text = form.text.value.trim();
  if (!text) return;
  if (!state.db || !navigator.onLine) { toast(t('tipOffline')); return; }
  const btn = form.querySelector('button');
  btn.disabled = true;
  try {
    const fs = state.fs;
    await fs.addDoc(fs.collection(state.db, 'tips'), {
      productId: form.dataset.id,
      productName: form.dataset.name.slice(0, 80),
      name: form.name.value.trim().slice(0, 40),
      text: text.slice(0, 400),
      status: 'pending',
      createdAt: fs.serverTimestamp(),
    });
    form.reset();
    toast(t('tipThanks'));
  } catch (e) {
    console.warn('Tip not sent', e);
    toast(t('tipOffline'));
  } finally {
    btn.disabled = false;
  }
}

/* ---------- Product photos (published by the shop's app) ---------- */
// The app keeps each product photo in its own small document,
// catalog_images/{productId}, because the catalog must stay a single
// document under Firestore's 1 MB limit. The catalog refers to a photo as
// "fs:<productId>:<version>"; the version changes whenever the photo does,
// so a replaced photo is fetched fresh. Photos load lazily as their card
// comes near the screen, and Firestore's offline cache keeps them
// available without internet after the first visit.
const photoCache = new Map();
const photoWaiting = new Set();
let photoObserver = null;
function isFsImage(image) { return typeof image === 'string' && image.startsWith('fs:'); }
function hydratePhotos(root = document) {
  const imgs = $$('img[data-fs]', root).filter((img) => !img.dataset.loaded && !img.dataset.watching);
  if (!imgs.length) return;
  if (!photoObserver && 'IntersectionObserver' in window) {
    photoObserver = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) { photoObserver.unobserve(e.target); loadPhoto(e.target); }
      });
    }, { rootMargin: '400px 0px' });
  }
  imgs.forEach((img) => {
    img.dataset.watching = '1';
    if (photoObserver) photoObserver.observe(img); else loadPhoto(img);
  });
}
async function loadPhoto(img) {
  const ref = img.dataset.fs;
  if (!ref) return;
  if (photoCache.has(ref)) { img.src = photoCache.get(ref); img.dataset.loaded = '1'; return; }
  if (!state.db) { photoWaiting.add(img); return; }
  const id = ref.split(':')[1];
  try {
    const snap = await state.fs.getDoc(state.fs.doc(state.db, 'catalog_images', id));
    const data = snap.exists() ? snap.data().data : '';
    if (!data) return;
    const url = `data:image/jpeg;base64,${data}`;
    photoCache.set(ref, url);
    $$(`img[data-fs="${CSS.escape(ref)}"]`).forEach((el) => { el.src = url; el.dataset.loaded = '1'; });
  } catch (e) {
    console.warn('Photo not available yet', e);
  }
}
function flushPhotoWaiting() {
  const list = [...photoWaiting];
  photoWaiting.clear();
  list.forEach(loadPhoto);
}

/* ---------- Firebase ---------- */
async function initFirebase() {
  if (state.db || state.starting) return;
  state.starting = true;
  try {
    const base = `https://www.gstatic.com/firebasejs/${FIREBASE_SDK_VERSION}`;
    const [{ initializeApp }, fs] = await Promise.all([
      import(`${base}/firebase-app.js`),
      import(`${base}/firebase-firestore.js`),
    ]);
    const app = initializeApp(FIREBASE_CONFIG);
    state.fbApp = app;
    let db;
    try {
      db = fs.initializeFirestore(app, { localCache: fs.persistentLocalCache({ tabManager: fs.persistentMultipleTabManager() }) });
    } catch {
      db = fs.getFirestore(app);
    }
    state.fs = fs;
    state.db = db;
    flushPhotoWaiting();
    fs.onSnapshot(fs.doc(db, 'catalog', 'main'), { includeMetadataChanges: true }, (snap) => {
      state.fromCache = snap.metadata.fromCache;
      if (!snap.exists()) {
        if (!snap.metadata.fromCache && !state.catalog) setCatalog({ products: [] }, false);
        renderUpdated();
        return;
      }
      const raw = snap.data();
      const updatedAt = raw.updatedAt?.toMillis ? raw.updatedAt.toMillis() : (raw.updatedAt ?? null);
      setCatalog({ ...raw, updatedAt }, true);
    }, (err) => {
      console.warn('Catalog could not load', err);
      if (!state.catalog) showError(t('loadFail'));
    });
    flushOutbox();
  } catch (e) {
    console.warn('Firebase not available yet', e);
    if (!state.catalog) showError(t('loadFail'));
  } finally {
    state.starting = false;
  }
}

/* ---------- Misc ---------- */
let toastTimer;
function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.hidden = true; }, 3500);
}

function copy(text) {
  const done = () => toast(t('copied'));
  if (navigator.clipboard?.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(() => legacyCopy(text, done));
  } else legacyCopy(text, done);
}
function legacyCopy(text, done) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.setAttribute('readonly', '');
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); done(); } catch { toast(t('copyFail')); }
  ta.remove();
}

function updateNet() {
  const el = $('#net');
  el.hidden = navigator.onLine;
  el.textContent = t('offline');
}

function setLang(lang) {
  state.lang = lang === 'ta' ? 'ta' : 'en';
  save(LS.lang, state.lang);
  applyStatic();
  renderAll();
  if (state.view?.name === 'checkout') renderSheet();
}

function bindEvents() {
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    const key = b.dataset.key;
    const inGrid = Boolean(b.closest('#catalog'));
    switch (b.dataset.act) {
      case 'lang':
        setLang(b.dataset.lang);
        break;
      case 'cat':
        scrollToSection(b.dataset.cat);
        break;
      case 'pack':
        state.sel[b.dataset.id] = b.dataset.label;
        refreshCard(b.dataset.id, `[data-act="pack"][data-label="${CSS.escape(b.dataset.label)}"]`, b);
        if (state.view?.name === 'product') renderSheet();
        break;
      case 'view':
        state.pvTab = 'about';
        if (state.view) { state.view = { name: 'product', id: b.dataset.id }; renderSheet(true); } else openSheet({ name: 'product', id: b.dataset.id });
        break;
      case 'sub':
        state.sub = { ...(state.sub || {}), [b.dataset.cat]: b.dataset.sub };
        renderCatalog();
        break;
      case 'custom':
        openSheet({ name: 'kg', id: b.dataset.id });
        setTimeout(() => $('#kgIn')?.focus(), 250);
        break;
      case 'track':
        if (state.view) { state.view = { name: 'track', no: b.dataset.no }; renderSheet(true); } else openSheet({ name: 'track', no: b.dataset.no });
        break;
      case 'trackRefresh':
        if (state.track) delete state.track[b.dataset.no];
        renderSheet();
        break;
      case 'install':
        installNow();
        break;
      case 'installClose':
        $('#installBar').hidden = true;
        $('#installBar').dataset.dismissed = '1'; // this visit only
        break;
      case 'alertsOn':
        enableOfferAlerts();
        break;
      case 'feedback':
        if (state.view) { state.view = { name: 'feedback', q: b.dataset.q || '' }; renderSheet(true); } else openSheet({ name: 'feedback', q: b.dataset.q || '' });
        break;
      case 'stockAlert':
        enableStockAlert(b.dataset.id);
        break;
      case 'copyUpi':
        copyText(state.catalog.store.upiId);
        if (state.view?.name === 'confirm') { state.view.draft.upiCopied = true; saveDraft(); renderSheet(); }
        break;
      case 'star':
        state.rate = { ...(state.rate || {}), [b.dataset.pid]: Number(b.dataset.n) };
        renderSheet();
        break;
      case 'sendReview':
        sendReview(b.dataset.no, b.dataset.pid, b.dataset.pname, b.dataset.idx);
        break;
      case 'confirmOrder':
        if (state.view?.name !== 'confirm') break;
        if (needsProof() && !payingOnWa(state.view.draft) && !state.view.draft.proof) { toast(t('proofNeeded')); break; }
        {
          const draft = state.view.draft;
          const wantsUpdates = draft.notify !== false && pushPossible();
          const viaWa = payingOnWa(draft);
          const waAmt = totals().total + (deliveryChargeFor(totals().total, draft.fulfilment !== 'pickup', draft.pincode) || 0);
          placeOrder(draft);
          const no = state.view?.name === 'done' ? state.view.orderNo : null;
          if (viaWa && no) window.open(`https://wa.me/${waNumber()}?text=${encodeURIComponent(t('waPayMsg', { no, amt: money(waAmt) }))}`, '_blank', 'noopener');
          if (wantsUpdates && no) enableOrderUpdates(no, true);
        }
        break;
      case 'orderUpdates':
        enableOrderUpdates(b.dataset.no);
        break;
      case 'editOrder':
        if (state.view?.name === 'confirm') { state.view = { name: 'checkout', draft: state.view.draft }; renderSheet(true); }
        break;
      case 'pvtab':
        state.pvTab = b.dataset.tab;
        renderSheet();
        break;
      case 'viewtab':
        state.pvTab = b.dataset.tab;
        if (state.view) { state.view = { name: 'product', id: b.dataset.id }; renderSheet(true); } else openSheet({ name: 'product', id: b.dataset.id });
        break;
      case 'catgo':
        closeSheet();
        scrollToSection(b.dataset.cat);
        break;
      case 'nav':
        navigate(b.dataset.to);
        break;
      case 'bdot':
        $('#bnTrack').scrollTo({ left: $('#bnTrack').clientWidth * Number(b.dataset.i), behavior: 'smooth' });
        break;
      case 'add':
      case 'inc':
      case 'dec': {
        const act = b.dataset.act;
        setQty(key, (state.cart[key] || 0) + (act === 'dec' ? -1 : 1));
        refreshCard(key.split('::')[0], inGrid ? `[data-act="${act === 'add' ? 'inc' : act}"]` : null, inGrid ? b : null);
        renderCartBar();
        if (state.view?.name === 'cart' || state.view?.name === 'product') {
          renderSheet();
          if (!inGrid) ($(`#sheetBody [data-act="${act}"][data-key="${CSS.escape(key)}"]`) || $('#closeSheet')).focus();
        }
        break;
      }
      case 'checkout':
        state.view = { name: 'checkout' };
        renderSheet(true);
        break;
      case 'close':
        closeSheet();
        break;
      case 'copy':
        copy(b.dataset.text);
        break;
      default:
    }
  });

  // Pay now: copy the UPI ID, then hand over to the phone's UPI apps.
  document.addEventListener('click', async (e) => {
    const a = e.target.closest('a[data-paynow]');
    if (!a) return;
    e.preventDefault();
    const upi = a.dataset.upi;
    try {
      await Promise.race([navigator.clipboard.writeText(upi), new Promise((r) => setTimeout(r, 600))]);
    } catch (_) {
      const ta = document.createElement('textarea');
      ta.value = upi; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (_) { /* nothing more to try */ }
      ta.remove();
    }
    saveDraft();
    toast(t('payCopied', { amt: money(Number(a.dataset.amt)) }));
    window.location.href = a.href;
  });
  // Payment screenshot: shrink it on the phone, keep it with the draft order.
  document.addEventListener('change', async (e) => {
    if (e.target.id !== 'proofIn' || state.view?.name !== 'confirm') return;
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const data = await compressImage(file).catch(() => null);
    if (!data) { toast(t('proofBad')); return; }
    state.view.draft.proof = data;
    saveDraft();
    renderSheet();
  });
  document.addEventListener('input', (e) => {
    if (e.target.id === 'utrIn' && state.view?.name === 'confirm') { state.view.draft.utr = e.target.value; saveDraft(); }
    if (e.target.id === 'notifyOpt' && state.view?.name === 'confirm') state.view.draft.notify = e.target.checked;
    if (e.target.name === 'payVia' && state.view?.name === 'confirm') { state.view.draft.payVia = e.target.value; saveDraft(); renderSheet(); }
  });
  // Delivery charge updates as soon as a full pincode is typed.
  document.addEventListener('input', (e) => {
    if (e.target.id !== 'f-pincode' || !$('#coCharges')) return;
    const pin = e.target.value.replace(/\D/g, '');
    const delivery = $('#co [name="fulfilment"]:checked')?.value !== 'pickup';
    $('#coCharges').innerHTML = chargeRows(totals().total, delivery, pin);
  });
  document.addEventListener('submit', (e) => {
    if (e.target.id === 'tipForm') { e.preventDefault(); sendTip(e.target); return; }
    if (e.target.id === 'fbForm') { e.preventDefault(); sendFeedback(e.target); return; }
    if (e.target.id === 'kgForm') {
      e.preventDefault();
      const kg = round2(Number(String(e.target.kg.value).replace(',', '.')));
      if (!(kg >= 0.1 && kg <= 100)) { toast(t('kgBad')); return; }
      const id = e.target.dataset.id;
      if (!state.catalog.products.some((x) => x.id === id)) return;
      state.sel[id] = fmtKg(kg);
      closeSheet();
      refreshCard(id);
      return;
    }
    if (e.target.id !== 'co') return;
    e.preventDefault();
    submitCheckout(e.target);
  });
  document.addEventListener('change', (e) => {
    const form = e.target.closest('#co');
    if (!form) return;
    if (e.target.name === 'fulfilment') form.dataset.mode = e.target.value;
    if (e.target.name === 'payment') form.dataset.pay = e.target.value;
  });
  // Missing product photo: show the placeholder instead of a broken image.
  document.addEventListener('error', (e) => {
    const el = e.target;
    if (el.tagName === 'IMG' && !el.dataset.fallback && el.closest('.ph')) { el.dataset.fallback = '1'; el.src = '/images/placeholder.svg'; }
  }, true);

  $('#search').addEventListener('input', (e) => {
    state.q = e.target.value;
    if (!state.catalog) return;
    renderCats();
    renderCatalog();
  });
  $('#openCart').addEventListener('click', () => openSheet({ name: 'cart' }));
  $('#headCart').addEventListener('click', () => openSheet({ name: 'cart' }));
  $('#headOrders').addEventListener('click', () => openSheet({ name: 'orders' }));
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', measureHead);
  $('#closeSheet').addEventListener('click', closeSheet);
  $('#scrim').addEventListener('click', closeSheet);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && state.view) closeSheet(); });

  window.addEventListener('online', () => { updateNet(); renderUpdated(); if (LIVE) { initFirebase(); flushOutbox(); } });
  window.addEventListener('offline', () => { updateNet(); renderUpdated(); });
}

async function boot() {
  $('#year').textContent = String(new Date().getFullYear());
  applyStatic();
  bindEvents();
  watchTiles();
  measureHead();
  // Any time cards are (re)drawn, start loading their photos.
  new MutationObserver(() => hydratePhotos($('#catalog'))).observe($('#catalog'), { childList: true, subtree: true });
  document.addEventListener('change', (e) => {
    if (e.target.id !== 'sortSel') return;
    state.sort = e.target.value; // this visit only — see currentSort()
    renderCatalog();
  });
  try { localStorage.removeItem(LS.sort); } catch (_) { /* old saved sort choice */ }
  startBannerAutoplay();
  showInstallBar(); // footer card, every visit until installed
  restoreDraft(); // back from the UPI app: continue where the customer left off
  startUpdateWatch(); // new version published while the store is open -> reload
  const trackNo = new URLSearchParams(location.search).get('track');
  if (trackNo && /^[A-Z]{2,5}-\d{4}-[A-Z0-9]{4}$/.test(trackNo)) {
    const openTrack = (n = 0) => (state.catalog ? openSheet({ name: 'track', no: trackNo }) : n < 20 && setTimeout(() => openTrack(n + 1), 300));
    openTrack();
  }
  if (navigator.clearAppBadge) navigator.clearAppBadge().catch(() => {});
  // The floating WhatsApp button steps aside while scrolling so it never
  // covers an Add button, and comes back as soon as scrolling stops.
  let scrollTimer = null;
  window.addEventListener('scroll', () => {
    document.body.classList.add('is-scrolling');
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(() => document.body.classList.remove('is-scrolling'), 650);
  }, { passive: true });
  // Banner dots follow the swipe position.
  $('#bnTrack').addEventListener('scroll', () => {
    const tr = $('#bnTrack');
    const i = Math.round(tr.scrollLeft / Math.max(1, tr.clientWidth));
    $$('#bnDots button').forEach((d, k) => d.setAttribute('aria-current', String(k === i)));
  }, { passive: true });
  renderSkeleton();
  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    navigator.serviceWorker.register('/sw.js').then((reg) => {
      // Look for a newer version whenever the customer comes back to the store.
      document.addEventListener('visibilitychange', () => { if (!document.hidden) reg.update().catch(() => {}); });
    }).catch((e) => console.warn('Offline support unavailable', e));
    // A new version took over: reload once so the customer sees it straight away
    // (otherwise an open tab or installed app could keep showing the old one).
    let reloaded = false;
    const hadController = Boolean(navigator.serviceWorker.controller);
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (!hadController || reloaded) return;
      reloaded = true;
      window.location.reload();
    });
  }
  if (LIVE) {
    const cached = load(LS.catalog, null);
    if (cached) { state.fromCache = true; setCatalog(cached, false); }
    initFirebase();
  } else {
    $('#demo').hidden = false;
    try {
      const res = await fetch('/data/sample-catalog.json');
      setCatalog(await res.json(), false);
    } catch {
      showError(t('loadFail'));
    }
  }
}

boot();
