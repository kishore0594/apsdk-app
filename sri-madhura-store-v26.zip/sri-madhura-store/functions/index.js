// Sri Madhura Agro Traders — server functions (Firebase Blaze plan).
//  1. notifyNewOrder: a web order arrives -> alert on every shop phone,
//     even when the app is closed.
//  2. subscribeOffers: a customer turns on offer alerts -> add them to the
//     "offers" list.
//  3. sendCampaign: the shop sends an offer from the app -> one short
//     notification-bar alert to every subscribed customer.
const fs = require('fs');
const path = require('path');
const { onDocumentCreated, onDocumentWritten } = require('firebase-functions/v2/firestore');
const { onSchedule } = require('firebase-functions/v2/scheduler');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');
const { getMessaging } = require('firebase-admin/messaging');
const { getStorage } = require('firebase-admin/storage');

initializeApp();
const db = getFirestore();

// Must match the Firestore database location (written by the setup command).
const REGION = (() => {
  try { return fs.readFileSync(path.join(__dirname, 'region.txt'), 'utf8').trim() || 'us-central1'; }
  catch (_) { return 'us-central1'; }
})();

const DEAD = new Set(['messaging/registration-token-not-registered', 'messaging/invalid-registration-token', 'messaging/invalid-argument']);
const rupees = (n) => `₹${Math.round(Number(n) || 0)}`;

exports.notifyNewOrder = onDocumentCreated({ document: 'orders/{orderId}', region: REGION }, async (event) => {
  const o = event.data && event.data.data();
  if (!o) return;
  const devices = await db.collection('staff_devices').get();
  const tokens = devices.docs.map((d) => d.get('token')).filter(Boolean);
  if (!tokens.length) return;
  const name = (o.customer && o.customer.name) || 'Customer';
  const res = await getMessaging().sendEachForMulticast({
    tokens,
    notification: { title: 'New web order', body: `${name} · ${rupees(o.total)} · ${o.orderNo || event.params.orderId}` },
    android: { priority: 'high', notification: { channelId: 'orders', sound: 'default', tag: String(event.params.orderId) } },
    data: { orderId: String(event.params.orderId) },
  });
  // Phones that uninstalled the app: remove their old registration.
  await Promise.all(res.responses.map((r, i) =>
    (!r.success && r.error && DEAD.has(r.error.code)) ? devices.docs[i].ref.delete() : null));
});

exports.subscribeOffers = onDocumentCreated({ document: 'push_subscribers/{id}', region: REGION }, async (event) => {
  const token = event.data && event.data.get('token');
  if (!token) return;
  try {
    await getMessaging().subscribeToTopic([token], 'offers');
  } catch (e) {
    console.warn('subscribe failed', e.message);
  }
});

exports.sendCampaign = onDocumentCreated({ document: 'push_campaigns/{id}', region: REGION }, async (event) => {
  const c = event.data && event.data.data();
  if (!c || !c.title) return;
  try {
    const messageId = await getMessaging().send({
      topic: 'offers',
      data: {
        title: String(c.title).slice(0, 60),
        body: String(c.body || '').slice(0, 160),
        url: String(c.url || '/'),
        tag: `offer-${event.params.id}`,
      },
      webpush: { headers: { Urgency: 'high', TTL: '172800' } },
    });
    await event.data.ref.update({ status: 'sent', sent_at: new Date().toISOString(), message_id: messageId });
  } catch (e) {
    await event.data.ref.update({ status: 'failed', error: String(e.message || e).slice(0, 300) });
  }
});

// ---------------------------------------------------------------------------
// India time helpers (the app stores dates as local "YYYY-MM-DDTHH:MM:SS").
const istDate = (offsetDays = 0) =>
  new Date(Date.now() + 5.5 * 3600 * 1000 + offsetDays * 86400 * 1000).toISOString().slice(0, 10);

async function staffTokens() {
  const devices = await db.collection('staff_devices').get();
  return { devices, tokens: devices.docs.map((d) => d.get('token')).filter(Boolean) };
}

// 4. Daily summary, 8 PM India time: sales today, low stock, customers who
//    owe and haven't paid in 30+ days, web orders waiting.
exports.dailyDigest = onSchedule({ schedule: 'every day 20:00', timeZone: 'Asia/Kolkata', region: REGION }, async () => {
  const today = istDate(0);
  const salesSnap = await db.collection('sales').where('date', '>=', today).get();
  let count = 0;
  let total = 0;
  salesSnap.forEach((d) => {
    if (!String(d.get('date') || '').startsWith(today) || d.get('status') === 'cancelled') return;
    count += 1;
    total += Number(d.get('total_amount')) || 0;
  });

  const products = await db.collection('products').get();
  const low = products.docs.filter((p) => {
    const reorder = Number(p.get('reorder_level')) || 0;
    return reorder > 0 && (Number(p.get('quantity')) || 0) <= reorder;
  }).length;

  const owing = await db.collection('vendors').where('balance', '>', 0).get();
  const recent = await db.collection('credit_transactions').where('date', '>=', istDate(-30)).get();
  const paidRecently = new Set(recent.docs.filter((t) => t.get('type') === 'PAYMENT').map((t) => t.get('vendor_id')));
  const overdue = owing.docs.filter((v) => !paidRecently.has(v.id)).length;

  const waiting = (await db.collection('orders').where('status', '==', 'requested').get()).size;

  const { devices, tokens } = await staffTokens();
  if (!tokens.length) return;
  const parts = [
    low ? `${low} item${low === 1 ? '' : 's'} low on stock` : 'Stock OK',
    overdue ? `${overdue} customer${overdue === 1 ? '' : 's'} owe and haven't paid in 30+ days` : null,
    waiting ? `${waiting} web order${waiting === 1 ? '' : 's'} waiting` : null,
  ].filter(Boolean);
  const res = await getMessaging().sendEachForMulticast({
    tokens,
    notification: { title: `Today: ${rupees(total)} · ${count} sale${count === 1 ? '' : 's'}`, body: parts.join(' · ') },
    android: { notification: { tag: `digest-${today}` } },
  });
  await Promise.all(res.responses.map((r, i) =>
    (!r.success && r.error && DEAD.has(r.error.code)) ? devices.docs[i].ref.delete() : null));
});

// 6. Weekly backup, Sunday 11 PM India time: every collection saved as JSON
//    to Firebase Storage (backups/YYYY-MM-DD/<collection>.json). Keeps the
//    latest 8 weekly backups. Web-store photo copies are skipped (the
//    originals are inside the products backup).
exports.weeklyBackup = onSchedule({
  schedule: 'every sunday 23:00', timeZone: 'Asia/Kolkata', region: REGION, timeoutSeconds: 540, memory: '512MiB',
}, async () => {
  const project = process.env.GCLOUD_PROJECT || JSON.parse(process.env.FIREBASE_CONFIG || '{}').projectId;
  const bucket = getStorage().bucket(process.env.BACKUP_BUCKET || `${project}.firebasestorage.app`);
  const stamp = istDate(0);
  for (const col of await db.listCollections()) {
    if (col.id === 'catalog_images') continue;
    const snap = await col.get();
    const rows = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    await bucket.file(`backups/${stamp}/${col.id}.json`).save(JSON.stringify(rows), {
      contentType: 'application/json', resumable: false,
    });
  }
  const [files] = await bucket.getFiles({ prefix: 'backups/' });
  const days = [...new Set(files.map((f) => f.name.split('/')[1]).filter(Boolean))].sort();
  const remove = new Set(days.slice(0, Math.max(0, days.length - 8)));
  await Promise.all(files.filter((f) => remove.has(f.name.split('/')[1])).map((f) => f.delete()));
});

// 7. Instant order updates to the customer (no WhatsApp needed): when the
//    shop confirms, dispatches, delivers, verifies payment or cancels in
//    the app, the customer who tapped "Notify me" gets a notification.
const STATUS_TEXT = {
  confirmed: { en: ['✅ Order confirmed', 'Your order {no} is confirmed. We will pack it soon.'], ta: ['✅ ஆர்டர் உறுதிசெய்யப்பட்டது', 'உங்கள் ஆர்டர் {no} உறுதிசெய்யப்பட்டது. விரைவில் பேக் செய்வோம்.'] },
  dispatched: { en: ['🚚 Order dispatched', 'Your order {no} is on its way{via}.'], ta: ['🚚 ஆர்டர் அனுப்பப்பட்டது', 'உங்கள் ஆர்டர் {no} வழியில் உள்ளது{via}.'] },
  delivered: { en: ['📦 Order delivered', 'Your order {no} has been delivered. Thank you!'], ta: ['📦 டெலிவரி முடிந்தது', 'உங்கள் ஆர்டர் {no} டெலிவரி செய்யப்பட்டது. நன்றி!'] },
  cancelled: { en: ['Order cancelled', 'Your order {no} was cancelled. Please contact the shop for help.'], ta: ['ஆர்டர் ரத்து', 'உங்கள் ஆர்டர் {no} ரத்து செய்யப்பட்டது. உதவிக்கு கடையைத் தொடர்பு கொள்ளவும்.'] },
  paymentVerified: { en: ['💳 Payment received', 'We received your payment for order {no}. Thank you!'], ta: ['💳 பணம் பெறப்பட்டது', 'ஆர்டர் {no}-க்கான உங்கள் பணம் பெறப்பட்டது. நன்றி!'] },
};
exports.notifyOrderStatus = onDocumentWritten({ document: 'order_status/{orderNo}', region: REGION }, async (event) => {
  const before = (event.data.before && event.data.before.data()) || {};
  const after = (event.data.after && event.data.after.data()) || null;
  if (!after) return;
  let key = null;
  if (after.status !== before.status && STATUS_TEXT[after.status]) key = after.status;
  else if (after.paymentVerified === true && before.paymentVerified !== true) key = 'paymentVerified';
  if (!key) return;
  const no = event.params.orderNo;
  const sub = await db.collection('order_push').doc(no).get();
  if (!sub.exists || !sub.get('token')) return;
  const lang = sub.get('lang') === 'ta' ? 'ta' : 'en';
  const via = key === 'dispatched' && after.courier ? (lang === 'ta' ? ` (${after.courier})` : ` via ${after.courier}`) : '';
  const [title, body] = STATUS_TEXT[key][lang];
  try {
    await getMessaging().send({
      token: sub.get('token'),
      data: { title, body: body.replace('{no}', no).replace('{via}', via), url: `/?track=${no}`, tag: `order-${no}` },
      webpush: { headers: { Urgency: 'high', TTL: '86400' } },
    });
  } catch (e) {
    if (DEAD.has(e.code)) await sub.ref.delete();
  }
});
