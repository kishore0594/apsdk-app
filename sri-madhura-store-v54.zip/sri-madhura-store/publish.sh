#!/usr/bin/env bash
# Safe publish for madhuraagro.in. Run from anywhere:  bash publish.sh
# 1) makes sure the Firebase tools, login and project are ready
# 2) fills public/js/config.js with YOUR Firebase web settings (read from
#    Firebase itself), so the live site never goes out in "preview" mode
# 3) sets the functions region to where your database is
# 4) publishes the website, functions and database rules
cd "$(dirname "$0")" || exit 1
echo "== Sri Madhura website publish (folder: $PWD) =="

if ! command -v firebase >/dev/null 2>&1; then
  echo "Installing Firebase tools (one time)..."
  npm install -g firebase-tools --no-audit --no-fund >/dev/null 2>&1 || { echo "STOP: could not install firebase-tools."; exit 1; }
fi

if ! firebase projects:list --json >/tmp/smat_projects.json 2>/dev/null; then
  echo ""
  echo "STOP: please sign in to Firebase first. Run this, follow the link, paste the code:"
  echo "   firebase login --no-localhost"
  echo "Then paste the publish command again."
  exit 1
fi

PROJ=$(python3 - <<'PY'
import json
try:
    rc = json.load(open('.firebaserc'))['projects']['default']
except Exception:
    rc = ''
if rc and not rc.startswith('PASTE'):
    print(rc)
else:
    try:
        d = json.load(open('/tmp/smat_projects.json')); r = d.get('result', d)
        ids = [p.get('projectId') for p in r if p.get('projectId')]
        print(ids[0] if len(ids) == 1 else '')
    except Exception:
        print('')
PY
)
if [ -z "$PROJ" ]; then
  echo ""
  echo "STOP: more than one Firebase project (or none). Your projects:"
  firebase projects:list
  echo "Run:   firebase use <your project id>     then paste the publish command again."
  exit 1
fi
printf '{\n  "projects": {\n    "default": "%s"\n  }\n}\n' "$PROJ" > .firebaserc
echo "Project: $PROJ"

# Web settings (apiKey, appId...) straight from Firebase.
APPID=$(firebase apps:list WEB --project "$PROJ" --json 2>/dev/null | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin); r = d.get('result', d)
    print(r[0]['appId'] if r else '')
except Exception:
    print('')
")
if [ -z "$APPID" ]; then
  echo "STOP: no Web app found in Firebase project $PROJ (Firebase console > Project settings > Your apps)."
  exit 1
fi
firebase apps:sdkconfig WEB "$APPID" --project "$PROJ" --json 2>/dev/null > /tmp/smat_sdk.json
python3 - <<'PY' || exit 1
import json, re, sys
d = json.load(open('/tmp/smat_sdk.json')); r = d.get('result', d)
cfg = r.get('sdkConfig') or {}
if not cfg and r.get('fileContents'):
    m = re.search(r'\{.*\}', r['fileContents'], re.S)
    cfg = json.loads(m.group(0)) if m else {}
if not cfg.get('apiKey'):
    print("STOP: could not read your Firebase web settings."); sys.exit(1)
keys = ['apiKey', 'authDomain', 'projectId', 'storageBucket', 'messagingSenderId', 'appId']
body = ''.join(f"  {k}: '{cfg.get(k, '')}',\n" for k in keys)
p = 'public/js/config.js'
s = open(p, encoding='utf-8').read()
s = re.sub(r'export const FIREBASE_CONFIG = \{.*?\};', 'export const FIREBASE_CONFIG = {\n' + body + '};', s, count=1, flags=re.S)
open(p, 'w', encoding='utf-8').write(s)
print("Web settings: OK (" + cfg.get('projectId', '') + ")")
PY
if grep -q "PASTE_API_KEY" public/js/config.js; then echo "STOP: web settings missing — not publishing."; exit 1; fi

# Functions region = database location (keeps /img photos and pages working).
(cd functions && bash setup-region.sh) || { echo "STOP: region check failed (see message above)."; exit 1; }

(cd functions && npm install --no-audit --no-fund) || { echo "STOP: npm install failed."; exit 1; }
firebase deploy --project "$PROJ" --only hosting,functions,firestore:rules
