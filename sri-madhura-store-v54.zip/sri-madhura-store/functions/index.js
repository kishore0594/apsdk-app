// Sri Madhura Agro Traders — server functions (Firebase Blaze plan).
//  1. notifyNewOrder: a web order arrives -> alert on every shop phone,
//     even when the app is closed.
//  2. subscribeOffers: a customer turns on offer alerts -> add them to the
//     "offers" list.
//  3. sendCampaign: the shop sends an offer from the app -> one short
//     notification-bar alert to every subscribed customer.
const fs = require('fs');
const path = require('path');
const { onDocumentCreated, onDocumentWritten, onDocumentUpdated } = require('firebase-functions/v2/firestore');
const { onSchedule } = require('firebase-functions/v2/scheduler');
const { onRequest } = require('firebase-functions/v2/https');
const seo = require('./seo');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');
const { getMessaging } = require('firebase-admin/messaging');
const { getStorage } = require('firebase-admin/storage');

initializeApp();
const db = getFirestore();

// Must match the Firestore database location (written by the setup command).
const REGION = (() => {
  try { return fs.readFileSync(path.join(__dirname, 'region.txt'), 'utf8').trim() || 'us-central1'; }
  catch (_) { return 'us-central1'; }
})();

const DEAD = new Set(['messaging/registration-token-not-registered', 'messaging/invalid-registration-token', 'messaging/invalid-argument']);
const rupees = (n) => `₹${Math.round(Number(n) || 0)}`;

exports.notifyNewOrder = onDocumentCreated({ document: 'orders/{orderId}', region: REGION }, async (event) => {
  const o = event.data && event.data.data();
  if (!o) return;
  const devices = await db.collection('staff_devices').get();
  const tokens = devices.docs.map((d) => d.get('token')).filter(Boolean);
  if (!tokens.length) return;
  const name = (o.customer && o.customer.name) || 'Customer';
  const res = await getMessaging().sendEachForMulticast({
    tokens,
    notification: { title: 'New web order', body: `${name} · ${rupees(o.total)} · ${o.orderNo || event.params.orderId}` },
    android: { priority: 'high', notification: { channelId: 'orders', sound: 'default', tag: String(event.params.orderId) } },
    data: { orderId: String(event.params.orderId) },
  });
  // Phones that uninstalled the app: remove their old registration.
  await Promise.all(res.responses.map((r, i) =>
    (!r.success && r.error && DEAD.has(r.error.code)) ? devices.docs[i].ref.delete() : null));
});

// Price history: whenever the app publishes the catalog, note each
// product's price if it changed (one point per change, per day) — for the
// chart on the product page, and per pack for the "prior price" rule
// (from 1 Jan 2027 a price cut must show the lowest price of the 30 days
// before it). The prior prices for every pack go into price_history/_prior.
function addPoint(points, today, point) {
  const out = Array.isArray(points) ? points.slice() : [];
  const last = out[out.length - 1];
  if (last && Object.keys(point).every((k) => last[k] === point[k])) return null; // unchanged
  const full = { d: today, ...point };
  if (last && last.d === today) out[out.length - 1] = full; else out.push(full);
  return out.slice(-240);
}
exports.recordPrices = onDocumentWritten({ document: 'catalog/main', region: REGION }, async (event) => {
  const cat = event.data && event.data.after && event.data.after.exists ? event.data.after.data() : null;
  if (!cat) return;
  const today = new Date(Date.now() + 5.5 * 3600 * 1000).toISOString().slice(0, 10); // India date
  const products = seo.visibleProducts(cat);
  if (!products.length) return;
  const refs = products.map((p) => db.doc(`price_history/${p.id}`));
  const snaps = await db.getAll(...refs);
  let batch = db.batch();
  let n = 0;
  const priors = {};
  for (let i = 0; i < products.length; i++) {
    const p = products[i];
    const old = snaps[i].exists ? snaps[i].data() : {};
    let changed = false;
    // Main series (chart): per kg for loose items, else the main pack.
    const h = seo.historyPrice(p);
    let points = old.points || [];
    if (h && h.p > 0) {
      const next = addPoint(points, today, { p: h.p, m: h.m, l: h.l });
      if (next) { points = next; changed = true; }
    }
    // Every pack (and per kg for loose items): today's selling price.
    const packs = { ...(old.packs || {}) };
    const now = (Array.isArray(p.packs) ? p.packs : []).filter((k) => k && k.label && Number(k.price) > 0)
      .map((k) => [String(k.label), Math.round(Number(k.offerPrice) > 0 && Number(k.offerPrice) < Number(k.price) ? Number(k.offerPrice) : Number(k.price))]);
    if (p.byWeight && Number(p.pricePerKg) > 0) {
      const per = Number(p.pricePerKg); const off = Number(p.offerPerKg) || 0;
      now.push(['1 kg', Math.round(off > 0 && off < per ? off : per)]);
    }
    for (const [label, price] of now) {
      const next = addPoint(packs[label], today, { p: price });
      if (next) { packs[label] = next; changed = true; }
    }
    priors[p.id] = Object.fromEntries(Object.entries(packs).map(([label, series]) => [label, seo.priorOf(series)]));
    if (changed) {
      batch.set(refs[i], { name: String(p.name || ''), points, packs, updatedAt: new Date() });
      if (++n % 400 === 0) { await batch.commit(); batch = db.batch(); }
    }
  }
  batch.set(db.doc('price_history/_prior'), { items: priors, updatedAt: new Date() });
  await batch.commit();
});

exports.subscribeOffers = onDocumentCreated({ document: 'push_subscribers/{id}', region: REGION }, async (event) => {
  const token = event.data && event.data.get('token');
  if (!token) return;
  try {
    await getMessaging().subscribeToTopic([token], 'offers');
  } catch (e) {
    console.warn('subscribe failed', e.message);
  }
});

exports.sendCampaign = onDocumentCreated({ document: 'push_campaigns/{id}', region: REGION }, async (event) => {
  const c = event.data && event.data.data();
  if (!c || !c.title) return;
  try {
    const messageId = await getMessaging().send({
      topic: 'offers',
      data: {
        title: String(c.title).slice(0, 60),
        body: String(c.body || '').slice(0, 160),
        url: String(c.url || '/'),
        tag: `offer-${event.params.id}`,
      },
      webpush: { headers: { Urgency: 'high', TTL: '172800' } },
    });
    await event.data.ref.update({ status: 'sent', sent_at: new Date().toISOString(), message_id: messageId });
  } catch (e) {
    await event.data.ref.update({ status: 'failed', error: String(e.message || e).slice(0, 300) });
  }
});

// ---------------------------------------------------------------------------
// India time helpers (the app stores dates as local "YYYY-MM-DDTHH:MM:SS").
const istDate = (offsetDays = 0) =>
  new Date(Date.now() + 5.5 * 3600 * 1000 + offsetDays * 86400 * 1000).toISOString().slice(0, 10);

async function staffTokens() {
  const devices = await db.collection('staff_devices').get();
  return { devices, tokens: devices.docs.map((d) => d.get('token')).filter(Boolean) };
}

// 4. Daily summary, 8 PM India time: sales today, low stock, customers who
//    owe and haven't paid in 30+ days, web orders waiting.
exports.dailyDigest = onSchedule({ schedule: 'every day 20:00', timeZone: 'Asia/Kolkata', region: REGION }, async () => {
  const today = istDate(0);
  const salesSnap = await db.collection('sales').where('date', '>=', today).get();
  let count = 0;
  let total = 0;
  salesSnap.forEach((d) => {
    if (!String(d.get('date') || '').startsWith(today) || d.get('status') === 'cancelled') return;
    count += 1;
    total += Number(d.get('total_amount')) || 0;
  });

  const products = await db.collection('products').get();
  const low = products.docs.filter((p) => {
    const reorder = Number(p.get('reorder_level')) || 0;
    return reorder > 0 && (Number(p.get('quantity')) || 0) <= reorder;
  }).length;

  const owing = await db.collection('vendors').where('balance', '>', 0).get();
  const recent = await db.collection('credit_transactions').where('date', '>=', istDate(-30)).get();
  const paidRecently = new Set(recent.docs.filter((t) => t.get('type') === 'PAYMENT').map((t) => t.get('vendor_id')));
  const overdue = owing.docs.filter((v) => !paidRecently.has(v.id)).length;

  const waiting = (await db.collection('orders').where('status', '==', 'requested').get()).size;

  const { devices, tokens } = await staffTokens();
  if (!tokens.length) return;
  const parts = [
    low ? `${low} item${low === 1 ? '' : 's'} low on stock` : 'Stock OK',
    overdue ? `${overdue} customer${overdue === 1 ? '' : 's'} owe and haven't paid in 30+ days` : null,
    waiting ? `${waiting} web order${waiting === 1 ? '' : 's'} waiting` : null,
  ].filter(Boolean);
  const res = await getMessaging().sendEachForMulticast({
    tokens,
    notification: { title: `Today: ${rupees(total)} · ${count} sale${count === 1 ? '' : 's'}`, body: parts.join(' · ') },
    android: { notification: { tag: `digest-${today}` } },
  });
  await Promise.all(res.responses.map((r, i) =>
    (!r.success && r.error && DEAD.has(r.error.code)) ? devices.docs[i].ref.delete() : null));
});

// 6. Weekly backup, Sunday 11 PM India time: every collection saved as JSON
//    to Firebase Storage (backups/YYYY-MM-DD/<collection>.json). Keeps the
//    latest 8 weekly backups. Web-store photo copies are skipped (the
//    originals are inside the products backup).
exports.weeklyBackup = onSchedule({
  schedule: 'every sunday 23:00', timeZone: 'Asia/Kolkata', region: REGION, timeoutSeconds: 540, memory: '512MiB',
}, async () => {
  const project = process.env.GCLOUD_PROJECT || JSON.parse(process.env.FIREBASE_CONFIG || '{}').projectId;
  const bucket = getStorage().bucket(process.env.BACKUP_BUCKET || `${project}.firebasestorage.app`);
  const stamp = istDate(0);
  for (const col of await db.listCollections()) {
    if (col.id === 'catalog_images') continue;
    const snap = await col.get();
    const rows = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    await bucket.file(`backups/${stamp}/${col.id}.json`).save(JSON.stringify(rows), {
      contentType: 'application/json', resumable: false,
    });
  }
  const [files] = await bucket.getFiles({ prefix: 'backups/' });
  const days = [...new Set(files.map((f) => f.name.split('/')[1]).filter(Boolean))].sort();
  const remove = new Set(days.slice(0, Math.max(0, days.length - 8)));
  await Promise.all(files.filter((f) => remove.has(f.name.split('/')[1])).map((f) => f.delete()));
  // Search words older than 6 months are no longer needed (they are in the backups).
  const old = await db.collection('search_log').where('createdAt', '<', new Date(Date.now() - 183 * 86400 * 1000)).limit(450).get();
  if (!old.empty) {
    const batch = db.batch();
    old.docs.forEach((d) => batch.delete(d.ref));
    await batch.commit();
  }
});

// 7. Instant order updates to the customer (no WhatsApp needed): when the
//    shop confirms, dispatches, delivers, verifies payment or cancels in
//    the app, the customer who tapped "Notify me" gets a notification.
const STATUS_TEXT = {
  confirmed: { en: ['✅ Order confirmed', 'Your order {no} is confirmed. We will pack it soon.'], ta: ['✅ ஆர்டர் உறுதிசெய்யப்பட்டது', 'உங்கள் ஆர்டர் {no} உறுதிசெய்யப்பட்டது. விரைவில் பேக் செய்வோம்.'] },
  dispatched: { en: ['🚚 Order dispatched', 'Your order {no} is on its way{via}.'], ta: ['🚚 ஆர்டர் அனுப்பப்பட்டது', 'உங்கள் ஆர்டர் {no} வழியில் உள்ளது{via}.'] },
  delivered: { en: ['📦 Delivered — rate your items ⭐', 'Your order {no} has been delivered. Tap to rate your items — it helps other families choose!'], ta: ['📦 டெலிவரி முடிந்தது — மதிப்பிடுங்கள் ⭐', 'உங்கள் ஆர்டர் {no} டெலிவரி செய்யப்பட்டது. உங்கள் பொருட்களை மதிப்பிட அழுத்தவும்!'] },
  cancelled: { en: ['Order cancelled', 'Your order {no} was cancelled. Please contact the shop for help.'], ta: ['ஆர்டர் ரத்து', 'உங்கள் ஆர்டர் {no} ரத்து செய்யப்பட்டது. உதவிக்கு கடையைத் தொடர்பு கொள்ளவும்.'] },
  paymentVerified: { en: ['💳 Payment received', 'We received your payment for order {no}. Thank you!'], ta: ['💳 பணம் பெறப்பட்டது', 'ஆர்டர் {no}-க்கான உங்கள் பணம் பெறப்பட்டது. நன்றி!'] },
};
exports.notifyOrderStatus = onDocumentWritten({ document: 'order_status/{orderNo}', region: REGION }, async (event) => {
  const before = (event.data.before && event.data.before.data()) || {};
  const after = (event.data.after && event.data.after.data()) || null;
  if (!after) return;
  let key = null;
  if (after.status !== before.status && STATUS_TEXT[after.status]) key = after.status;
  else if (after.paymentVerified === true && before.paymentVerified !== true) key = 'paymentVerified';
  if (!key) return;
  const no = event.params.orderNo;
  const sub = await db.collection('order_push').doc(no).get();
  if (!sub.exists || !sub.get('token')) return;
  const lang = sub.get('lang') === 'ta' ? 'ta' : 'en';
  const via = key === 'dispatched' && after.courier ? (lang === 'ta' ? ` (${after.courier})` : ` via ${after.courier}`) : '';
  const [title, body] = STATUS_TEXT[key][lang];
  try {
    await getMessaging().send({
      token: sub.get('token'),
      data: { title, body: body.replace('{no}', no).replace('{via}', via), url: key === 'delivered' ? `/?track=${no}&rate=1` : `/?track=${no}`, tag: `order-${no}` },
      webpush: { headers: { Urgency: 'high', TTL: '86400' } },
    });
  } catch (e) {
    if (DEAD.has(e.code)) await sub.ref.delete();
  }
});

// 8. Back in stock: a product goes from 0 to some stock in the app ->
//    everyone who tapped "Notify me when back" gets an alert (once).
exports.notifyBackInStock = onDocumentUpdated({ document: 'products/{productId}', region: REGION }, async (event) => {
  const before = event.data.before.data() || {};
  const after = event.data.after.data() || {};
  if (!((Number(before.quantity) || 0) <= 0 && (Number(after.quantity) || 0) > 0)) return;
  const pid = event.params.productId;
  const subs = await db.collection('stock_alerts').where('productId', '==', pid).get();
  if (subs.empty) return;
  const name = String(after.name || 'Your item');
  const nameTa = String(after.name_local || name);
  await Promise.all(subs.docs.map(async (d) => {
    const ta = d.get('lang') === 'ta';
    try {
      await getMessaging().send({
        token: d.get('token'),
        data: {
          title: ta ? `🌾 ${nameTa} மீண்டும் கிடைக்கிறது!` : `🌾 ${name} is back in stock!`,
          body: ta ? 'தீரும் முன் இப்போதே ஆர்டர் செய்யுங்கள்.' : 'Order now before it runs out again.',
          url: '/', tag: `stock-${pid}`,
        },
        webpush: { headers: { Urgency: 'high', TTL: '86400' } },
      });
    } catch (e) { /* expired token: removed below anyway */ }
    await d.ref.delete(); // one alert per request
  }));
});

// 9. Restock reminder, 10 AM India time: about 25 days after an order was
//    delivered, customers who chose order updates get one friendly nudge.
exports.restockReminders = onSchedule({ schedule: 'every day 10:00', timeZone: 'Asia/Kolkata', region: REGION }, async () => {
  const from = istDate(-26);
  const to = istDate(-25);
  const snap = await db.collection('orders').where('status_at', '>=', from).where('status_at', '<', to).get();
  await Promise.all(snap.docs.map(async (o) => {
    const d = o.data();
    if (!['delivered', 'paid'].includes(d.status) || d.restock_reminded) return;
    const sub = await db.collection('order_push').doc(o.id).get();
    if (!sub.exists || !sub.get('token')) return;
    const first = (Array.isArray(d.items) && d.items[0] && d.items[0].name) || 'your millets';
    const ta = sub.get('lang') === 'ta';
    try {
      await getMessaging().send({
        token: sub.get('token'),
        data: {
          title: ta ? `🌾 ${first} மீண்டும் வாங்கும் நேரமா?` : `🌾 Time to restock ${first}?`,
          body: ta ? 'புதிய சரக்கு தயார் — ஒரே தட்டில் மீண்டும் ஆர்டர் செய்யுங்கள்.' : 'Fresh stock is ready — reorder in one tap.',
          url: '/', tag: `restock-${o.id}`,
        },
        webpush: { headers: { TTL: '86400' } },
      });
    } catch (e) { /* expired token */ }
    await o.ref.update({ restock_reminded: true });
  }));
});

// 10. Google pages: /p/<product>, /recipe/<recipe>, /shop/<brand>, /faq, /policy/<name>,
//     Tamil /ta/..., /sitemap.xml, /feed.xml (Google Shopping), /robots.txt, /img/<photo>
// ---------------- Automatic indexing ----------------
// Every time the app publishes the catalog, find which pages really changed
// (price, name, photo, text — not stock counts) and:
//  * give them a fresh "last changed" date in the sitemap (Google reads it),
//  * tell Bing / Yandex at once (IndexNow),
//  * ask Google to read the sitemap again (Search Console API, at most every
//    3 hours). Google only allows this for the site's verified owners: add
//    this function's service account as an Owner in Search Console once —
//    its address is saved in Firestore seo_state/pages → status.account.
const SITE = 'https://madhuraagro.in';
const INDEXNOW_KEY = '41776f2c11d56afd85608d4157c6d3c4';
const { GoogleAuth } = require('google-auth-library');

async function submitSitemapToGoogle() {
  const auth = new GoogleAuth({ scopes: ['https://www.googleapis.com/auth/webmasters'] });
  let account = '';
  try { account = ((await auth.getCredentials()) || {}).client_email || ''; } catch (_) { /* shown as unknown */ }
  const client = await auth.getClient();
  const feed = encodeURIComponent(`${SITE}/sitemap.xml`);
  let lastErr = null;
  // Domain property first, then the https:// address property.
  for (const site of ['sc-domain:madhuraagro.in', `${SITE}/`]) {
    try {
      await client.request({ url: `https://www.googleapis.com/webmasters/v3/sites/${encodeURIComponent(site)}/sitemaps/${feed}`, method: 'PUT' });
      return { ok: true, site, account };
    } catch (e) { lastErr = e; }
  }
  const msg = (lastErr && lastErr.response && lastErr.response.data && lastErr.response.data.error && lastErr.response.data.error.message)
    || (lastErr && lastErr.message) || 'unknown error';
  return { ok: false, error: String(msg).slice(0, 300), account };
}

async function tellIndexNow(urls) {
  if (!urls.length) return 'nothing';
  const res = await fetch('https://api.indexnow.org/indexnow', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
    body: JSON.stringify({ host: 'madhuraagro.in', key: INDEXNOW_KEY, keyLocation: `${SITE}/${INDEXNOW_KEY}.txt`, urlList: urls.slice(0, 10000) }),
  });
  return `${res.status}`;
}

async function seoAnnounce({ force = false } = {}) {
  const snapCat = await db.doc('catalog/main').get();
  if (!snapCat.exists) return;
  const cat = snapCat.data();
  let names = { entries: [], forms: [], brands: {} };
  try { const r = await fetch(`${SITE}/data/names.json`); if (r.ok) names = await r.json(); } catch (_) { /* brand pages use defaults */ }
  const hashes = seo.pageHashes(cat, names);
  const ref = db.doc('seo_state/pages');
  const snap = await ref.get();
  const old = (snap.exists && snap.get('pages')) || {};
  const status = (snap.exists && snap.get('status')) || {};
  const now = new Date().toISOString();
  const pages = {};
  const changed = [];
  for (const [p, h] of Object.entries(hashes)) {
    const k = seo.pageKey(p);
    if (old[k] && old[k].h === h) pages[k] = old[k];
    else { pages[k] = { h, at: now }; changed.push(p); }
  }
  if (!changed.length && !force) return;
  const urls = changed.flatMap((p) => [`${SITE}${p}`, `${SITE}${seo.pathFor('ta', p)}`]);
  const next = { ...status, changedPages: changed.length, changedAt: now };
  try { next.indexnow = await tellIndexNow(urls); } catch (e) { next.indexnow = `error: ${e.message}`; }
  next.indexnowAt = now;
  const lastGoogle = status.googleAt ? Date.parse(status.googleAt) : 0;
  if (force || Date.now() - lastGoogle > 3 * 3600 * 1000) {
    const g = await submitSitemapToGoogle();
    next.google = g.ok ? `ok (${g.site})` : `error: ${g.error}`;
    next.googleAt = now;
    if (g.account) next.account = g.account;
  }
  await ref.set({ pages, status: next, updatedAt: new Date() });
  console.log('seoAnnounce', JSON.stringify({ changed: changed.length, google: next.google, indexnow: next.indexnow }));
}

exports.seoPing = onDocumentWritten({ document: 'catalog/main', region: REGION, timeoutSeconds: 120 }, async () => {
  await seoAnnounce();
});

// Once a week Google is asked to read the sitemap again even if nothing changed.
exports.seoWeekly = onSchedule({ schedule: 'every monday 09:00', timeZone: 'Asia/Kolkata', region: REGION }, async () => {
  await seoAnnounce({ force: true });
});

exports.seo = onRequest({ region: REGION, memory: '256MiB', maxInstances: 5, concurrency: 40 }, seo.handler(db));
