// Google-friendly pages for the web store (Firebase Hosting rewrites here).
//   /p/<slug>          one page per product   (Product rich results: price, stock, stars)
//   /recipe/<slug>     one page per recipe    (Recipe rich results: photo, time, steps)
//   /shop/<slug>       brand pages: Madhura Millets, Madhura Rice, Madhura Cattle Feeds
//   /prices            today's price list (price per kg, every pack)
//   /faq               questions & answers
//   /policy/<name>     shipping, returns, privacy, terms, contact (Google Shopping and
//                      payment gateways ask for these)
//   /ta, /ta/...       the same pages in Tamil (hreflang links connect each pair)
//   /sitemap.xml       every page in English and Tamil, always current
//   /feed.xml          product feed for Google Merchant Center (free Shopping listings)
//   /robots.txt        points Google at the sitemap
//   /img/<id>.jpg      stored product/site photos as real image addresses
//   /main-host         which web address is the main one (used by the website and the app)
// Main address: madhuraagro.in. Until it is connected in Firebase and
// working, everything stays on the old .web.app address. As soon as it
// answers, the old addresses send people and Google there (301).
// People get the normal store (index.html), which opens the right product,
// recipe or section; Google and link previews (WhatsApp, Instagram) get
// proper titles, photos and data.

const MIN = 60 * 1000;
const MAIN_HOST = 'madhuraagro.in';
// Set to true once madhuraagro.in was checked working with the padlock
// (16 Oct 2026). The automatic check below then isn't needed.
const MAIN_CONNECTED = true;
// The project's own Firebase addresses (and www.) move to the main address.
const isOldHost = (host) => /\.(web\.app|firebaseapp\.com)$/i.test(host) || host.toLowerCase() === `www.${MAIN_HOST}`;
const DEFAULT_SHOP = 'Sri Madhura Agro Traders';

// ---- shared with the website (the same code is in public/js/app.js) ----
function slugify(s) {
  return String(s || '').toLowerCase().normalize('NFKD').replace(/[^\x00-\x7f]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'item';
}
// Same name twice -> ragi, ragi-2 (ordered by id, so both sides agree)
function productSlugs(products) {
  const groups = new Map();
  for (const p of products) {
    const base = slugify(p.name);
    if (!groups.has(base)) groups.set(base, []);
    groups.get(base).push(p.id);
  }
  const out = new Map();
  for (const [base, ids] of groups) [...ids].sort().forEach((id, i) => out.set(id, i ? `${base}-${i + 1}` : base));
  return out;
}
const recipeSlug = (r) => slugify(r.id);
const lc = (s) => String(s || '').toLowerCase();
const TAMIL = /[\u0B80-\u0BFF]/;
// Names customers type (public/data/names.json): the first matching entry wins.
function entryFor(p, names) {
  const hay = lc(`${p.name || ''} ${p.nameLocal || ''}`);
  return ((names && names.entries) || []).find((e) => (e.match || []).some((m) => hay.includes(lc(m)))) || null;
}
const CATTLE_RE = /cattle|feed|poultry|bran|husk|cake|pellet|theevanam|தீவன|கால்நடை/;
const RICE_RE = /rice|arisi|அரிசி/;
const MILLET_RE = /millet|grain|gram|flour|pulse|dal|சிறுதானி|தானிய/;
// Which brand a product belongs to: millets, rice, cattle (or '' if none).
function brandOf(p, names) {
  const c = lc(`${p.category || ''} ${p.subcategory || ''}`);
  if (CATTLE_RE.test(c)) return 'cattle';
  const e = entryFor(p, names);
  if (e && e.brand) return e.brand;
  if (RICE_RE.test(c)) return 'rice';
  if (MILLET_RE.test(c)) return 'millets';
  return '';
}
// "Also called" names: the shop's own first, then the dictionary's.
function aliasesFor(p, names) {
  const name = String(p.name || '');
  const local = String(p.nameLocal || '');
  const hay = lc(`${name} ${local}`);
  const has = (list) => (list || []).some((m) => hay.includes(lc(m)));
  const out = [];
  const add = (x) => { const v = String(x || '').trim(); if (v) out.push(v); };
  (Array.isArray(p.aliases) ? p.aliases : []).forEach(add);
  const e = entryFor(p, names);
  if (e) {
    // Form words (flour, rava...) must be whole words: "matta" is not "atta".
    const ws = words(hay);
    const form = ((names && names.forms) || []).find((f) => (f.match || []).some((m) => {
      const w = lc(m);
      return /\s/.test(w) || TAMIL.test(w) ? hay.includes(w) : ws.includes(w);
    }));
    const word = (x, k) => (form ? `${x} ${form[k]}` : x);
    (e.variants || []).filter((v) => has(v.match))
      .forEach((v) => ['en', 'tl', 'ta'].forEach((k) => (v[k] || []).forEach((x) => add(word(x, k)))));
    const en = e.en || [];
    const tl = e.tl || [];
    if (en[0]) add(word(en[0], 'en'));
    if (tl[0]) add(word(tl[0], 'tl'));
    tl.slice(1).forEach((x) => add(word(x, 'tl')));
    en.slice(1).forEach((x) => add(word(x, 'en')));
    (e.ta || []).forEach((x) => add(word(x, 'ta')));
  } else if (brandOf(p, names) === 'rice' && !RICE_RE.test(lc(name))) {
    const base = name.replace(/\([^)]*\)/g, ' ').replace(/\s+/g, ' ').trim();
    if (base) { add(`${base} rice`); add(`${base} arisi`); }
  }
  const nl = lc(name);
  const ll = lc(local);
  const seen = new Set();
  return out.filter((x) => {
    const k = lc(x);
    if (seen.has(k) || nl.includes(k) || (ll && ll.includes(k))) return false;
    seen.add(k);
    return true;
  }).slice(0, 10);
}
function usesFor(p, names, lang) {
  const e = entryFor(p, names);
  return (e && e.uses && (e.uses[lang] || e.uses.en)) || '';
}
const words = (s) => lc(s).split(/[^a-z0-9\u0B80-\u0BFF]+/).filter(Boolean);
// Recipes that use a product: linked in the app, or named after its grain.
function recipesFor(p, recipes, names) {
  const e = entryFor(p, names);
  const keys = new Set(((e && e.recipeKeys) || []).map(lc));
  return (recipes || []).filter((r) => (Array.isArray(r.products) && r.products.includes(p.id))
    || words(`${r.id} ${r.name}`).some((w) => keys.has(w)));
}
// Brand pages first (Madhura Millets, Rice, Cattle Feeds), then any
// category whose products have no brand.
function shopPages(products, names) {
  const pages = [];
  const brands = (names && names.brands) || {};
  for (const b of ['millets', 'rice', 'cattle']) {
    const items = products.filter((p) => brandOf(p, names) === b);
    if (items.length && brands[b]) pages.push({ key: b, brand: b, slug: brands[b].slug, items });
  }
  const used = new Set(pages.map((x) => x.slug));
  const loose = products.filter((p) => !brandOf(p, names));
  for (const c of [...new Set(loose.map((p) => String(p.category || 'Other')))].sort()) {
    let slug = slugify(c);
    if (used.has(slug)) slug = `${slug}-items`;
    used.add(slug);
    pages.push({ key: `cat:${c}`, brand: '', category: c, slug, items: loose.filter((p) => String(p.category || 'Other') === c) });
  }
  return pages;
}
// Delivery, hours and contact words used in the FAQ and policies.
function shopVars(cat, lang) {
  const s = (cat && cat.store) || {};
  const site = (cat && cat.site) || {};
  const ta = lang === 'ta';
  const wa = String(s.whatsapp || '').replace(/\D/g, '');
  const waText = wa.length === 10 ? `+91 ${wa}` : wa.length > 10 ? `+${wa}` : '';
  const phone = String(site.phone || '').replace(/[^0-9+]/g, '');
  const email = /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(site.email || '').trim()) ? String(site.email).trim() : '';
  const addr = String(s.pickupAddress || s.address || '').trim();
  const sh = s.shipping || {};
  const zoneFree = sh.enabled === true ? Number(sh.rates && sh.rates.local && sh.rates.local.freeAbove) || 0 : 0;
  const flatFree = sh.enabled === true ? 0 : Number(s.freeDeliveryAbove) || 0;
  const amt = Math.round(zoneFree || flatFree);
  let free = '';
  if (amt > 0) {
    free = zoneFree
      ? (ta ? ` உள்ளூரில் ₹${amt}க்கு மேல் ஆர்டருக்கு இலவச டெலிவரி.` : ` Free local delivery on orders above ₹${amt}.`)
      : (ta ? ` ₹${amt}க்கு மேல் ஆர்டருக்கு இலவச டெலிவரி.` : ` Free delivery on orders above ₹${amt}.`);
  }
  const contact = [waText && `WhatsApp ${waText}`, phone && phone.replace(/\D/g, '').slice(-10) !== wa.slice(-10) ? `${ta ? 'போன்' : 'phone'} ${phone}` : '', email]
    .filter(Boolean).join(' · ');
  const str = (v) => (typeof v === 'string' ? v.trim() : '');
  return {
    shop: (ta && str(s.nameLocal)) || str(s.name) || DEFAULT_SHOP,
    free,
    hours: (ta && str(site.hoursLocal)) || str(site.hours) || str(s.hours) || (ta ? 'அனைத்து நாட்களும் · காலை 8 – இரவு 8' : 'Open all days · 8 AM – 8 PM'),
    dispatch: (ta && str(site.dispatchTimeLocal)) || str(site.dispatchTime) || (ta ? '1–2 வேலை நாட்களுக்குள்' : '1–2 working days'),
    pickup: addr ? `: ${addr}` : '',
    wa: waText ? ` (${waText})` : '',
    contact: contact ? `: ${contact}` : '',
    // raw values for the contact page
    _wa: waText, _waNum: wa.length === 10 ? `91${wa}` : wa, _phone: phone, _email: email, _addr: addr,
    _owner: str((site.owner && site.owner.name) || ''),
    _fssai: str(site.fssai).replace(/[^0-9A-Za-z ]/g, '').slice(0, 20), _map: /^https:\/\//i.test(str(site.mapUrl)) ? str(site.mapUrl) : '',
  };
}
const fillVars = (text, vars) => String(text || '').replace(/\{(\w+)\}/g, (m, k) => (vars[k] != null && !k.startsWith('_') ? vars[k] : ''));
// Policy paragraphs: the shop's own text (set in the app) or the standard text.
function policyLines(policies, key, cat, lang) {
  const site = (cat && cat.site) || {};
  const own = { shipping: 'shippingPolicy', returns: 'returnPolicy' }[key];
  if (own) {
    const text = (lang === 'ta' && String(site[`${own}Local`] || '').trim()) || String(site[own] || '').trim();
    if (text) return text.split('\n').map((x) => x.trim()).filter(Boolean);
  }
  const page = policies && policies.pages && policies.pages[key];
  const body = (page && page.body && (page.body[lang] || page.body.en)) || [];
  const vars = shopVars(cat, lang);
  return body.map((x) => fillVars(x, vars));
}
function faqItems(faq, cat, lang) {
  const vars = shopVars(cat, lang);
  return (Array.isArray(faq) ? faq : []).filter((f) => f && f.q && f.a).map((f) => ({
    id: String(f.id || ''),
    q: fillVars((lang === 'ta' && f.q.ta) || f.q.en, vars),
    a: fillVars((lang === 'ta' && f.a.ta) || f.a.en, vars),
  }));
}

// ---- helpers ----
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clip = (s, n) => { const t = String(s || '').replace(/\s+/g, ' ').trim(); return t.length > n ? `${t.slice(0, n - 1)}…` : t; };
const imgUrl = (origin, image) => {
  if (!image) return `${origin}/icons/icon-512.png`;
  if (/^https?:\/\//i.test(image)) return image;
  if (String(image).startsWith('fs:')) {
    const [, id, v] = String(image).split(':');
    return `${origin}/img/${encodeURIComponent(id)}.jpg${v ? `?v=${encodeURIComponent(v)}` : ''}`;
  }
  return `${origin}/images/products/${encodeURIComponent(image)}`;
};
const priceOf = (pack) => (pack ? Math.round(Number(pack.offerPrice || pack.price) || 0) : 0);
const validPacks = (p) => (Array.isArray(p.packs) ? p.packs : []).filter((k) => k && k.label && Number(k.price) > 0)
  .map((k) => ({ ...k, price: Math.round(Number(k.price)), offerPrice: Math.round(Number(k.offerPrice)) > 0 && Math.round(Number(k.offerPrice)) < Math.round(Number(k.price)) ? Math.round(Number(k.offerPrice)) : null }));
const mainPack = (p) => validPacks(p).find((k) => k.isDefault) || validPacks(p)[0] || null;
// Grievance officer line (Consumer Protection (E-Commerce) Rules): who handles
// complaints, how to reach them, and the response times.
function grievanceLine(v, lang) {
  const who = v._owner || v.shop;
  const how = [v._phone || v._wa, v._email].filter(Boolean).join(' · ');
  return lang === 'ta'
    ? `${who}${how ? ` · ${how}` : ''}. புகார்களை 48 மணி நேரத்தில் ஏற்று, ஒரு மாதத்துக்குள் தீர்க்கிறோம்.`
    : `${who}${how ? ` · ${how}` : ''}. We acknowledge complaints within 48 hours and resolve them within one month.`;
}

// ---- Prior price (Consumer Protection (E-Commerce) Amendment Rules 2026, from 1 Jan 2027):
// when a price cut is shown, the struck-out price must be the LOWEST price of the
// 30 days before the cut. The server keeps each pack's price history and works out
// that price (price_history/_prior: { id: { packLabel: { w: price, k: known } } }).
// Offers whose 30-day low isn't higher than the offer show no "was" price.
const PRIOR_RULE_FROM = Date.parse('2027-01-01T00:00:00+05:30');
function applyPrior(raw, prior, now = Date.now()) {
  if (!raw || !Array.isArray(raw.products)) return raw;
  const strict = now >= PRIOR_RULE_FROM;
  const fix = (entry, price, offer) => {
    if (!(offer > 0 && offer < price)) return [price, offer];
    if (entry && entry.k) return entry.w > offer ? [entry.w, offer] : [offer, null];
    return strict ? [offer, null] : [price, offer];
  };
  return {
    ...raw,
    products: raw.products.map((p) => {
      if (!p) return p;
      const e = (prior && prior[p.id]) || {};
      const out = { ...p };
      if (Array.isArray(p.packs)) {
        out.packs = p.packs.map((k) => {
          if (!k) return k;
          const [price, offer] = fix(e[k.label], Math.round(Number(k.price) || 0), Math.round(Number(k.offerPrice) || 0));
          return { ...k, price, offerPrice: offer || null };
        });
      }
      if (p.byWeight && Number(p.offerPerKg) > 0) {
        const [per, off] = fix(e['1 kg'], Number(p.pricePerKg) || 0, Number(p.offerPerKg) || 0);
        out.pricePerKg = per;
        out.offerPerKg = off || 0;
      }
      return out;
    }),
  };
}

// Lowest price in the 30 days before the current price began (series of
// {d: 'YYYY-MM-DD', p}). Known only when the history covers that whole window.
function priorOf(series) {
  const DAY = 86400000;
  const dayMs = (d) => Date.parse(`${d}T00:00:00Z`);
  if (!Array.isArray(series) || !series.length) return { k: false };
  const cur = series[series.length - 1].p;
  let j = series.length - 1;
  while (j > 0 && series[j - 1].p === cur) j--;
  if (j === 0) return { k: false };
  const start = dayMs(series[j].d);
  const from = start - 30 * DAY;
  if (dayMs(series[0].d) > from) return { k: false };
  const inWindow = [];
  for (let i = 0; i < j; i++) {
    const next = dayMs(series[i + 1].d);
    if (next > from && dayMs(series[i].d) < start) inWindow.push(series[i].p);
  }
  return inWindow.length ? { k: true, w: Math.min(...inWindow) } : { k: false };
}

// The grain's name in Hindi, Telugu, Kannada and Malayalam (names.json "lang"),
// e.g. [['Telugu', 'Sajjalu (సజ్జలు)'], ...] — people search "kambu in telugu".
function otherLangs(p, names, lang) {
  const e = entryFor(p, names);
  if (!e || !e.lang) return [];
  const label = (lang === 'ta' && names.languagesTa) || names.languages || {};
  return ['te', 'hi', 'kn', 'ml'].filter((k) => e.lang[k]).map((k) => [label[k] || k, e.lang[k]]);
}
const latinOf = (s) => String(s).replace(/\s*\([^)]*\)\s*$/, '');

// The price kept in the price history: per kg for loose items, else the
// main pack. { p: today's price, m: regular price, l: what it is for }.
function historyPrice(p) {
  const per = Math.round(Number(p.pricePerKg) || 0);
  if (p.byWeight && per > 0) {
    const offer = Math.round(Number(p.offerPerKg) || 0);
    return { p: offer > 0 && offer < per ? offer : per, m: per, l: '1 kg' };
  }
  const k = mainPack(p);
  return k ? { p: priceOf(k), m: k.price, l: String(k.label) } : null;
}
const shortName = (p, lang) => String((lang === 'ta' && p.nameLocal) || p.name || '').replace(/\([^)]*\)/g, '').replace(/[-–]\s*$/, '').trim();
const pathFor = (lang, path) => (lang === 'ta' ? (path === '/' ? '/ta/' : `/ta${path}`) : path);
const T = (lang, en, ta) => (lang === 'ta' && ta ? ta : en);
const brandName = (names, b, lang) => {
  const x = names && names.brands && names.brands[b];
  return x ? ((lang === 'ta' && x.name.ta) || x.name.en) : '';
};
// Feed brands named in the product itself, e.g. "KNC Special 50kg" -> KNC.
function makerOf(p, names) {
  if (brandOf(p, names) !== 'cattle') return '';
  const m = /^([A-Z]{2,5})\b/.exec(String(p.name || '').trim());
  return m ? m[1] : '';
}
// What the website shows: same rules as the store (packs with a price, categories not hidden).
function visibleProducts(cat) {
  const hidden = new Set((Array.isArray(cat.hiddenCategories) ? cat.hiddenCategories : []).map(String));
  return (Array.isArray(cat.products) ? cat.products : [])
    .filter((p) => p && p.id && p.name && validPacks(p).length && !hidden.has(String(p.category || 'Other')));
}
const shopName = (cat, lang) => shopVars(cat, lang).shop;

function headTags({ title, description, url, canonical, image, type, jsonld, lang, alternates }) {
  const ld = (Array.isArray(jsonld) ? jsonld : [jsonld]).filter(Boolean);
  return [
    `<title>${esc(title)}</title>`,
    `<meta name="description" content="${esc(description)}">`,
    `<link rel="canonical" href="${esc(canonical || url)}">`,
    ...(alternates || []).map((a) => `<link rel="alternate" hreflang="${a.lang}" href="${esc(a.href)}">`),
    `<meta property="og:type" content="${esc(type)}">`,
    `<meta property="og:locale" content="${lang === 'ta' ? 'ta_IN' : 'en_IN'}">`,
    `<meta property="og:title" content="${esc(title)}">`,
    `<meta property="og:description" content="${esc(description)}">`,
    `<meta property="og:url" content="${esc(url)}">`,
    `<meta property="og:image" content="${esc(image)}">`,
    '<meta name="twitter:card" content="summary_large_image">',
    ...ld.map((j) => `<script type="application/ld+json">${JSON.stringify(j).replace(/</g, '\\u003c')}</script>`),
  ].join('\n    ');
}
const altLinks = (origin, path) => [
  { lang: 'en', href: `${origin}${path}` },
  { lang: 'ta', href: `${origin}${pathFor('ta', path)}` },
  { lang: 'x-default', href: `${origin}${path}` },
];

// Put our tags into the store's own index.html (old title/og/alternate tags removed)
function inject(baseHtml, head, block, lang = 'en') {
  let html = baseHtml.replace(/<title>[\s\S]*?<\/title>/i, '')
    .replace(/<meta\s+(?:property="og:[^"]*"|name="description"|name="twitter:[^"]*")[^>]*>\s*/gi, '')
    .replace(/<link\s+rel="(?:canonical|alternate)"[^>]*>\s*/gi, '')
    .replace(/<script type="application\/ld\+json">[\s\S]*?<\/script>\s*/gi, ''); // the home page's own shop data
  html = html.replace(/<html lang="[^"]*">/i, `<html lang="${lang === 'ta' ? 'ta' : 'en'}">`);
  html = html.replace(/<head>/i, `<head>\n    ${head}`);
  // The page's own content goes FIRST (above the store), so Google sees what
  // this page is about before the shared shop sections; the home hero is hidden.
  html = html.replace(/<body>/i, '<body class="seo-page">');
  if (/<section class="promo"/i.test(html)) return html.replace(/<section class="promo"/i, `${block}\n  <section class="promo"`);
  return html.replace(/<footer class="foot">/i, `${block}\n  <footer class="foot">`);
}
const crumbs = (origin, lang, items) => ({
  '@context': 'https://schema.org', '@type': 'BreadcrumbList',
  itemListElement: items.map(([name, path], i) => ({ '@type': 'ListItem', position: i + 1, name, item: `${origin}${pathFor(lang, path)}` })),
});
const crumbNav = (lang, items) => `<nav class="crumbs">${items.map(([name, path], i) =>
  (i < items.length - 1 ? `<a href="${esc(pathFor(lang, path))}">${esc(name)}</a>` : `<span>${esc(name)}</span>`)).join(' › ')}</nav>`;
const homeWord = (lang) => T(lang, 'Home', 'முகப்பு');
// Kilograms in a pack ("500 g" -> 0.5, "50 kg bag" -> 50), 0 if unknown.
function kgOf(k) {
  if (Number(k.kg) > 0) return Number(k.kg);
  const m = /(\d+(?:\.\d+)?)\s*(kg|kgs|kilo|g|gm|gms|gram|grams)\b/i.exec(String(k.label || ''));
  return m ? Number(m[1]) * (/^k/i.test(m[2]) ? 1 : 0.001) : 0;
}
// Today's price per kg: the shop's per-kg rate, else worked out from a pack size.
function rateOf(p) {
  const per = Number(p.pricePerKg) || 0;
  const offer = Number(p.offerPerKg) || 0;
  if (p.byWeight && per > 0) return Math.round(offer > 0 && offer < per ? offer : per);
  const packs = validPacks(p);
  const k = packs.find((x) => kgOf(x) > 0);
  if (k) return Math.round(priceOf(k) / kgOf(k));
  // One bag whose size is in the product name, e.g. "KNC Special 50kg" sold as "1 Nos".
  const inName = packs.length === 1 ? kgOf({ label: p.name }) : 0;
  return inName > 0 ? Math.round(priceOf(packs[0]) / inName) : 0;
}
const joinList = (arr, lang) => (arr.length < 2 ? arr.join('')
  : lang === 'ta' ? arr.join(', ') : `${arr.slice(0, -1).join(', ')} and ${arr[arr.length - 1]}`);
const sizeLike = (l) => /\d\s*(kg|kgs|g|gm|gms|l|ltr|ml)\b|bag|pack|packet|மூட்டை/i.test(String(l));
// One product-specific sentence (names, uses, sizes, price per kg), so no
// two product pages read the same to Google.
function summaryOf(p, names, cat, lang) {
  const ta = lang === 'ta';
  const brand = brandOf(p, names);
  const from = makerOf(p, names) ? shopName(cat, lang) : (brandName(names, brand, lang) || shopName(cat, lang));
  const aliases = aliasesFor(p, names).filter((a) => (ta ? TAMIL.test(a) : !TAMIL.test(a))).slice(0, 2);
  const uses = usesFor(p, names, lang);
  const sizes = validPacks(p).map((k) => k.label).filter(sizeLike);
  const rate = rateOf(p);
  const name = ta ? (p.nameLocal || p.name) : p.name;
  const main = mainPack(p);
  if (ta) {
    return `${name}${aliases.length ? ` (${aliases.join(', ')})` : ''} — ${from}. ${uses ? `${uses} செய்ய ஏற்றது. ` : ''}`
      + (sizes.length ? `${joinList(sizes, 'ta')} அளவுகளில் கிடைக்கும்${rate ? ` (கிலோ ₹${rate})` : ''}.` : `விலை ₹${priceOf(main)}${rate ? ` (கிலோ ₹${rate})` : ''}.`);
  }
  return `${name}${aliases.length ? ` (also called ${aliases.join(', ')})` : ''} from ${from}. ${uses ? `Good for ${uses}. ` : ''}`
    + (sizes.length ? `Available in ${joinList(sizes, 'en')}${rate ? ` (₹${rate} per kg)` : ''}.` : `Price ₹${priceOf(main)}${rate ? ` (₹${rate} per kg)` : ''}.`);
}

function productPage(ctx, p, slug, packParam) {
  const { cat, names, origin, lang, base } = ctx;
  const ta = lang === 'ta';
  const shop = shopName(cat, lang);
  const aliases = aliasesFor(p, names);
  const latin = aliases.filter((a) => !TAMIL.test(a));
  const brand = brandOf(p, names);
  const pages = shopPages(visibleProducts(cat), names);
  const page = pages.find((x) => x.items.some((i) => i.id === p.id));
  const pageName = page ? (page.brand ? brandName(names, page.brand, lang) : page.category) : '';
  const packs = validPacks(p);
  const chosen = packParam ? packs.find((k) => k.label === packParam) : null;
  const pack = chosen || mainPack(p);
  const price = priceOf(pack);
  const path = `/p/${slug}`;
  const canonical = `${origin}${pathFor(lang, path)}`;
  const url = chosen ? `${canonical}?pack=${encodeURIComponent(chosen.label)}` : canonical;
  const image = imgUrl(origin, p.image);
  const nameMain = ta ? (p.nameLocal || p.name) : p.name;
  const list = (en, tam) => (ta && Array.isArray(tam) && tam.length ? tam : (Array.isArray(en) ? en : []));
  const desc = (ta && p.descriptionLocal) || p.description || '';
  const benefits = list(p.benefits, p.benefitsLocal);
  const howTo = list(p.howTo, p.howToLocal);
  const uses = usesFor(p, names, lang);
  const about = clip(desc || benefits.join('. ') || (uses ? T(lang, `Good for ${uses}.`, `${uses} செய்ய ஏற்றது.`) : '') || `${nameMain} – ${shop}`, 300);
  const summary = summaryOf(p, names, cat, lang);
  const langs = otherLangs(p, names, lang);
  const grain = shortName(p, lang);
  // Buyer-style titles, most-searched words first (cut by Google after ~60 characters).
  const rate = rateOf(p);
  const brandLabel = brandName(names, brand, lang) || shop;
  const priceBit = rate ? T(lang, `₹${rate}/kg`, `₹${rate}/கிலோ`) : `₹${price}`;
  const latinShort = latin.filter((a) => !lc(a).includes(lc(grain))).slice(0, 2);
  const title = ta
    ? `${shortName(p, 'ta')}${p.nameLocal ? ` (${shortName(p, 'en')})` : ''} வாங்க – ${priceBit} | ${brandLabel}`
    : `Buy ${grain}${latinShort.length ? ` (${latinShort.join(', ')})` : ''} Online – ${priceBit} | ${brandLabel}`;
  const description = clip(ta
    ? `${nameMain}${p.nameLocal ? ` (${shortName(p, 'en')})` : ''}${langs.length ? ` · ${langs.slice(0, 2).map(([, n]) => latinOf(n)).join(', ')}` : ''}${pack ? ` · ${pack.label}` : ''} ₹${price}. ${about}`
    : `${p.name}${latin.length ? ` (${latin.slice(0, 3).join(', ')})` : ''}${langs.length ? ` · ${langs.slice(0, 2).map(([l, n]) => `${l}: ${latinOf(n)}`).join(', ')}` : ''}${pack ? ` – ${pack.label}` : ''} ₹${price}. ${about}`, 160);
  const out = p.inStock === false;
  const offerOf = (k) => ({
    '@type': 'Offer', price: priceOf(k).toFixed(2), priceCurrency: 'INR', name: k.label,
    availability: out ? 'https://schema.org/OutOfStock' : 'https://schema.org/InStock',
    itemCondition: 'https://schema.org/NewCondition', url: `${canonical}?pack=${encodeURIComponent(k.label)}`,
  });
  const offers = chosen || packs.length === 1 ? offerOf(chosen || packs[0]) : {
    '@type': 'AggregateOffer', priceCurrency: 'INR', offerCount: packs.length, offers: packs.map(offerOf),
    lowPrice: Math.min(...packs.map(priceOf)).toFixed(2), highPrice: Math.max(...packs.map(priceOf)).toFixed(2),
  };
  const jsonld = {
    '@context': 'https://schema.org', '@type': 'Product', name: nameMain, image: [image], description: clip(`${summary} ${about}`, 500), sku: String(p.id),
    brand: { '@type': 'Brand', name: makerOf(p, names) || brandName(names, brand, 'en') || shopName(cat, 'en') },
    offers,
  };
  if (aliases.length || langs.length) jsonld.alternateName = [...aliases, ...langs.map(([, n]) => latinOf(n))];
  if (p.category) jsonld.category = p.category;
  if (p.rating && Number(p.rating.count) > 0) {
    jsonld.aggregateRating = { '@type': 'AggregateRating', ratingValue: Number(p.rating.avg).toFixed(1), reviewCount: Number(p.rating.count), bestRating: 5, worstRating: 1 };
    const reviews = (Array.isArray(p.reviews) ? p.reviews : []).filter((r) => r && String(r.name || '').trim() && Number(r.stars) >= 1).slice(0, 5);
    if (reviews.length) {
      jsonld.review = reviews.map((r) => ({
        '@type': 'Review', author: { '@type': 'Person', name: String(r.name).trim().slice(0, 40) },
        reviewRating: { '@type': 'Rating', ratingValue: Math.min(5, Math.round(Number(r.stars))), bestRating: 5, worstRating: 1 },
        ...(r.text ? { reviewBody: clip(r.text, 400) } : {}),
      }));
    }
  }
  const trail = [[homeWord(lang), '/'], ...(page ? [[pageName, `/shop/${page.slug}`]] : []), [nameMain, path]];
  const slugs = productSlugs(visibleProducts(cat));
  const faqBlock = productFaq(p, packs, names, cat, lang, grain, langs, brand);
  const recipes = recipesFor(p, cat.recipes, names);
  const more = page ? page.items.filter((x) => x.id !== p.id && x.inStock !== false).slice(0, 6) : [];
  const steps = howTo.length ? `<h2>${esc(T(lang, brand === 'cattle' ? 'How to use' : 'How to cook', brand === 'cattle' ? 'பயன்படுத்தும் முறை' : 'சமைக்கும் முறை'))}</h2><ol>${howTo.map((x) => `<li>${esc(x)}</li>`).join('')}</ol>` : '';
  const block = `<section class="seo-block wrap" aria-label="${esc(nameMain)}">
    ${crumbNav(lang, trail)}
    <h1>${esc(nameMain)}${ta ? (p.nameLocal ? ` <span lang="en">· ${esc(p.name)}</span>` : '') : (p.nameLocal ? ` <span lang="ta">· ${esc(p.nameLocal)}</span>` : '')}</h1>
    ${p.image ? `<img class="seo-img" src="${esc(image)}" alt="${esc(`${nameMain}${!ta && latin.length ? ` – ${latin.slice(0, 2).join(', ')}` : ''}${pageName ? ` | ${pageName}` : ''}`)}" width="320" height="320" loading="lazy" decoding="async">` : ''}
    ${aliases.length ? `<p class="also">${esc(T(lang, 'Also called', 'மற்ற பெயர்கள்'))}: ${esc(aliases.join(' · '))}</p>` : ''}
    <p>${packs.map((k) => `${esc(k.label)}: ₹${priceOf(k)}`).join(' · ')}${out ? ` · ${esc(T(lang, 'Out of stock', 'இருப்பு இல்லை'))}` : ''} · <a href="${esc(pathFor(lang, '/prices'))}">${esc(T(lang, 'All prices today', 'இன்றைய அனைத்து விலைகள்'))}</a></p>
    <p>${esc(summary)}</p>
    <p>${esc(about)}</p>
    ${uses ? `<p><strong>${esc(T(lang, 'Good for', 'இதற்கு ஏற்றது'))}:</strong> ${esc(uses)}</p>` : ''}
    ${specsHTML(p, packs, names, cat, lang, brandLabel, aliases)}
    ${langs.length ? `<h2>${esc(T(lang, `${grain} in Telugu, Hindi, Kannada and Malayalam`, `${grain} — பிற மொழிகளில்`))}</h2>
    <ul>${langs.map(([l, n]) => `<li>${esc(T(lang, `${grain} in ${l}`, `${l}`))}: <strong>${esc(n)}</strong></li>`).join('')}</ul>
    <p class="also"><a href="${esc(pathFor(lang, '/guide/millet-names'))}">${esc(T(lang, 'All millet names in every language →', 'அனைத்து சிறுதானியப் பெயர்கள் →'))}</a></p>` : ''}
    ${steps}
    ${recipes.length ? `<h2>${esc(T(lang, 'Recipes', 'சமையல் குறிப்புகள்'))}</h2><ul>${recipes.map((r) => `<li><a href="${esc(pathFor(lang, `/recipe/${recipeSlug(r)}`))}">${esc((ta && r.nameLocal) || r.name)}</a></li>`).join('')}</ul>` : ''}
    ${faqBlock.html}
    ${more.length ? `<h2>${esc(T(lang, `More from ${pageName}`, `${pageName} — மேலும்`))}</h2><ul>${more.map((x) => `<li><a href="${esc(pathFor(lang, `/p/${slugs.get(x.id)}`))}">${esc(ta ? (x.nameLocal || x.name) : x.name)}</a></li>`).join('')}</ul>` : ''}
  </section>`;
  return inject(base, headTags({
    title, description, url, canonical, image, type: 'product', lang,
    jsonld: [jsonld, crumbs(origin, lang, trail), faqBlock.jsonld], alternates: altLinks(origin, path),
  }), block, lang);
}

// Specifications table (like big shopping sites): brand, type, packs, price per kg…
function specsHTML(p, packs, names, cat, lang, brandLabel, aliases) {
  const v = shopVars(cat, lang);
  const rate = rateOf(p);
  const rows = [
    [T(lang, 'Brand', 'பிராண்ட்'), brandLabel],
    [T(lang, 'Type', 'வகை'), [p.category, p.subcategory].filter((x) => x && !/^(human|other)$/i.test(String(x).trim())).join(' · ')],
    [T(lang, 'Pack sizes', 'அளவுகள்'), packs.map((k) => k.label).join(', ')],
    [T(lang, 'Price per kg', 'கிலோ விலை'), rate ? `₹${rate}` : ''],
    [T(lang, 'Also called', 'மற்ற பெயர்கள்'), aliases.slice(0, 4).join(', ')],
    [T(lang, 'Storage', 'சேமிப்பு'), T(lang, 'Airtight container, in a cool and dry place', 'காற்றுப் புகாத டப்பாவில், குளிர்ந்த உலர்ந்த இடத்தில்')],
    [T(lang, 'Sold by', 'விற்பனையாளர்'), v.shop],
    [T(lang, 'FSSAI licence no.', 'FSSAI உரிம எண்'), v._fssai],
  ].filter(([, val]) => val);
  return `<h2>${esc(T(lang, 'Specifications', 'விவரங்கள்'))}</h2><table class="spec-table"><tbody>${rows.map(([k, val]) => `<tr><th>${esc(k)}</th><td>${esc(val)}</td></tr>`).join('')}</tbody></table>`;
}

// Questions people ask about this product, answered from the shop's own data.
function productFaq(p, packs, names, cat, lang, grain, langs, brand) {
  const v = shopVars(cat, lang);
  const uses = usesFor(p, names, lang);
  const qa = [];
  if (langs.length) {
    qa.push([T(lang, `What is ${grain} called in Telugu and Hindi?`, `${grain} தெலுங்கு, இந்தியில் என்ன பெயர்?`),
      langs.map(([l, n]) => `${l}: ${n}`).join(' · ')]);
  }
  if (uses && brand !== 'cattle') qa.push([T(lang, `How is ${grain} used?`, `${grain} எதற்குப் பயன்படும்?`), T(lang, `Good for ${uses}.`, `${uses} செய்ய ஏற்றது.`)]);
  qa.push([T(lang, `What is the price of ${grain}?`, `${grain} விலை என்ன?`),
    `${packs.map((k) => `${k.label}: ₹${priceOf(k)}`).join(' · ')}${rateOf(p) ? T(lang, ` (₹${rateOf(p)} per kg)`, ` (கிலோ ₹${rateOf(p)})`) : ''}.`]);
  qa.push([T(lang, 'Do you deliver?', 'டெலிவரி உண்டா?'),
    T(lang, `Yes — we dispatch within ${v.dispatch}.${v.free} Every order is confirmed on WhatsApp${v.wa}.`,
      `ஆம் — ${v.dispatch} அனுப்புகிறோம்.${v.free} ஒவ்வொரு ஆர்டரும் WhatsApp${v.wa}-ல் உறுதிசெய்யப்படும்.`)]);
  if (brand !== 'cattle') qa.push([T(lang, `How should I store ${grain}?`, `${grain}-ஐ எப்படி சேமிப்பது?`),
    T(lang, 'In an airtight container, in a cool and dry place, away from moisture.', 'காற்றுப் புகாத டப்பாவில், ஈரம் படாத குளிர்ந்த இடத்தில் வைக்கவும்.')]);
  const html = `<h2>${esc(T(lang, 'Questions & answers', 'கேள்விகளும் பதில்களும்'))}</h2>${qa.map(([q, a]) => `<h3>${esc(q)}</h3><p>${esc(a)}</p>`).join('')}`;
  const jsonld = { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: qa.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) };
  return { html, jsonld };
}

function recipePage(ctx, r, slug) {
  const { cat, names, origin, lang, base } = ctx;
  const ta = lang === 'ta';
  const shop = shopName(cat, lang);
  const pick = (en, tam) => (ta && Array.isArray(tam) && tam.length ? tam : (Array.isArray(en) ? en : []));
  const path = `/recipe/${slug}`;
  const url = `${origin}${pathFor(lang, path)}`;
  const image = imgUrl(origin, r.photo);
  const name = (ta && r.nameLocal) || r.name;
  const why = pick(r.benefits, r.benefitsLocal).join('. ');
  const ingredients = pick(r.ingredients, r.ingredientsLocal);
  const steps = pick(r.steps, r.stepsLocal);
  const title = ta
    ? `${name} செய்முறை | ${r.name} recipe in Tamil – ${shop}`
    : `${r.name} recipe${r.nameLocal ? ` (${r.nameLocal})` : ''} – Tamil style, easy steps | ${shop}`;
  const description = clip(ta
    ? `${name} செய்முறை${r.minutes ? ` — ${r.minutes} நிமிடத்தில்` : ''}. ${why}`
    : `${r.name} recipe${r.minutes ? ` in ${r.minutes} minutes` : ''}. ${why}`, 160);
  const jsonld = {
    '@context': 'https://schema.org', '@type': 'Recipe', name, image: [image], description: clip(why || name, 300),
    inLanguage: ta ? 'ta' : 'en',
    author: { '@type': 'Organization', name: shop }, recipeCuisine: 'South Indian',
    keywords: [r.name, r.nameLocal, 'millet recipe'].filter(Boolean).join(', '),
    recipeIngredient: ingredients,
    recipeInstructions: steps.map((s, i) => ({ '@type': 'HowToStep', position: i + 1, text: s })),
  };
  if (r.minutes) jsonld.totalTime = `PT${Number(r.minutes)}M`;
  if (r.serves) jsonld.recipeYield = `${Number(r.serves)} servings`;
  const products = visibleProducts(cat);
  const slugs = productSlugs(products);
  const used = products.filter((p) => recipesFor(p, [r], names).length);
  const trail = [[homeWord(lang), '/'], [name, path]];
  const block = `<section class="seo-block wrap" aria-label="${esc(name)}">
    ${crumbNav(lang, trail)}
    <h1>${esc(name)}${ta ? (r.nameLocal ? ` <span lang="en">(${esc(r.name)})</span>` : '') : (r.nameLocal ? ` <span lang="ta">(${esc(r.nameLocal)})</span>` : '')}</h1>
    ${r.photo ? `<img class="seo-img" src="${esc(image)}" alt="${esc(`${name} – ${T(lang, 'recipe', 'செய்முறை')}`)}" width="320" height="320" loading="lazy" decoding="async">` : ''}
    ${why ? `<p>${esc(why)}</p>` : ''}
    <h2>${esc(T(lang, 'Ingredients', 'தேவையான பொருட்கள்'))}</h2><ul>${ingredients.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>
    <h2>${esc(T(lang, 'Method', 'செய்முறை'))}</h2><ol>${steps.map((x) => `<li>${esc(x)}</li>`).join('')}</ol>
    ${used.length ? `<h2>${esc(T(lang, 'Buy the ingredients', 'பொருட்களை வாங்க'))}</h2><ul>${used.map((p) => `<li><a href="${esc(pathFor(lang, `/p/${slugs.get(p.id)}`))}">${esc(ta ? (p.nameLocal || p.name) : p.name)}</a></li>`).join('')}</ul>` : ''}
  </section>`;
  return inject(base, headTags({
    title, description, url, image, type: 'article', lang, jsonld: [jsonld, crumbs(origin, lang, trail)], alternates: altLinks(origin, path),
  }), block, lang);
}

function shopPage(ctx, page) {
  const { cat, names, origin, lang, base } = ctx;
  const ta = lang === 'ta';
  const shop = shopName(cat, lang);
  const b = page.brand ? names.brands[page.brand] : null;
  const label = b ? brandName(names, page.brand, lang) : page.category;
  const what = b ? ((ta && b.what.ta) || b.what.en) : page.category;
  const path = `/shop/${page.slug}`;
  const url = `${origin}${pathFor(lang, path)}`;
  const rank = (p) => { const e = entryFor(p, names); return e && e.rank ? e.rank : 99; };
  const items = [...page.items].sort((x, y) => Number(y.inStock !== false) - Number(x.inStock !== false) || rank(x) - rank(y) || String(x.name).localeCompare(String(y.name)));
  // Best-known names first (ragi, kambu, thinai…; cattle feed, oil cakes…), one per grain.
  const label4 = (p) => {
    const e = entryFor(p, names);
    if (e && page.brand === 'cattle') return (ta && e.ta && e.ta[0]) || e.en[0];
    return shortName(p, lang);
  };
  const seenTop = new Set();
  const top = [...page.items].sort((x, y) => rank(x) - rank(y) || String(x.name).localeCompare(String(y.name))).filter((p) => {
    const e = entryFor(p, names);
    const k = e ? e.id : shortName(p, lang);
    if (seenTop.has(k)) return false;
    seenTop.add(k);
    return true;
  }).map(label4).filter(Boolean).slice(0, 4);
  const title = ta
    ? `${label} – ${what} ஆன்லைனில் வாங்க${top.length ? `: ${top.join(', ')}` : ''} | ${shop}`
    : `${label} – Buy ${what} online${top.length ? `: ${top.join(', ')}` : ''} | ${shop}`;
  const intro = b ? ((ta && b.intro.ta) || b.intro.en) : '';
  const description = clip(`${intro || label} ${top.join(', ')}`, 160);
  const slugs = productSlugs(visibleProducts(cat));
  const link = (p) => pathFor(lang, `/p/${slugs.get(p.id)}`);
  const from = (p) => Math.min(...validPacks(p).map(priceOf));
  const guide = items.filter((p) => usesFor(p, names, lang));
  const recipes = (cat.recipes || []).filter((r) => items.some((p) => recipesFor(p, [r], names).length));
  const image = imgUrl(origin, (items.find((p) => p.image) || {}).image);
  const trail = [[homeWord(lang), '/'], [label, path]];
  const block = `<section class="seo-block wrap" aria-label="${esc(label)}">
    ${crumbNav(lang, trail)}
    <h1>${esc(label)}${b ? ` — ${esc(what)}` : ''}</h1>
    ${intro ? `<p>${esc(intro)}</p>` : ''}
    ${guide.length ? `<h2>${esc(T(lang, 'Which one for what', 'எது எதற்கு'))}</h2><ul>${guide.map((p) => {
    const al = aliasesFor(p, names).filter((a) => (ta ? TAMIL.test(a) : !TAMIL.test(a))).slice(0, 2);
    return `<li><a href="${esc(link(p))}">${esc(ta ? (p.nameLocal || p.name) : p.name)}</a>${al.length ? ` (${esc(al.join(', '))})` : ''} — ${esc(usesFor(p, names, lang))}</li>`;
  }).join('')}</ul>` : ''}
    <h2>${esc(T(lang, 'All products', 'அனைத்து பொருட்களும்'))}</h2>
    <ul class="seo-list">${items.map((p) => `<li>${p.image ? `<img class="seo-thumb" src="${esc(imgUrl(origin, p.image))}" alt="${esc(ta ? (p.nameLocal || p.name) : p.name)}" width="56" height="56" loading="lazy" decoding="async">` : ''}<a href="${esc(link(p))}">${esc(ta ? (p.nameLocal || p.name) : p.name)}</a> — ${esc(T(lang, 'from', 'முதல்'))} ₹${from(p)}${p.inStock === false ? ` · ${esc(T(lang, 'out of stock', 'இருப்பு இல்லை'))}` : ''}</li>`).join('')}</ul>
    <p><a href="${esc(pathFor(lang, '/prices'))}">${esc(T(lang, "Today's price list", 'இன்றைய விலைப் பட்டியல்'))}</a></p>
    ${recipes.length ? `<h2>${esc(T(lang, 'Recipes', 'சமையல் குறிப்புகள்'))}</h2><ul>${recipes.map((r) => `<li><a href="${esc(pathFor(lang, `/recipe/${recipeSlug(r)}`))}">${esc((ta && r.nameLocal) || r.name)}</a></li>`).join('')}</ul>` : ''}
  </section>`;
  const itemList = {
    '@context': 'https://schema.org', '@type': 'ItemList', name: label,
    itemListElement: items.map((p, i) => ({ '@type': 'ListItem', position: i + 1, url: `${origin}${link(p)}`, name: ta ? (p.nameLocal || p.name) : p.name })),
  };
  return inject(base, headTags({
    title, description, url, image, type: 'website', lang, jsonld: [itemList, crumbs(origin, lang, trail)], alternates: altLinks(origin, path),
  }), block, lang);
}

// ---- Guides: pages that answer what people search ("millet names in Tamil") ----
const GUIDES = ['millet-names', 'traditional-rice', 'how-to-cook-millets'];
// "Ragi (கேழ்வரகு, Finger millet) is Ragulu in Telugu, … and Muthari in Malayalam."
function langSentence(e, lang) {
  const en = { te: 'Telugu', hi: 'Hindi', kn: 'Kannada', ml: 'Malayalam' };
  const ta = { te: 'தெலுங்கில்', hi: 'இந்தியில்', kn: 'கன்னடத்தில்', ml: 'மலையாளத்தில்' };
  const keys = ['te', 'hi', 'kn', 'ml'].filter((k) => e.lang && e.lang[k]);
  if (lang === 'ta') return `${(e.ta || [])[0]} (${(e.en || [])[0]}) — ${keys.map((k) => `${ta[k]} ${e.lang[k]}`).join(', ')}.`;
  const parts = keys.map((k) => `${latinOf(e.lang[k])} in ${en[k]}`);
  const list = parts.length > 1 ? `${parts.slice(0, -1).join(', ')} and ${parts[parts.length - 1]}` : parts.join('');
  return `${(e.tl || [])[0]} (${(e.ta || [])[0]}, ${(e.en || [])[0]}) is ${list}.`;
}
function guidePage(ctx, slug) {
  const { cat, names, origin, lang, base } = ctx;
  const ta = lang === 'ta';
  const shop = shopName(cat, lang);
  const path = `/guide/${slug}`;
  const url = `${origin}${pathFor(lang, path)}`;
  const products = visibleProducts(cat);
  const slugs = productSlugs(products);
  const inShop = (e) => products.filter((p) => entryFor(p, names) === e);
  const shopCell = (e) => {
    const list = inShop(e);
    return list.length
      ? list.map((p) => `<a href="${esc(pathFor(lang, `/p/${slugs.get(p.id)}`))}">${esc(ta ? (p.nameLocal || p.name) : p.name)}</a>${rateOf(p) ? ` ₹${rateOf(p)}/${ta ? 'கிலோ' : 'kg'}` : ''}`).join('<br>')
      : '—';
  };
  const LANGS = ['te', 'hi', 'kn', 'ml'];
  const langLabel = (k) => ((ta && names.languagesTa) || names.languages || {})[k] || k;
  const table = (entries, withLangs) => `<div class="guide-table"><table class="price-table"><thead><tr>
      <th>${esc(T(lang, 'English', 'ஆங்கிலம்'))}</th><th>${esc(T(lang, 'Tamil', 'தமிழ்'))}</th>${withLangs
        ? LANGS.map((k) => `<th>${esc(langLabel(k))}</th>`).join('')
        : `<th>${esc(T(lang, 'Also called', 'வேறு பெயர்கள்'))}</th>`}<th>${esc(T(lang, 'Used for', 'பயன்பாடு'))}</th><th>${esc(T(lang, 'At our shop', 'எங்கள் கடையில்'))}</th></tr></thead><tbody>
      ${entries.map((e) => `<tr id="${esc(e.id)}"><td><strong>${esc((e.en || [])[0] || '')}</strong></td><td>${esc((e.ta || [])[0] || '')}<br><small>${esc((e.tl || [])[0] || '')}</small></td>
        ${withLangs
          ? LANGS.map((k) => `<td>${esc((e.lang && e.lang[k]) || '—')}</td>`).join('')
          : `<td>${esc([...(e.tl || []).slice(1), ...(e.en || []).slice(1)].slice(0, 4).join(', '))}</td>`}<td>${esc((e.uses && (e.uses[lang] || e.uses.en)) || '')}</td><td>${shopCell(e)}</td></tr>`).join('')}
      </tbody></table></div>`;
  const entries = (names && names.entries) || [];
  let heading; let intro; let body; let description;
  if (slug === 'millet-names') {
    heading = T(lang, 'Millet names in Tamil, English, Telugu, Hindi, Kannada & Malayalam', 'சிறுதானியங்களின் பெயர்கள் — தமிழ், ஆங்கிலம், தெலுங்கு, இந்தி, கன்னடம், மலையாளம்');
    intro = T(lang,
      'Millets are called siruthaniyam (சிறுதானியம்) in Tamil. The same grain has different names in every language, so here is one simple list — with how each is usually cooked and today\'s price at our shop.',
      'சிறுதானியங்களுக்கு ஒவ்வொரு மொழியிலும் வேறு பெயர்கள் உள்ளன. இங்கே ஒரே பட்டியலில் — எப்படிச் சமைப்பது, எங்கள் கடையின் இன்றைய விலையுடன்.');
    const mil = entries.filter((e) => e.brand === 'millets');
    body = `${table(mil, true)}
      ${mil.filter((e) => e.lang && e.lang.te).map((e) => `<h2>${esc(T(lang, `What is ${(e.tl || [])[0]} called in Telugu, Hindi and Kannada?`, `${(e.ta || [])[0]} — தெலுங்கு, இந்தி, கன்னடத்தில்`))}</h2>
      <p>${esc(langSentence(e, lang))}</p>`).join('\n      ')}`;
    description = T(lang, 'Ragi is kezhvaragu, kambu is pearl millet (bajra), thinai is foxtail millet… All millet names in Tamil, English and Hindi in one list, with uses and prices.',
      'கேழ்வரகு, கம்பு, தினை, சாமை, வரகு, குதிரைவாலி — சிறுதானியங்களின் தமிழ், ஆங்கிலப் பெயர்கள் ஒரே பட்டியலில்.');
  } else if (slug === 'traditional-rice') {
    heading = T(lang, 'Traditional rice varieties of Tamil Nadu', 'தமிழ்நாட்டின் பாரம்பரிய அரிசி வகைகள்');
    intro = T(lang,
      'Paarambariya arisi (பாரம்பரிய அரிசி) — the native rice varieties of Tamil Nadu, and the everyday rice we stock. Names in Tamil and English, what each is used for, and today\'s price.',
      'தமிழ்நாட்டின் பாரம்பரிய அரிசி வகைகளும் அன்றாட அரிசிகளும் — தமிழ், ஆங்கிலப் பெயர்கள், பயன்பாடு, இன்றைய விலையுடன்.');
    body = table(entries.filter((e) => e.brand === 'rice'), false);
    description = T(lang, 'Mappillai samba, karuppu kavuni, seeraga samba, kattuyanam, poongar and more: traditional rice varieties of Tamil Nadu with Tamil names, uses and prices.',
      'மாப்பிள்ளை சம்பா, கருப்பு கவுனி, சீரகச் சம்பா, காட்டுயானம், பூங்கார் — பாரம்பரிய அரிசி வகைகள்.');
  } else {
    heading = T(lang, 'How to cook millets — simple steps for beginners', 'சிறுதானியங்களை எப்படி சமைப்பது — எளிய வழிமுறை');
    intro = T(lang, 'New to millets? Cook them like rice. These are the usual home steps; every kitchen and stove is a little different, so adjust water to how soft you like it.',
      'சிறுதானியங்களுக்குப் புதியவரா? அரிசி போலவே சமைக்கலாம். இவை வழக்கமான வீட்டு முறைகள்; உங்களுக்கு ஏற்றபடி தண்ணீரை மாற்றிக்கொள்ளுங்கள்.');
    const steps = ta ? [
      'அலசுங்கள்: 2–3 முறை தண்ணீரில் நன்றாக அலசி, தூசி நீக்குங்கள்.',
      'ஊறவையுங்கள்: சாமை, தினை, வரகு, குதிரைவாலி — 30 நிமிடம் முதல் 2 மணி நேரம். கம்பு, சோளம் — 4–6 மணி நேரம்.',
      'தண்ணீர்: சாதமாக — 1 கப் தானியத்துக்கு சுமார் 2½–3 கப். பொங்கல், உப்புமா — சுமார் 3–4 கப்.',
      'சமைக்கவும்: குக்கரில் 2–3 விசில், அல்லது பாத்திரத்தில் மூடி வைத்து மெதுவாக 15–20 நிமிடம்.',
      'ஆரம்பத்தில்: அரிசியுடன் பாதிக்குப் பாதி கலந்து சமைத்தால் சுவைக்குப் பழகுவது எளிது.',
    ] : [
      'Rinse: wash 2–3 times in water to remove dust.',
      'Soak: small millets (samai, thinai, varagu, kuthiraivali) 30 minutes to 2 hours; kambu and cholam (sorghum) 4–6 hours.',
      'Water: as rice, about 2½–3 cups of water for 1 cup of millet; for pongal or upma, about 3–4 cups.',
      'Cook: 2–3 whistles in a pressure cooker, or covered on low heat for 15–20 minutes.',
      'Starting out: mix half millet and half rice — the taste is easier to get used to.',
    ];
    const recipes = (cat.recipes || []).slice(0, 8);
    body = `<ol>${steps.map((x) => `<li>${esc(x)}</li>`).join('')}</ol>
      ${recipes.length ? `<h2>${esc(T(lang, 'Recipes to try', 'செய்து பார்க்க சமையல் குறிப்புகள்'))}</h2><ul>${recipes.map((r) =>
        `<li><a href="${esc(pathFor(lang, `/recipe/${recipeSlug(r)}`))}">${esc(ta ? (r.nameLocal || r.name) : r.name)}</a></li>`).join('')}</ul>` : ''}
      <p><a href="${esc(pathFor(lang, '/guide/millet-names'))}">${esc(T(lang, 'Millet names in Tamil and English →', 'சிறுதானியப் பெயர்கள் →'))}</a></p>`;
    description = T(lang, 'How to cook millets at home: rinse, soak, water ratio and cooking time for samai, thinai, varagu, kuthiraivali, kambu and cholam.',
      'சிறுதானியங்களை வீட்டில் சமைக்கும் முறை: அலசுதல், ஊறவைத்தல், தண்ணீர் அளவு, சமைக்கும் நேரம்.');
  }
  const others = GUIDES.filter((g) => g !== slug);
  const guideName = (g) => ({
    'millet-names': T(lang, 'Millet names in Tamil & English', 'சிறுதானியப் பெயர்கள்'),
    'traditional-rice': T(lang, 'Traditional rice varieties', 'பாரம்பரிய அரிசி வகைகள்'),
    'how-to-cook-millets': T(lang, 'How to cook millets', 'சிறுதானியம் சமைக்கும் முறை'),
  }[g]);
  const jsonld = {
    '@context': 'https://schema.org', '@type': 'Article', headline: heading, description: clip(description, 300),
    inLanguage: lang === 'ta' ? 'ta' : 'en', mainEntityOfPage: url,
    author: { '@type': 'Organization', name: shop }, publisher: { '@type': 'Organization', name: shop },
  };
  const block = `<section class="seo-block wrap guide" aria-label="${esc(heading)}">
    ${crumbNav(lang, [[homeWord(lang), '/'], [heading, path]])}
    <h1>${esc(heading)}</h1>
    <p>${esc(intro)}</p>
    ${body}
    <p class="also">${esc(T(lang, 'More guides:', 'மேலும்:'))} ${others.map((g) => `<a href="${esc(pathFor(lang, `/guide/${g}`))}">${esc(guideName(g))}</a>`).join(' · ')} · <a href="${esc(pathFor(lang, '/prices'))}">${esc(T(lang, "Today's prices", 'இன்றைய விலை'))}</a></p>
  </section>`;
  return inject(base, headTags({
    title: `${heading} | ${shop}`, description: clip(description, 160), url,
    image: `${origin}/icons/icon-512.png`, type: 'article', lang, jsonld: [jsonld, crumbs(origin, lang, [[homeWord(lang), '/'], [heading, path]])],
    alternates: altLinks(origin, path),
  }), block, lang);
}

// The shop itself, for Google (name, logo, contact, return policy).
function storeJsonLd(cat, origin, lang) {
  const v = shopVars(cat, 'en');
  const out = {
    '@context': 'https://schema.org', '@type': 'OnlineStore', name: v.shop, url: `${origin}${lang === 'ta' ? '/ta/' : '/'}`,
    logo: `${origin}/icons/icon-512.png`, image: `${origin}/icons/icon-512.png`,
    hasMerchantReturnPolicy: { '@type': 'MerchantReturnPolicy', merchantReturnLink: `${origin}/policy/returns` },
  };
  if (v._phone || v._wa) out.telephone = v._phone || v._wa;
  if (v._email) out.email = v._email;
  if (v._addr) out.address = { '@type': 'PostalAddress', streetAddress: v._addr, addressCountry: 'IN' };
  return out;
}

function faqPage(ctx, faq) {
  const { cat, origin, lang, base } = ctx;
  const shop = shopName(cat, lang);
  const items = faqItems(faq, cat, lang);
  const path = '/faq';
  const url = `${origin}${pathFor(lang, path)}`;
  const heading = T(lang, 'Questions & answers', 'கேள்விகளும் பதில்களும்');
  const jsonld = {
    '@context': 'https://schema.org', '@type': 'FAQPage',
    mainEntity: items.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } })),
  };
  const block = `<section class="seo-block wrap" aria-label="${esc(heading)}">
    ${crumbNav(lang, [[homeWord(lang), '/'], [heading, path]])}
    <h1>${esc(heading)} — ${esc(shop)}</h1>
    ${items.map((f) => `<h2>${esc(f.q)}</h2><p>${esc(f.a)}</p>`).join('\n    ')}
  </section>`;
  return inject(base, headTags({
    title: `${heading} | ${shop}`, description: clip(items.slice(0, 3).map((f) => f.q).join(' '), 160), url,
    image: `${origin}/icons/icon-512.png`, type: 'website', lang, jsonld, alternates: altLinks(origin, path),
  }), block, lang);
}

function policyPage(ctx, policies, key) {
  const { cat, origin, lang, base } = ctx;
  const page = policies.pages[key];
  const shop = shopName(cat, lang);
  const heading = (lang === 'ta' && page.title.ta) || page.title.en;
  const path = `/policy/${key}`;
  const url = `${origin}${pathFor(lang, path)}`;
  let body;
  if (key === 'contact') {
    const v = shopVars(cat, lang);
    const row = (label, value) => (value ? `<p><strong>${esc(label)}:</strong> ${value}</p>` : '');
    body = [
      `<p><strong>${esc(shop)}</strong></p>`,
      row(T(lang, 'Address', 'முகவரி'), esc(v._addr)),
      row(T(lang, 'Phone', 'போன்'), v._phone ? `<a href="tel:${esc(v._phone)}">${esc(v._phone)}</a>` : ''),
      row('WhatsApp', v._wa ? `<a href="https://wa.me/${esc(v._waNum)}">${esc(v._wa)}</a>` : ''),
      row(T(lang, 'Email', 'மின்னஞ்சல்'), v._email ? `<a href="mailto:${esc(v._email)}">${esc(v._email)}</a>` : ''),
      row(T(lang, 'Shop hours', 'கடை நேரம்'), esc(v.hours)),
      row(T(lang, 'FSSAI licence no.', 'FSSAI உரிம எண்'), esc(v._fssai)),
      row(T(lang, 'Grievance officer', 'குறை தீர்க்கும் அலுவலர்'), esc(grievanceLine(v, lang))),
      v._map ? `<p><a href="${esc(v._map)}">${esc(T(lang, 'Get directions', 'வழி காட்டு'))}</a></p>` : '',
    ].filter(Boolean).join('\n    ');
  } else {
    body = policyLines(policies, key, cat, lang).map((x) => `<p>${esc(x)}</p>`).join('\n    ');
  }
  const links = policies.order.filter((k) => k !== key)
    .map((k) => `<a href="${esc(pathFor(lang, `/policy/${k}`))}">${esc((lang === 'ta' && policies.pages[k].title.ta) || policies.pages[k].title.en)}</a>`).join(' · ');
  const block = `<section class="seo-block wrap" aria-label="${esc(heading)}">
    ${crumbNav(lang, [[homeWord(lang), '/'], [heading, path]])}
    <h1>${esc(heading)}</h1>
    ${body}
    <p class="pol-links">${links}</p>
  </section>`;
  const desc = key === 'contact' ? `${heading} – ${shop}` : policyLines(policies, key, cat, lang).join(' ');
  return inject(base, headTags({
    title: `${heading} | ${shop}`, description: clip(desc, 160), url, image: `${origin}/icons/icon-512.png`,
    type: 'website', lang, jsonld: null, alternates: altLinks(origin, path),
  }), block, lang);
}

// Today's price list: every product, price per kg and pack prices, always
// current (built from the catalog the app publishes).
function pricesPage(ctx) {
  const { cat, names, origin, lang, base } = ctx;
  const ta = lang === 'ta';
  const shop = shopName(cat, lang);
  const products = visibleProducts(cat);
  const pages = shopPages(products, names);
  const slugs = productSlugs(products);
  const path = '/prices';
  const url = `${origin}${pathFor(lang, path)}`;
  const rank = (p) => { const e = entryFor(p, names); return e && e.rank ? e.rank : 99; };
  const byRank = (a, b) => Number(b.inStock !== false) - Number(a.inStock !== false) || rank(a) - rank(b) || String(a.name).localeCompare(String(b.name));
  const date = new Date(Date.now() + 5.5 * 3600 * 1000)
    .toLocaleDateString(ta ? 'ta-IN' : 'en-IN', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });
  // Best-known names for the title, taking turns between brands: Ragi, Ponni, Cattle feed, Kambu…
  const label = (p, brand) => {
    const e = entryFor(p, names);
    return brand === 'cattle' && e ? ((ta && e.ta && e.ta[0]) || e.en[0]) : shortName(p, lang);
  };
  const lists = pages.map((x) => {
    const seenKey = new Set();
    return [...x.items].sort(byRank).filter((p) => {
      const e = entryFor(p, names);
      const k = e ? e.id : shortName(p, lang); // one name per grain (Ragi, not also Ragi flour)
      if (seenKey.has(k)) return false;
      seenKey.add(k);
      return true;
    }).map((p) => label(p, x.brand)).filter(Boolean);
  });
  const top = [];
  for (let i = 0; top.length < 4 && lists.some((l) => l.length > i); i += 1) {
    lists.forEach((l) => { if (l[i] && top.length < 4 && !top.includes(l[i])) top.push(l[i]); });
  }
  const heading = T(lang, "Today's prices", 'இன்றைய விலைகள்');
  const title = ta
    ? `இன்றைய விலைப் பட்டியல் – ${top.join(', ')} | ${shop}`
    : `Today's price list – ${top.join(', ')} price per kg | ${shop}`;
  const name = (p) => (ta ? (p.nameLocal || p.name) : p.name);
  const cell = (k) => (k.offerPrice ? `${esc(k.label)} ₹${k.offerPrice} <s>₹${k.price}</s>` : `${esc(k.label)} ₹${k.price}`);
  const sample = [...products].sort(byRank).filter((p) => rateOf(p) > 0).slice(0, 3)
    .map((p) => `${shortName(p, lang)} ₹${rateOf(p)}${T(lang, '/kg', '/கிலோ')}`).join(', ');
  const description = clip(ta
    ? `${shop} — இன்றைய விலைகள் (${date}). ${sample}. விலை மாறும்போது தானாகப் புதுப்பிக்கப்படும்.`
    : `${shop} – today's prices (${date}). ${sample}. Updated automatically whenever our prices change.`, 160);
  const block = `<section class="seo-block wrap" aria-label="${esc(heading)}">
    ${crumbNav(lang, [[homeWord(lang), '/'], [heading, path]])}
    <h1>${esc(heading)} — ${esc(date)}</h1>
    <p>${esc(T(lang, "Our shop's selling prices, updated automatically whenever they change. The delivery charge is separate and shown at checkout before you pay.",
    'எங்கள் கடையின் விற்பனை விலைகள் — விலை மாறும்போது தானாகவே புதுப்பிக்கப்படும். டெலிவரி கட்டணம் தனி; பணம் செலுத்தும் முன் செக்அவுட்டில் தெரியும்.'))}</p>
    ${pages.map((x) => `<h2><a href="${esc(pathFor(lang, `/shop/${x.slug}`))}">${esc(x.brand ? brandName(names, x.brand, lang) : x.category)}</a></h2>
    <table class="price-table"><thead><tr><th>${esc(T(lang, 'Product', 'பொருள்'))}</th><th>${esc(T(lang, 'Per kg', 'கிலோ விலை'))}</th><th>${esc(T(lang, 'Packs', 'அளவுகள்'))}</th></tr></thead><tbody>
    ${[...x.items].sort(byRank).map((p) => `<tr><td><a href="${esc(pathFor(lang, `/p/${slugs.get(p.id)}`))}">${esc(name(p))}</a>${p.inStock === false ? ` <small>(${esc(T(lang, 'out of stock', 'இருப்பு இல்லை'))})</small>` : ''}</td><td>${rateOf(p) ? `₹${rateOf(p)}` : '–'}</td><td>${validPacks(p).map(cell).join(' · ')}</td></tr>`).join('\n    ')}
    </tbody></table>`).join('\n    ')}
  </section>`;
  const jsonld = {
    '@context': 'https://schema.org', '@type': 'ItemList', name: `${heading} – ${shop}`,
    itemListElement: [...products].sort(byRank).map((p, i) => ({ '@type': 'ListItem', position: i + 1, url: `${origin}${pathFor(lang, `/p/${slugs.get(p.id)}`)}`, name: name(p) })),
  };
  return inject(base, headTags({
    title, description, url, image: imgUrl(origin, (products.find((p) => p.image) || {}).image), type: 'website', lang,
    jsonld: [jsonld, crumbs(origin, lang, [[homeWord(lang), '/'], [heading, path]])], alternates: altLinks(origin, path),
  }), block, lang);
}

// Tamil home page (/ta/). The English home is the static index.html.
function taHome(ctx) {
  const { cat, names, origin, base } = ctx;
  const lang = 'ta';
  const shop = shopName(cat, lang);
  const products = visibleProducts(cat);
  const pages = shopPages(products, names);
  const slugs = productSlugs(products);
  const what = pages.map((x) => (x.brand ? names.brands[x.brand].what.ta : x.category));
  const title = `${what.join(', ')} – ஆன்லைனில் வாங்க | ${shop}`;
  const description = clip(`${shop}: ${pages.map((x) => (x.brand ? brandName(names, x.brand, 'ta') : x.category)).join(', ')}. UPI மூலம் பணம், ஆர்டர் கண்காணிப்பு, வீட்டுக்கே டெலிவரி.`, 160);
  const block = `<section class="seo-block wrap" aria-label="${esc(shop)}">
    <h1>${esc(shop)} — ${esc(what.join(', '))}</h1>
    ${pages.map((x) => `<h2><a href="${esc(pathFor(lang, `/shop/${x.slug}`))}">${esc(x.brand ? brandName(names, x.brand, 'ta') : x.category)}</a></h2>
    <ul>${x.items.filter((p) => p.inStock !== false).slice(0, 12).map((p) => `<li><a href="${esc(pathFor(lang, `/p/${slugs.get(p.id)}`))}">${esc(p.nameLocal || p.name)}</a></li>`).join('')}</ul>`).join('\n    ')}
    <p><a href="/ta/prices">இன்றைய விலைப் பட்டியல்</a> · <a href="/ta/faq">கேள்விகளும் பதில்களும்</a></p>
  </section>`;
  const jsonld = storeJsonLd(cat, origin, 'ta');
  return inject(base, headTags({
    title, description, url: `${origin}/ta/`, image: `${origin}/icons/icon-512.png`, type: 'website', lang: 'ta', jsonld, alternates: altLinks(origin, '/'),
  }), block, 'ta');
}

// Town pages: people search "millets near Sankarapuram", "ragi Kallakurichi"...
// One honest page per town we serve: what we sell, today's prices, how to
// get it (delivery to the door or pickup at our Pudupattu shop).
const TOWNS = {
  pudupattu: { en: 'Pudupattu', ta: 'புதுப்பட்டு', home: true },
  sankarapuram: { en: 'Sankarapuram', ta: 'சங்கராபுரம்' },
  kallakurichi: { en: 'Kallakurichi', ta: 'கள்ளக்குறிச்சி' },
  thiruvannamalai: { en: 'Thiruvannamalai', ta: 'திருவண்ணாமலை' },
};
const TOWN_SLUGS = Object.keys(TOWNS);
function townPage(ctx, slug) {
  const { cat, names, origin, lang, base } = ctx;
  const ta = lang === 'ta';
  const t = TOWNS[slug];
  const v = shopVars(cat, lang);
  const shop = v.shop;
  const products = visibleProducts(cat);
  const pages = shopPages(products, names);
  const slugs = productSlugs(products);
  const path = `/town/${slug}`;
  const url = `${origin}${pathFor(lang, path)}`;
  const rank = (p) => { const e = entryFor(p, names); return e && e.rank ? e.rank : 99; };
  const top = [...products].filter((p) => p.inStock !== false).sort((a, b) => rank(a) - rank(b));
  const what = pages.map((x) => (x.brand ? brandName(names, x.brand, lang) : x.category));
  const heading = ta ? `${t.ta} — சிறுதானியங்கள், அரிசி, மாட்டுத் தீவனம்` : `Millets, rice & cattle feed in ${t.en}`;
  const intro = t.home
    ? T(lang, `Our shop is in ${t.en}${v._addr ? ` (${v._addr})` : ''}. Visit us, or order online and pick up at the shop — or get it delivered.`,
      `எங்கள் கடை ${t.ta}வில் உள்ளது${v._addr ? ` (${v._addr})` : ''}. நேரில் வாருங்கள், அல்லது ஆன்லைனில் ஆர்டர் செய்து கடையில் பெற்றுக்கொள்ளுங்கள் / டெலிவரி பெறுங்கள்.`)
    : T(lang, `Living in or near ${t.en}? Order ${what.join(', ')} online from ${shop}, Pudupattu — delivered to your door, or pick up at our shop.`,
      `${t.ta} அல்லது அருகில் இருக்கிறீர்களா? ${shop} (புதுப்பட்டு) — ${what.join(', ')} ஆன்லைனில் ஆர்டர் செய்யுங்கள்; வீட்டுக்கே டெலிவரி அல்லது கடையில் பெறலாம்.`);
  const priceCell = (p) => (rateOf(p) ? `₹${rateOf(p)}${T(lang, '/kg', '/கிலோ')}` : (mainPack(p) ? `${esc(mainPack(p).label)} ₹${priceOf(mainPack(p))}` : '–'));
  const rows = top.slice(0, 14).map((p) => `<tr><td><a href="${esc(pathFor(lang, `/p/${slugs.get(p.id)}`))}">${esc(ta ? (p.nameLocal || p.name) : p.name)}</a></td><td>${priceCell(p)}</td></tr>`).join('\n      ');
  const others = TOWN_SLUGS.filter((x) => x !== slug);
  const description = clip(ta
    ? `${t.ta}: ${what.join(', ')} — ${shop}. இன்றைய விலை, UPI பணம், வீட்டுக்கே டெலிவரி அல்லது புதுப்பட்டு கடையில் பெறலாம்.`
    : `${what.join(', ')} in ${t.en} from ${shop}. Today's prices, UPI payment, delivery to your door or pickup at our Pudupattu shop.`, 160);
  const block = `<section class="seo-block wrap guide town" aria-label="${esc(heading)}">
    ${crumbNav(lang, [[homeWord(lang), '/'], [heading, path]])}
    <h1>${esc(heading)}</h1>
    <p>${esc(intro)}</p>
    <h2>${esc(T(lang, `Today's prices for ${t.en}`, `${t.ta} — இன்றைய விலை`))}</h2>
    <table class="price-table"><thead><tr><th>${esc(T(lang, 'Product', 'பொருள்'))}</th><th>${esc(T(lang, 'Price', 'விலை'))}</th></tr></thead><tbody>
      ${rows}
    </tbody></table>
    <p><a href="${esc(pathFor(lang, '/prices'))}">${esc(T(lang, 'All products and prices →', 'அனைத்து பொருட்களும் விலைகளும் →'))}</a></p>
    <h2>${esc(T(lang, 'How to get it', 'எப்படிப் பெறுவது'))}</h2>
    <ul>
      <li>${esc(T(lang, `Delivery: the delivery charge for your address is shown at checkout, before you pay. Sent within ${v.dispatch}.${v.free}`,
    `டெலிவரி: உங்கள் முகவரிக்கான கட்டணம் பணம் செலுத்தும் முன் செக்அவுட்டில் தெரியும். ${v.dispatch} அனுப்புவோம்.${v.free}`))}</li>
      <li>${esc(T(lang, `Pickup: free at our shop in Pudupattu${v.pickup}. ${v.hours}.`, `கடையில் பெறுதல்: புதுப்பட்டு கடையில் இலவசம்${v.pickup}. ${v.hours}.`))}</li>
      <li>${esc(T(lang, `Payment: UPI (GPay, PhonePe, Paytm).${v.contact ? ` Questions${v.contact}` : ''}`, `பணம்: UPI (GPay, PhonePe, Paytm).${v.contact ? ` கேள்விகள்${v.contact}` : ''}`))}</li>
    </ul>
    <p class="also">${esc(T(lang, 'Also serving:', 'மற்ற ஊர்கள்:'))} ${others.map((x) => `<a href="${esc(pathFor(lang, `/town/${x}`))}">${esc(ta ? TOWNS[x].ta : TOWNS[x].en)}</a>`).join(' · ')}</p>
  </section>`;
  const jsonld = [{ ...storeJsonLd(cat, origin, lang), areaServed: TOWN_SLUGS.map((x) => ({ '@type': 'City', name: TOWNS[x].en })) },
    crumbs(origin, lang, [[homeWord(lang), '/'], [heading, path]])];
  return inject(base, headTags({
    title: ta ? `${t.ta} — சிறுதானியம், அரிசி, மாட்டுத் தீவனம் | ${shop}` : `Millets, rice & cattle feed in ${t.en} | ${shop}`,
    description, url, image: `${origin}/icons/icon-512.png`, type: 'website', lang, jsonld, alternates: altLinks(origin, path),
  }), block, lang);
}

function allPaths(cat, names, policies) {
  const products = visibleProducts(cat);
  const slugs = productSlugs(products);
  return ['/',
    ...shopPages(products, names).map((x) => `/shop/${x.slug}`),
    '/prices',
    ...products.map((p) => `/p/${slugs.get(p.id)}`),
    ...(cat.recipes || []).map((r) => `/recipe/${recipeSlug(r)}`),
    '/faq',
    ...GUIDES.map((g) => `/guide/${g}`),
    ...TOWN_SLUGS.map((x) => `/town/${x}`),
    ...((policies && policies.order) || ['shipping', 'returns', 'privacy', 'terms', 'contact']).map((k) => `/policy/${k}`)];
}

// A short fingerprint of what each page shows. When it changes, that page
// gets a new "last changed" date in the sitemap and is announced to search
// engines (see seoPing in index.js). Stock counts aren't in the catalog, so
// a sale doesn't count as a change — only names, prices, photos, text.
const crypto = require('crypto');
const hashOf = (v) => crypto.createHash('md5').update(JSON.stringify(v === undefined ? null : v)).digest('hex').slice(0, 12);
function pageHashes(cat, names) {
  const products = visibleProducts(cat);
  const slugs = productSlugs(products);
  const all = hashOf(products.map((p) => [p.id, p.name, p.nameLocal, p.packs, p.pricePerKg, p.offerPerKg, p.inStock, p.image]));
  const out = { '/': all, '/prices': all };
  for (const x of shopPages(products, names)) out[`/shop/${x.slug}`] = hashOf(x.items);
  for (const p of products) out[`/p/${slugs.get(p.id)}`] = hashOf(p);
  for (const r of (cat.recipes || [])) out[`/recipe/${recipeSlug(r)}`] = hashOf(r);
  out['/faq'] = hashOf([cat.faq, cat.store, cat.shop]);
  for (const x of TOWN_SLUGS) out[`/town/${x}`] = all;
  return out;
}
// Firestore map keys can't hold "/" nicely, so "/p/ragi" is stored as "|p|ragi".
const pageKey = (path) => path.replace(/\//g, '|');

// [mods] = { path: 'YYYY-MM-DD' } — when each page really last changed.
function sitemap(cat, origin, names, policies, mods = {}) {
  const ts = cat.updatedAt && typeof cat.updatedAt.toDate === 'function' ? cat.updatedAt.toDate() : new Date();
  const lastmod = ts.toISOString().slice(0, 10);
  const alt = (path) => altLinks(origin, path).map((a) => `<xhtml:link rel="alternate" hreflang="${a.lang}" href="${esc(a.href)}"/>`).join('');
  // Product and recipe photos, so they can appear in Google Images.
  const products = visibleProducts(cat);
  const slugs = productSlugs(products);
  const photos = new Map();
  products.forEach((p) => { if (p.image) photos.set(`/p/${slugs.get(p.id)}`, imgUrl(origin, p.image)); });
  (cat.recipes || []).forEach((r) => { if (r.photo) photos.set(`/recipe/${recipeSlug(r)}`, imgUrl(origin, r.photo)); });
  const photo = (path) => (photos.has(path) ? `<image:image><image:loc>${esc(photos.get(path))}</image:loc></image:image>` : '');
  const urls = allPaths(cat, names, policies).flatMap((path) => [`${origin}${path}`, `${origin}${pathFor('ta', path)}`].map((loc) =>
    `  <url><loc>${esc(loc)}</loc><lastmod>${mods[path] || lastmod}</lastmod>${alt(path)}${photo(path)}</url>`));
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">\n${urls.join('\n')}\n</urlset>\n`;
}

// Google Merchant Center product feed: one item per pack size.
function feed(cat, origin, names) {
  const products = visibleProducts(cat);
  const slugs = productSlugs(products);
  const shop = shopName(cat, 'en');
  const x = (tag, value) => (value === '' || value == null ? '' : `<g:${tag}>${esc(value)}</g:${tag}>`);
  const items = [];
  for (const p of products) {
    if (!p.image) continue; // Google needs a real photo for every item
    const packs = validPacks(p);
    const brand = brandOf(p, names);
    const maker = makerOf(p, names);
    const latin = aliasesFor(p, names).filter((a) => !TAMIL.test(a));
    const about = p.description || (p.benefits || []).join('. ') || (usesFor(p, names, 'en') ? `Good for ${usesFor(p, names, 'en')}.` : '');
    for (const k of packs) {
      const size = /\d\s*(kg|kgs|g|gm|gms|l|ltr|ml)\b/i.test(k.label) && !lc(p.name).includes(lc(k.label)) ? ` – ${k.label}` : '';
      const kg = Number(k.kg) > 0 ? Number(k.kg) : (() => {
        const m = /(\d+(?:\.\d+)?)\s*(kg|kgs|g|gm|gms)\b/i.exec(k.label);
        return m ? Number(m[1]) * (/^k/i.test(m[2]) ? 1 : 0.001) : 0;
      })();
      const link = `${origin}/p/${slugs.get(p.id)}?pack=${encodeURIComponent(k.label)}`;
      const title = clip(`${maker ? '' : `${brandName(names, brand, 'en') || shop} `}${p.name}${latin.length ? `, ${latin.slice(0, 2).join(', ')}` : ''}${size}`, 150);
      items.push(`  <item>
    ${x('id', `${p.id}_${slugify(k.label)}`.slice(0, 50))}
    ${x('title', title)}
    ${x('description', clip(`${summaryOf(p, names, cat, 'en')} ${about}${latin.length ? ` Also called: ${latin.join(', ')}.` : ''}`, 1000) || title)}
    ${x('link', link)}
    ${x('image_link', imgUrl(origin, p.image))}
    ${x('availability', p.inStock === false ? 'out_of_stock' : 'in_stock')}
    ${x('price', `${k.price}.00 INR`)}
    ${k.offerPrice ? x('sale_price', `${k.offerPrice}.00 INR`) : ''}
    ${x('brand', maker || brandName(names, brand, 'en') || shop)}
    ${x('condition', 'new')}
    ${x('identifier_exists', 'no')}
    ${packs.length > 1 ? x('item_group_id', String(p.id).slice(0, 50)) : ''}
    ${x('product_type', brandName(names, brand, 'en') || p.category || '')}
    ${kg > 0 ? x('shipping_weight', `${Number(kg.toFixed(3))} kg`) : ''}
  </item>`.replace(/\n\s+\n/g, '\n'));
    }
  }
  return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">
<channel>
  <title>${esc(shop)}</title>
  <link>${esc(origin)}/</link>
  <description>${esc(`${shop} – products`)}</description>
${items.join('\n')}
</channel>
</rss>
`;
}

// ---- the HTTP handler (catalog, page shell and data files cached briefly) ----
function handler(db) {
  let catCache = { at: 0, data: null };
  const files = new Map(); // origin+path -> { at, value }
  const catalog = async () => {
    if (catCache.data && Date.now() - catCache.at < 5 * MIN) return catCache.data;
    const [snap, pri] = await Promise.all([
      db.doc('catalog/main').get(),
      db.doc('price_history/_prior').get().catch(() => null),
    ]);
    const raw = snap.exists ? snap.data() : { products: [], recipes: [] };
    catCache = { at: Date.now(), data: applyPrior(raw, pri && pri.exists ? pri.get('items') : null) };
    return catCache.data;
  };
  const hosted = async (origin, path, parse, fallback) => {
    const key = `${origin}${path}`;
    const hit = files.get(key);
    if (hit && Date.now() - hit.at < 10 * MIN) return hit.value;
    try {
      const res = await fetch(key);
      if (!res.ok) throw new Error(`${path}: ${res.status}`);
      const value = parse ? await res.json() : await res.text();
      files.set(key, { at: Date.now(), value });
      return value;
    } catch (e) {
      console.warn('seo file', path, e.message);
      return hit ? hit.value : fallback;
    }
  };
  const EMPTY_NAMES = { entries: [], forms: [], brands: {} };
  // When each page really last changed (written by seoPing).
  let datesCache = { at: 0, data: {} };
  const pageDates = async () => {
    if (Date.now() - datesCache.at < 10 * MIN) return datesCache.data;
    try {
      const snap = await db.doc('seo_state/pages').get();
      const pages = (snap.exists && snap.get('pages')) || {};
      const data = {};
      for (const [k, v] of Object.entries(pages)) if (v && v.at) data[k.replace(/\|/g, '/')] = String(v.at).slice(0, 10);
      datesCache = { at: Date.now(), data };
    } catch (e) { console.warn('seo dates', e.message); }
    return datesCache.data;
  };
  // Is madhuraagro.in connected and serving this website yet?
  let live = { at: 0, ok: false };
  const mainLive = async () => {
    if (MAIN_CONNECTED) return true;
    if (Date.now() - live.at < (live.ok ? 10 : 2) * MIN) return live.ok;
    let ok = false;
    try {
      const r = await fetch(`https://${MAIN_HOST}/version.json`, { signal: AbortSignal.timeout(4000) });
      ok = r.ok && /^v\d+$/.test(String((await r.json()).v || ''));
    } catch (e) { console.warn('main host check', e.message); ok = false; }
    live = { at: Date.now(), ok };
    return ok;
  };
  return async (req, res) => {
    const host = String(req.get('x-forwarded-host') || req.hostname || '').split(',')[0].trim();
    const origin = `https://${host}`;
    try {
      const path = decodeURIComponent(req.path || '/');
      if (path === '/main-host') {
        const ok = await mainLive();
        res.set('Cache-Control', 'no-store').type('application/json');
        return res.send(JSON.stringify({ main: ok ? `https://${MAIN_HOST}` : '' }));
      }
      if (isOldHost(host) && await mainLive()) {
        res.set('Cache-Control', 'public, max-age=3600');
        return res.redirect(301, `https://${MAIN_HOST}${req.originalUrl || req.url || '/'}`);
      }
      if (path === '/robots.txt') {
        res.set('Cache-Control', 'public, max-age=3600').type('text/plain');
        return res.send(`User-agent: *\nAllow: /\n\nSitemap: ${origin}/sitemap.xml\n`);
      }
      // Which photo version is stored for each product (the app checks this
      // and uploads again any photo that didn't reach the website).
      if (path === '/photo-versions') {
        const snap = await db.collection('catalog_images').select('v').get();
        const out = {};
        snap.forEach((d) => { out[d.id] = String(d.get('v') || ''); });
        res.set('Cache-Control', 'no-store').type('application/json');
        return res.send(JSON.stringify(out));
      }
      if (path.startsWith('/img/')) {
        const id = path.slice(5).replace(/\.jpg$/i, '');
        if (!/^[\w-]{1,120}$/.test(id)) return res.status(404).send('Not found');
        const snap = await db.doc(`catalog_images/${id}`).get();
        const b64 = snap.exists ? snap.get('data') : '';
        if (!b64) return res.status(404).send('Not found');
        const want = req.query && typeof req.query.v === 'string' ? req.query.v : '';
        const have = String(snap.get('v') || '');
        // A versioned address (?v=...) never changes, so phones and Google keep
        // it for a year — but only when the stored photo really is that version.
        // If the new photo hasn't arrived yet, keep it for 5 minutes only.
        res.set('Cache-Control', want && (!have || have === want)
          ? 'public, max-age=31536000, s-maxage=31536000, immutable'
          : want ? 'public, max-age=300, s-maxage=300' : 'public, max-age=86400, s-maxage=86400').type('image/jpeg');
        if (have) res.set('X-Photo-Version', have);
        return res.send(Buffer.from(String(b64).replace(/^data:image\/\w+;base64,/, ''), 'base64'));
      }
      const [cat, names] = await Promise.all([catalog(), hosted(origin, '/data/names.json', true, EMPTY_NAMES)]);
      if (path === '/sitemap.xml') {
        const [policies, mods] = await Promise.all([hosted(origin, '/data/policies.json', true, null), pageDates()]);
        res.set('Cache-Control', 'public, max-age=900, s-maxage=900').type('application/xml');
        return res.send(sitemap(cat, origin, names, policies, mods));
      }
      if (path === '/feed.xml') {
        res.set('Cache-Control', 'public, max-age=1800, s-maxage=3600').type('application/xml');
        return res.send(feed(cat, origin, names));
      }
      const base = await hosted(origin, '/index.html', false, '');
      let lang = 'en';
      let rest = path;
      if (rest === '/ta' || rest.startsWith('/ta/')) { lang = 'ta'; rest = rest.slice(3) || '/'; }
      const ctx = { cat, names, origin, lang, base };
      res.set('Cache-Control', 'public, max-age=300, s-maxage=600').type('text/html');
      if (lang === 'ta' && (rest === '/' || rest === '')) return res.send(taHome(ctx));
      const products = visibleProducts(cat);
      let m = rest.match(/^\/p\/([a-z0-9-]+)\/?$/);
      if (m) {
        const slugs = productSlugs(products);
        const p = products.find((x) => slugs.get(x.id) === m[1]);
        if (p) return res.send(productPage(ctx, p, m[1], req.query && typeof req.query.pack === 'string' ? req.query.pack : ''));
      }
      m = rest.match(/^\/recipe\/([a-z0-9-]+)\/?$/);
      if (m) {
        const r = (cat.recipes || []).find((x) => recipeSlug(x) === m[1]);
        if (r) return res.send(recipePage(ctx, r, m[1]));
      }
      m = rest.match(/^\/shop\/([a-z0-9-]+)\/?$/);
      if (m) {
        const page = shopPages(products, names).find((x) => x.slug === m[1]);
        if (page) return res.send(shopPage(ctx, page));
      }
      if (/^\/prices\/?$/.test(rest)) return res.send(pricesPage(ctx));
      m = rest.match(/^\/guide\/([a-z-]+)\/?$/);
      if (m && GUIDES.includes(m[1])) return res.send(guidePage(ctx, m[1]));
      m = rest.match(/^\/town\/([a-z]+)\/?$/);
      if (m && TOWNS[m[1]]) return res.send(townPage(ctx, m[1]));
      if (/^\/faq\/?$/.test(rest)) {
        const faq = await hosted(origin, '/data/faq.json', true, []);
        return res.send(faqPage(ctx, faq));
      }
      m = rest.match(/^\/policy\/([a-z]+)\/?$/);
      if (m) {
        const policies = await hosted(origin, '/data/policies.json', true, null);
        if (policies && policies.pages && policies.pages[m[1]]) return res.send(policyPage(ctx, policies, m[1]));
      }
      return res.status(404).send(base); // unknown: normal store, marked "not found" for Google
    } catch (e) {
      console.error('seo', e);
      return res.redirect(302, '/');
    }
  };
}

module.exports = {
  handler, MAIN_HOST, isOldHost, historyPrice, guidePage, GUIDES, applyPrior, priorOf, storeJsonLd, slugify, productSlugs, recipeSlug, entryFor, brandOf, aliasesFor, usesFor, recipesFor, shopPages, shopVars,
  fillVars, policyLines, faqItems, visibleProducts, productPage, recipePage, shopPage, faqPage, policyPage, taHome, pricesPage, summaryOf, rateOf,
  sitemap, feed, inject, allPaths, pageHashes, pageKey, pathFor, townPage, TOWN_SLUGS,
};
