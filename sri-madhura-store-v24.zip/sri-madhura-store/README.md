# Sri Madhura Agro Traders: web store

A phone-first online store. Customers browse, add to cart and order; the
order appears live in the shop's app, and the shop confirms on WhatsApp.
English and Tamil. Works offline after the first visit. Free Spark plan.

**Products are managed only in the shop's app** (Web Store screen and
Inventory). The app publishes the catalog and photos here automatically
whenever a product, price, stock level or photo changes. There is no
separate product editor on the website.

## Preview on your computer

From this folder: `npx serve public` (or `python -m http.server -d public`),
then open the address it prints. With `js/config.js` left empty, the store
runs in preview mode with sample products.

## Go live — do these in order

1. **Owner accounts first (important).** In the Firebase console, open
   Firestore, create a collection `admins`, and add one document per owner
   account. The document ID is the account's user ID (Authentication > Users,
   or shown on the app's "Waiting for access" screen). Add any field, e.g.
   `role: "owner"`. Skipping this before step 4 locks owners out of editing.
2. **Install the app update (v1.22.0 or later)**, sign in, open
   *Web Store* > *Shop details*: shop name, Tamil name, WhatsApp number
   (12 digits, e.g. 919876543210), UPI ID, delivery areas, pickup address.
   Choose which products appear online and add Tamil names / pack labels.
3. **Connect this website:** Firebase console > Project settings > Your apps >
   Add app > Web. Copy the config into `public/js/config.js`, and put the
   project ID in `.firebaserc`.
4. **Deploy:** `firebase deploy --only hosting,firestore:rules`
   `firestore.rules` covers BOTH the app and the website. It replaces the
   project's previous rules, which let any signed-in account read and write
   everything — unsafe once this website publishes the connection details.
5. **Staff accounts:** new sign-ups now wait for approval. Approve them in
   the app: *Manage Users* > tap the account > *View Only* or *Admin*.

## Everyday changes — all from the app, no code

- **Products, prices, offers, stock, photos:** Inventory and *Web Store*.
- **Product page text, details, Homemade / Best seller / New tags:** tap a
  product in *Web Store*.
- **Offer banners, delivery note, trust lines, owner story, About us,
  phone, map, hours, Instagram, category photos:** *Web Store* >
  *Website content*.

- **Benefits and How to use tabs:** tap a product in *Web Store* (use
  *Fill from library* for millets and grams), or *Fill benefits* to fill
  every matching product at once.
- **Customer tips:** customers suggest tips on a product's How to use tab;
  approve them in *Web Store* > *Customer tips* before they appear.

Changes appear on the website within a few seconds. Only design and layout
changes need a code update.

## How it fits together

- `catalog/main`: the product list and shop details, written by the app.
- `catalog_images/{productId}`: one photo per product, written by the app.
  Kept separate because a Firestore document is limited to 1 MB.
- `orders/{orderNo}`: created by customers here; managed in the app's
  *Online Orders* screen (price check, WhatsApp confirmation in English or
  Tamil, status, and *Record as sale* to update stock and reports).
- One web pack always equals one unit in the app's Inventory, so order
  quantities reduce stock exactly.

## After changing html/css/js

Change `CACHE = 'smat-v5'` in `sw.js` to the next number before deploying,
so phones pick up the new version.

## Staying free

The catalog is one document: 1 read per visit (free limit 50,000 a day).
Each photo is 1 read the first time it's shown, then cached on the phone.
Each order is 1 write (free limit 20,000 a day).
