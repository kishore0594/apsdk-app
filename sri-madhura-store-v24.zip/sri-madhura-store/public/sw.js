// Offline support for the Sri Madhura Agro Traders store.
// When you change index.html, css or js, bump CACHE so phones pick up the new version.
const CACHE = 'smat-v24';
const SHELL = [
  '/', '/index.html', '/css/style.css', '/js/app.js', '/js/config.js',
  '/manifest.json', '/images/placeholder.svg', '/images/logo.webp', '/images/logo-mark.webp',
  '/icons/icon-192.png', '/icons/icon-512.png',
];
const RUNTIME_HOSTS = ['www.gstatic.com', 'fonts.googleapis.com', 'fonts.gstatic.com'];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  if (url.origin === self.location.origin) {
    if (url.pathname.startsWith('/__/')) return; // Firebase reserved URLs
    if (req.mode === 'navigate') { event.respondWith(networkFirst(req)); return; }
    // Pages, scripts, styles and settings: always the newest version when
    // online (the saved copy is used only offline). Images and icons rarely
    // change, so they come from the saved copy for speed.
    const staticAsset = url.pathname.startsWith('/images/') || url.pathname.startsWith('/icons/');
    event.respondWith(staticAsset ? cacheFirst(req) : networkFirst(req));
    return;
  }
  // Firebase SDK and fonts. Firestore traffic (firestore.googleapis.com) is left alone.
  if (RUNTIME_HOSTS.includes(url.hostname)) { event.respondWith(staleWhileRevalidate(req)); return; }
  // Product photos hosted elsewhere (Cloudinary, imgbb, Firebase Storage).
  if (req.destination === 'image') event.respondWith(cacheFirst(req));
});

async function networkFirst(req) {
  const cache = await caches.open(CACHE);
  try {
    const res = await fetch(req);
    if (res.ok) cache.put(req, res.clone());
    return res;
  } catch {
    return (await cache.match(req)) || (await cache.match('/index.html')) || (await cache.match('/')) || Response.error();
  }
}

async function cacheFirst(req) {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(req);
  if (hit) return hit;
  try {
    const res = await fetch(req);
    if (res.ok || res.type === 'opaque') cache.put(req, res.clone());
    return res;
  } catch {
    return (await cache.match('/images/placeholder.svg')) || Response.error();
  }
}

async function staleWhileRevalidate(req) {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(req);
  const network = fetch(req)
    .then((res) => { if (res.ok) cache.put(req, res.clone()); return res; })
    .catch(() => hit || Response.error());
  return hit || network;
}

/* ---------- Offer alerts (web push) ----------
   The shop's server sends a short data message; we show it in the phone's
   notification bar and put a badge on the installed app icon (iPhone;
   Android shows its own dot for unread notifications). Tapping opens the
   store, or the page the shop linked. */
self.addEventListener('push', (event) => {
  let payload = {};
  try { payload = event.data ? event.data.json() : {}; } catch (_) { payload = {}; }
  const d = payload.data || payload;
  const title = String(d.title || 'Sri Madhura Agro Traders').slice(0, 80);
  event.waitUntil((async () => {
    await self.registration.showNotification(title, {
      body: String(d.body || '').slice(0, 200),
      icon: '/icons/icon-192.png',
      badge: '/icons/icon-192.png',
      tag: String(d.tag || 'offer'),
      data: { url: String(d.url || '/') },
    });
    if (self.navigator && self.navigator.setAppBadge) {
      try { await self.navigator.setAppBadge(1); } catch (_) { /* not supported here */ }
    }
  })());
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = new URL((event.notification.data && event.notification.data.url) || '/', self.location.origin).href;
  event.waitUntil((async () => {
    const wins = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const w of wins) {
      if (w.url.startsWith(self.location.origin) && 'focus' in w) {
        try { await w.navigate(url); } catch (_) { /* same page */ }
        return w.focus();
      }
    }
    return self.clients.openWindow(url);
  })());
});
