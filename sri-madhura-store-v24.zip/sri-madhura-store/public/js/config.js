// 1) Paste your Firebase web app config here
//    (Firebase console > Project settings > Your apps > Web app > Config).
//    While apiKey starts with "PASTE", the store runs in preview mode with sample products.
export const FIREBASE_CONFIG = {
  apiKey: 'PASTE_API_KEY',
  authDomain: '',
  projectId: '',
  storageBucket: '',
  messagingSenderId: '',
  appId: '',
};

export const FIREBASE_SDK_VERSION = '10.12.2';

// 2) Order numbers look like SMA-0924-K7PX. If you change this prefix,
//    change the same prefix in firestore.rules (validNewOrder).
// Web push key: Firebase console > Project settings > Cloud Messaging >
// Web Push certificates > Generate key pair. Empty = offer alerts hidden.
export const PUSH_VAPID_KEY = '';

export const ORDER_PREFIX = 'SMA';

// 3) Fallback shop details. The live values come from the "store" section
//    of the catalog the shop app publishes (Web Store > Shop details).
export const STORE_DEFAULTS = {
  name: 'Sri Madhura Agro Traders',
  tagline: 'Millets, rice and grains',
  whatsapp: '',
  upiId: '',
  minOrder: 0,
  deliveryAreas: [],
  pickupAddress: '',
  hours: '',
};
