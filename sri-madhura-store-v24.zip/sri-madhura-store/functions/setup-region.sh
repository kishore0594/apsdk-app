#!/usr/bin/env bash
# Finds your Firestore database location and writes the matching region
# for the functions (they must run where the database is).
cd "$(dirname "$0")"
LOC=$(firebase firestore:databases:get "(default)" --json 2>/dev/null | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin); r = d.get('result', d)
    print(r.get('locationId', ''))
except Exception:
    print('')
")
case "$LOC" in
  # Multi-region databases: functions run in a region inside them.
  nam5|nam7) REGION=us-central1 ;;
  eur3) REGION=europe-west1 ;;
  eur*|nam*) REGION=us-central1 ;;
  "") echo "Could not read the database location. Open Firebase console > Firestore > the location shown (e.g. asia-south1), then run:  echo asia-south1 > functions/region.txt"; exit 1 ;;
  *) REGION=$LOC ;;
esac
echo "$REGION" > region.txt
echo "Functions will run in: $REGION (database location: $LOC)"
